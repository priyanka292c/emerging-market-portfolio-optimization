"""
09_qaoa.py
==========
QAOA implementation for quantum portfolio sub-problem.
Uses Qiskit 2.5.x API (current installed version).

Two-scale design:
  SMALL-EXACT experiment: N_q = 8-12 assets, n_bits = 3
    -> M = 24-36 qubits, statevector simulation feasible
    -> Brute-force optimum computed for approximation ratio
  
  FINANCIAL-SCALE: handled by 07_classical_optimization.py

QAOA layers tested: p = 1, 2, 3
Classical optimisers: COBYLA, SLSQP
Noise simulation: via 11_noise_simulation.py integration

Outputs:
  - Results/qaoa_weights_{date}.csv
  - Results/qaoa_performance.csv
  - Results/qaoa_convergence.csv
  - Logs/09_qaoa.log
"""

import sys
import logging
import json
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
RESULTS   = ROOT / "Results"
LOG_DIR   = ROOT / "Logs"
RESULTS.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "09_qaoa.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
QAOA_LAYERS   = [1, 2, 3]
SHOTS         = 4096
N_QUBITS_MAX  = 36     # max for statevector simulation (conservative)
RANDOM_STATE  = 42
MAX_RESTARTS  = 3      # random restarts for COBYLA


# ---------------------------------------------------------------------------
# Qiskit version detection
# ---------------------------------------------------------------------------

def detect_qiskit():
    """Detect Qiskit version and available backends."""
    try:
        import qiskit
        log.info(f"Qiskit version: {qiskit.__version__}")
    except ImportError:
        log.error("Qiskit not installed.")
        sys.exit(1)
    try:
        from qiskit_aer import AerSimulator
        log.info("qiskit-aer: available")
        return True
    except ImportError:
        log.warning("qiskit-aer not installed -- QAOA cannot run.")
        return False


# ---------------------------------------------------------------------------
# QAOA circuit construction (Qiskit 2.x API)
# ---------------------------------------------------------------------------

def build_qaoa_circuit(J: np.ndarray, h: np.ndarray,
                        p: int, gamma: np.ndarray,
                        beta: np.ndarray) -> "QuantumCircuit":
    """
    Build QAOA circuit for Ising Hamiltonian H_C = sum_{ij} J_{ij} Z_i Z_j + sum_i h_i Z_i.

    Circuit structure (Qiskit 2.x):
      |+...+> (Hadamard initialization)
      repeat p times:
        Phase separation U_C(gamma_k): exp(-i gamma_k H_C)
          = prod_{ij} RZZ(2 gamma_k J_{ij}) * prod_i RZ(2 gamma_k h_i)
        Mixing operator U_B(beta_k):
          = prod_i RX(2 beta_k)

    Returns: QuantumCircuit (with measurements)
    """
    from qiskit import QuantumCircuit

    M = len(h)
    qc = QuantumCircuit(M, M)

    # Initialization: |+>^M
    qc.h(range(M))

    for k in range(p):
        gk = gamma[k]
        bk = beta[k]

        # Phase separation: ZZ terms
        for i in range(M):
            for j in range(i + 1, M):
                if abs(J[i, j]) > 1e-10:
                    qc.rzz(2 * gk * J[i, j], i, j)

        # Phase separation: Z terms (single-qubit Z rotations)
        for i in range(M):
            if abs(h[i]) > 1e-10:
                qc.rz(2 * gk * h[i], i)

        # Mixing operator: X rotations
        for i in range(M):
            qc.rx(2 * bk, i)

    # Measurement
    qc.measure(range(M), range(M))
    return qc


def build_qaoa_expectation_circuit(J: np.ndarray, h: np.ndarray,
                                    p: int, gamma: np.ndarray,
                                    beta: np.ndarray) -> "QuantumCircuit":
    """Circuit WITHOUT measurement for expectation value computation."""
    from qiskit import QuantumCircuit

    M = len(h)
    qc = QuantumCircuit(M)
    qc.h(range(M))

    for k in range(p):
        gk = gamma[k]
        bk = beta[k]
        for i in range(M):
            for j in range(i + 1, M):
                if abs(J[i, j]) > 1e-10:
                    qc.rzz(2 * gk * J[i, j], i, j)
        for i in range(M):
            if abs(h[i]) > 1e-10:
                qc.rz(2 * gk * h[i], i)
        for i in range(M):
            qc.rx(2 * bk, i)
    return qc


# ---------------------------------------------------------------------------
# Expectation value computation
# ---------------------------------------------------------------------------

_E_ALL_CACHE = {}

def get_e_all(J, h, offset, M):
    key = (M, round(float(offset), 6), round(float(np.sum(J)), 6), round(float(np.sum(h)), 6))
    if key not in _E_ALL_CACHE:
        Z_all = np.array([[1 - 2 * int(b) for b in format(i, f'0{M}b')] for i in range(2 ** M)])
        _E_ALL_CACHE[key] = np.einsum('ki,ij,kj->k', Z_all, J, Z_all) + Z_all @ h + offset
    return _E_ALL_CACHE[key]


def compute_expectation(J: np.ndarray, h: np.ndarray, offset: float,
                         params: np.ndarray, p: int,
                         simulator,
                         use_statevector: bool = True,
                         shots: int = SHOTS) -> float:
    """
    Compute E[<psi(gamma,beta)|H_C|psi(gamma,beta)>] via simulation.
    """
    gamma = params[:p]
    beta  = params[p:]
    M     = len(h)

    qc = build_qaoa_expectation_circuit(J, h, p, gamma, beta)

    if use_statevector and M <= 20:
        # Statevector simulation -- exact & vectorized
        from qiskit.quantum_info import Statevector
        sv = Statevector(qc)
        probs = sv.probabilities()       # 2^M probabilities
        E_all = get_e_all(J, h, offset, M)
        return float(probs @ E_all)
    else:
        # Shot-based simulation
        from qiskit import transpile
        qc_meas = qc.copy()
        qc_meas.measure_all()
        t_qc = transpile(qc_meas, simulator)
        job  = simulator.run(t_qc, shots=shots)
        counts = job.result().get_counts()

        E = 0.0
        for bitstring, count in counts.items():
            z = np.array([1 - 2 * int(b) for b in bitstring])
            E_z = z @ J @ z + h @ z + offset
            E  += (count / shots) * E_z
        return E


# ---------------------------------------------------------------------------
# QAOA optimisation loop
# ---------------------------------------------------------------------------

def run_qaoa(J: np.ndarray, h: np.ndarray, offset: float,
              p: int,
              simulator,
              use_statevector: bool = True,
              shots: int = SHOTS,
              n_restarts: int = MAX_RESTARTS,
              seed: int = RANDOM_STATE) -> dict:
    """
    Run QAOA for p layers and return best result.

    Returns dict with:
      - best_params  : (2p,) array [gamma, beta]
      - best_energy  : float
      - convergence  : list of (iter, energy)
      - n_evaluations: int
    """
    from scipy.optimize import minimize as sp_minimize

    M = len(h)
    rng = np.random.default_rng(seed)
    best_energy = np.inf
    best_params = None
    all_convergence = []
    total_evals = 0
    n_eval_counter = [0]

    def objective(params):
        n_eval_counter[0] += 1
        E = compute_expectation(J, h, offset, params, p,
                                 simulator, use_statevector, shots)
        all_convergence.append((n_eval_counter[0], E))
        return E

    for restart in range(n_restarts):
        # Random initialization
        gamma0 = rng.uniform(0, np.pi, p)
        beta0  = rng.uniform(0, np.pi / 2, p)
        params0 = np.concatenate([gamma0, beta0])

        try:
            res = sp_minimize(objective, params0, method="COBYLA",
                               options={"maxiter": 500, "rhobeg": 0.5})
            if res.fun < best_energy:
                best_energy = res.fun
                best_params = res.x.copy()
            total_evals += res.nfev
            log.info(f"    Restart {restart+1}/{n_restarts}: "
                     f"energy={res.fun:.6f}, nfev={res.nfev}")
        except Exception as e:
            log.warning(f"    Restart {restart+1}: COBYLA failed ({e})")

    return {
        "p":              p,
        "best_energy":    best_energy,
        "best_params":    best_params.tolist() if best_params is not None else None,
        "n_evaluations":  total_evals,
        "convergence":    all_convergence,
    }


# ---------------------------------------------------------------------------
# Extract portfolio weights from QAOA result
# ---------------------------------------------------------------------------

def extract_weights_from_qaoa(J: np.ndarray, h: np.ndarray, offset: float,
                                params: np.ndarray, p: int,
                                N: int, n_bits: int, w_max: float,
                                simulator,
                                shots: int = SHOTS) -> np.ndarray:
    """
    Sample the QAOA circuit and extract portfolio weights from the
    most-probable feasible bitstring.
    """
    gamma = params[:p]
    beta  = params[p:]
    M     = N * n_bits
    qc    = build_qaoa_circuit(J, h, p, gamma, beta)

    from qiskit import transpile
    t_qc = transpile(qc, simulator)
    job  = simulator.run(t_qc, shots=shots)
    counts = job.result().get_counts()

    sys.path.insert(0, str(ROOT / "Python"))
    from qubo_utils import weight_vector_from_x

    best_w   = None
    best_val = -np.inf

    for bitstring, count in sorted(counts.items(), key=lambda x: -x[1]):
        x = np.array([int(b) for b in reversed(bitstring)], dtype=float)  # LSB first
        if len(x) != M:
            continue
        w = weight_vector_from_x(x, N, n_bits, w_max)
        total_w = w.sum()
        # Feasibility check: budget within 20% of 1
        if total_w > 0.05:
            w_norm = w / total_w
            if best_w is None:
                best_w = w_norm
                best_val = count

    if best_w is None:
        log.warning("No feasible bitstring found -- returning equal weight.")
        return np.ones(N) / N

    return best_w


# ---------------------------------------------------------------------------
# Brute-force optimum (for approximation ratio, small N)
# ---------------------------------------------------------------------------

def brute_force_optimum(Q: np.ndarray, c: float = 0.0,
                         max_M: int = 20) -> tuple[float, float, np.ndarray]:
    """
    Enumerate all 2^M binary strings and find minimum and maximum QUBO value.
    Only feasible for M <= 20.
    """
    M = Q.shape[0]
    if M > max_M:
        log.warning(f"Brute force skipped: M={M} > {max_M}")
        return np.nan, np.nan, None

    best_min = np.inf
    best_max = -np.inf
    best_x   = None
    for i in range(2 ** M):
        x = np.array([int(b) for b in format(i, f'0{M}b')], dtype=float)
        val = x @ Q @ x + c
        if val < best_min:
            best_min = val
            best_x   = x.copy()
        if val > best_max:
            best_max = val

    log.info(f"Brute-force: E_min={best_min:.6f}, E_max={best_max:.6f}")
    return float(best_min), float(best_max), best_x


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    log.info("=" * 70)
    log.info("Phase 9: QAOA Quantum Portfolio Optimisation")
    log.info("=" * 70)

    if not detect_qiskit():
        log.error("qiskit-aer required. Install: pip install qiskit-aer")
        sys.exit(1)

    from qiskit_aer import AerSimulator

    # Use statevector simulator for exact small-scale experiment
    sv_simulator = AerSimulator(method="statevector")
    log.info(f"Simulator: {sv_simulator.name}")

    # Load QUBO test data (from 08_qubo_builder.py self-test)
    Q_path = DATA_PROC / "test_qubo_Q.npy"
    J_path = DATA_PROC / "test_ising_J.npy"
    h_path = DATA_PROC / "test_ising_h.npy"

    if not all(p.exists() for p in [Q_path, J_path, h_path]):
        log.error("QUBO test matrices not found. Run 08_qubo_builder.py first.")
        sys.exit(1)

    Q = np.load(Q_path)
    J = np.load(J_path)
    h = np.load(h_path)
    offset = float(0.25 * Q.sum() + 0.25 * np.trace(Q))
    M = Q.shape[0]

    log.info(f"\nQUBO dimensions: {Q.shape}  ({M} qubits)")

    # Truncate to max feasible for statevector (memory limit)
    if M > N_QUBITS_MAX:
        log.warning(f"M={M} > {N_QUBITS_MAX}: truncating for demo. Full run requires noise model.")
        M_use = N_QUBITS_MAX
        J = J[:M_use, :M_use]
        h = h[:M_use]
        Q = Q[:M_use, :M_use]
    else:
        M_use = M

    # Brute-force for approximation ratio (only if M_use <= 20)
    bf_min, bf_max, bf_x = brute_force_optimum(Q, 0.0, max_M=20)

    # QAOA runs
    qaoa_results = []
    for p in QAOA_LAYERS:
        log.info(f"\n--- QAOA p={p} ({2*p} parameters) ---")
        result = run_qaoa(J[:M_use, :M_use], h[:M_use], offset,
                           p=p, simulator=sv_simulator,
                           use_statevector=(M_use <= 20),
                           shots=SHOTS)

        if not np.isnan(bf_min) and bf_max > bf_min:
            approx_ratio = (bf_max - result["best_energy"]) / (bf_max - bf_min)
        else:
            approx_ratio = np.nan

        log.info(f"  p={p}: best_energy={result['best_energy']:.6f}, "
                 f"n_eval={result['n_evaluations']}, "
                 f"approx_ratio={approx_ratio:.4f}")

        qaoa_results.append({
            "p":             p,
            "best_energy":   result["best_energy"],
            "n_evaluations": result["n_evaluations"],
            "approx_ratio":  approx_ratio,
            "bf_optimum":    bf_min,
            "n_qubits":      M_use,
        })

        # Save convergence
        conv_df = pd.DataFrame(result["convergence"], columns=["iteration", "energy"])
        conv_df["p"] = p
        conv_df.to_csv(RESULTS / f"qaoa_convergence_p{p}.csv", index=False)

    # Save results
    res_df = pd.DataFrame(qaoa_results)
    res_df.to_csv(RESULTS / "qaoa_performance.csv", index=False)
    log.info(f"\n[OK] QAOA performance saved: {RESULTS / 'qaoa_performance.csv'}")
    log.info("\nQAOA Summary:")
    log.info(res_df.to_string(index=False))


if __name__ == "__main__":
    main()
