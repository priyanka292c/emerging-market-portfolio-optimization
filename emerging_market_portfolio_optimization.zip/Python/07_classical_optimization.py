"""
07_classical_optimization.py
=============================
Classical portfolio optimisation -- investment-scale experiment.
Universe: 30-50 BIST assets (full breadth).

Models implemented:
  A: Historical Mean + Markowitz (mean-variance)
  B: Factor ML Forecast + Markowitz
  C: Factor ML Forecast + Regime-adjusted + Markowitz
  D: Factor ML + Regime + CVaR (Path A, exact, CVXPY)
  E: Factor ML + Regime + CVaR + TC + Cardinality (full classical model, CVXPY MIQP)

Additional benchmarks:
  EW    : Equal Weight
  RP    : Risk Parity
  SA    : Simulated Annealing (scipy)
  GA    : Genetic Algorithm (DEAP)

Solver:
  - CVXPY with CLARABEL (quadratic) / ECOS_BB (MIQP) / HiGHS (LP sub-problems)
  - scipy.optimize.milp with HiGHS for LP benchmarks
  - For cardinality-constrained MIQP, CVXPY uses ECOS_BB or SCIP if available.

Transaction cost model:
  TC_t = sum_i c_i * |w_{i,t} - w_{i,t-1}|
  Only TC appears in the objective (turnover is a REPORTED metric, not penalised separately).

Outputs:
  - Results/classical_weights_{model}.csv   : weights per date per model
  - Results/classical_performance.csv       : aggregated metrics
  - Logs/07_classical_optimization.log
"""

import sys
import logging
import json
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import minimize

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
COV_DIR   = DATA_PROC / "covariances"
RESULTS   = ROOT / "Results"
LOG_DIR   = ROOT / "Logs"
RESULTS.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "07_classical_optimization.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------
LAMBDA1        = 1.0    # variance penalty
LAMBDA2        = 0.5    # CVaR penalty
LAMBDA3        = 2.0    # TC penalty
TC_COST        = 0.002  # 20bps proportional transaction cost
ALPHA_CVAR     = 0.95
CARDINALITY_K  = 12     # max assets in portfolio
W_MIN          = 0.0    # minimum weight
W_MAX          = 0.20   # maximum single-asset weight
MAX_TURNOVER   = 0.50   # max portfolio turnover per rebalancing (for constraint model)
SCENARIO_WIN   = 252    # historical scenario window for CVaR
REGIME_SCALE   = {      # mu adjustment by regime (conservative in bear, aggressive in bull)
    "Bear":         0.50,
    "Bear/Normal":  0.75,
    "Normal":       1.00,
    "Bull":         1.25,
    "Strong Bull":  1.50,
    "Unknown":      1.00,
}


# ---------------------------------------------------------------------------
# Data loaders
# ---------------------------------------------------------------------------

def load_forecasts(model_name: str = "Ensemble") -> pd.DataFrame:
    path = DATA_PROC / "ml_forecasts.csv"
    if not path.exists():
        log.error("ml_forecasts.csv not found.")
        sys.exit(1)
    df = pd.read_csv(path, parse_dates=["date"])
    return df[df["model"] == model_name].copy()


def load_regimes() -> pd.DataFrame:
    path = DATA_PROC / "regime_states.csv"
    if not path.exists():
        log.warning("regime_states.csv not found -- regime scaling disabled.")
        return pd.DataFrame(columns=["date", "label"])
    return pd.read_csv(path, parse_dates=["date"])


def load_covariance(date: pd.Timestamp, cov_type: str = "lw") -> tuple[np.ndarray, list]:
    """Load precomputed covariance matrix and ticker list for given date."""
    meta_path = DATA_PROC / "cov_metadata.csv"
    if not meta_path.exists():
        return None, []
    meta = pd.read_csv(meta_path, parse_dates=["date"])
    row  = meta[meta["date"] <= date].iloc[-1] if not meta[meta["date"] <= date].empty else None
    if row is None:
        return None, []
    date_str = pd.to_datetime(row["date"]).strftime("%Y%m%d")
    cov_path = COV_DIR / f"cov_{cov_type}_{date_str}.npy"
    if not cov_path.exists():
        return None, []
    cov     = np.load(cov_path)
    tickers = json.loads(row["tickers_json"])
    return cov, tickers


def load_returns_for_scenarios(date: pd.Timestamp,
                                tickers: list[str]) -> np.ndarray:
    ret = pd.read_csv(DATA_PROC / "returns.csv", index_col=0, parse_dates=True)
    hist = ret.loc[ret.index < date, tickers].iloc[-SCENARIO_WIN:]
    return hist.dropna(how="any").values


# ---------------------------------------------------------------------------
# Regime-adjusted expected return
# ---------------------------------------------------------------------------

def regime_adjust_mu(mu: np.ndarray, date: pd.Timestamp,
                      regimes: pd.DataFrame) -> np.ndarray:
    row = regimes[regimes["date"] <= date]
    if row.empty:
        return mu
    label  = row.iloc[-1]["label"]
    scale  = REGIME_SCALE.get(label, 1.0)
    return mu * scale


# ---------------------------------------------------------------------------
# Model A/B/C: unconstrained mean-variance (CVXPY)
# ---------------------------------------------------------------------------

def solve_markowitz(mu: np.ndarray, Sigma: np.ndarray,
                    lam1: float = LAMBDA1,
                    w_prev: np.ndarray = None,
                    tc_cost: float = 0.0) -> np.ndarray:
    """Standard mean-variance with optional TC penalty (linear approximation)."""
    try:
        import cvxpy as cp
    except ImportError:
        log.error("cvxpy not installed.")
        return np.ones(len(mu)) / len(mu)

    N = len(mu)
    w = cp.Variable(N)
    obj = -mu @ w + lam1 * cp.quad_form(w, Sigma)
    if w_prev is not None and tc_cost > 0:
        obj = obj + tc_cost * cp.norm1(w - w_prev)

    prob = cp.Problem(cp.Minimize(obj), [
        cp.sum(w) == 1,
        w >= W_MIN,
        w <= W_MAX,
    ])
    prob.solve(solver=cp.CLARABEL, verbose=False)
    if prob.status not in ["optimal", "optimal_inaccurate"] or w.value is None:
        log.warning(f"Markowitz: solver status={prob.status}. Returning EW.")
        return np.ones(N) / N
    return np.maximum(w.value, 0)


# ---------------------------------------------------------------------------
# Model D: CVaR-constrained (Path A exact, CVXPY)
# ---------------------------------------------------------------------------

def solve_cvar_portfolio(mu: np.ndarray, Sigma: np.ndarray,
                          R_scenarios: np.ndarray,
                          lam1: float = LAMBDA1,
                          lam2: float = LAMBDA2,
                          alpha: float = ALPHA_CVAR,
                          w_prev: np.ndarray = None,
                          tc_cost: float = 0.0) -> np.ndarray:
    """Full CVaR-constrained portfolio (exact Rockafellar-Uryasev)."""
    try:
        import cvxpy as cp
    except ImportError:
        return np.ones(len(mu)) / len(mu)

    N = len(mu)
    T = len(R_scenarios)

    sys.path.insert(0, str(ROOT / "Python"))
    from cvar_utils import cvar_exact_cvxpy   # avoid circular import

    w   = cp.Variable(N)
    nu  = cp.Variable()
    u   = cp.Variable(T)
    losses = -R_scenarios @ w

    cvar_expr = nu + (1.0 / ((1 - alpha) * T)) * cp.sum(u)

    obj = -mu @ w + lam1 * cp.quad_form(w, Sigma) + lam2 * cvar_expr
    if w_prev is not None and tc_cost > 0:
        obj = obj + tc_cost * cp.norm1(w - w_prev)

    prob = cp.Problem(cp.Minimize(obj), [
        cp.sum(w) == 1,
        w >= W_MIN, w <= W_MAX,
        u >= 0, u >= losses - nu,
    ])
    prob.solve(solver=cp.CLARABEL, verbose=False)

    if prob.status not in ["optimal", "optimal_inaccurate"] or w.value is None:
        log.warning(f"CVaR portfolio: status={prob.status}. Using Markowitz fallback.")
        return solve_markowitz(mu, Sigma, lam1, w_prev, tc_cost)

    return np.maximum(w.value, 0)


# ---------------------------------------------------------------------------
# Model E: Full model -- MIQP with cardinality (CVXPY + ECOS_BB)
# ---------------------------------------------------------------------------

def solve_full_miqp(mu: np.ndarray, Sigma: np.ndarray,
                     R_scenarios: np.ndarray,
                     K: int = CARDINALITY_K,
                     lam1: float = LAMBDA1,
                     lam2: float = LAMBDA2,
                     lam3: float = LAMBDA3,
                     alpha: float = ALPHA_CVAR,
                     w_prev: np.ndarray = None,
                     tc_cost: float = TC_COST) -> np.ndarray:
    """
    Two-Stage MILP+QP: cardinality-constrained, CVaR-penalised, TC-penalised.
    Uses two-stage HiGHS (MILP cardinality selection) + CLARABEL (continuous QP).
    Binary selection variables z_i in {0,1}: z_i=1 iff asset i is selected (sum_i z_i <= K).
    Continuous weight w_i on selected assets optimized with exact CVaR and covariance.
    """
    try:
        import cvxpy as cp
    except ImportError:
        return np.ones(len(mu)) / len(mu)

    N = len(mu)
    T = max(len(R_scenarios), 1)
    if w_prev is None:
        w_prev = np.ones(N) / N

    # Stage 1: HiGHS MILP for cardinality asset selection
    z = cp.Variable(N, boolean=True)
    w_lin = cp.Variable(N, nonneg=True)
    nu = cp.Variable()
    u  = cp.Variable(T)
    losses = (-R_scenarios @ w_lin) if T > 1 else cp.Constant(np.zeros(1))
    cvar_expr = nu + (1.0 / ((1 - alpha) * T)) * cp.sum(u)
    tc_expr   = tc_cost * cp.norm1(w_lin - w_prev)
    diag_var  = np.diag(Sigma)

    obj_milp = (-mu @ w_lin
                + lam1 * (diag_var @ w_lin)
                + lam2 * cvar_expr
                + lam3 * tc_expr)
    constraints_milp = [
        cp.sum(w_lin) == 1,
        cp.sum(z) <= K,
        w_lin >= W_MIN * z,
        w_lin <= W_MAX * z,
    ]
    if T > 1:
        constraints_milp += [u >= 0, u >= losses - nu]

    prob_milp = cp.Problem(cp.Minimize(obj_milp), constraints_milp)
    try:
        prob_milp.solve(solver=cp.HIGHS, verbose=False)
        selected = np.where(z.value > 0.5)[0] if z.value is not None else np.argsort(mu)[-K:]
    except Exception:
        selected = np.argsort(mu)[-K:]

    if len(selected) == 0:
        selected = np.argsort(mu)[-K:]

    # Stage 2: Exact continuous CVaR + variance QP on selected K assets with CLARABEL
    N_sub = len(selected)
    w_sub = cp.Variable(N_sub, nonneg=True)
    nu2   = cp.Variable()
    u2    = cp.Variable(T)
    R_sub = R_scenarios[:, selected] if T > 1 else np.zeros((1, N_sub))
    losses2 = (-R_sub @ w_sub) if T > 1 else cp.Constant(np.zeros(1))
    cvar_expr2 = nu2 + (1.0 / ((1 - alpha) * T)) * cp.sum(u2)
    Sig_sub = Sigma[np.ix_(selected, selected)]
    mu_sub  = mu[selected]
    w_prev_sub = w_prev[selected]
    tc_expr2 = tc_cost * cp.norm1(w_sub - w_prev_sub)

    obj_qp = (-mu_sub @ w_sub
              + lam1 * cp.quad_form(w_sub, cp.psd_wrap(Sig_sub))
              + lam2 * cvar_expr2
              + lam3 * tc_expr2)
    constraints_qp = [
        cp.sum(w_sub) == 1,
        w_sub >= W_MIN,
        w_sub <= W_MAX,
    ]
    if T > 1:
        constraints_qp += [u2 >= 0, u2 >= losses2 - nu2]

    prob_qp = cp.Problem(cp.Minimize(obj_qp), constraints_qp)
    prob_qp.solve(solver=cp.CLARABEL, verbose=False)

    w_final = np.zeros(N)
    if prob_qp.status in ["optimal", "optimal_inaccurate"] and w_sub.value is not None:
        w_final[selected] = np.maximum(w_sub.value, 0)
        if w_final.sum() > 0:
            w_final /= w_final.sum()
    else:
        w_final[selected] = 1.0 / len(selected)

    return w_final


# ---------------------------------------------------------------------------
# Benchmarks
# ---------------------------------------------------------------------------

def equal_weight(N: int) -> np.ndarray:
    return np.ones(N) / N


def risk_parity(Sigma: np.ndarray) -> np.ndarray:
    """Risk-parity via iterative marginal risk contribution equalisation."""
    N = Sigma.shape[0]
    w = np.ones(N) / N
    for _ in range(500):
        sigma_p = np.sqrt(w @ Sigma @ w)
        mrc     = Sigma @ w / sigma_p
        rcs     = w * mrc
        target  = rcs.mean()
        w_new   = w * (target / np.maximum(rcs, 1e-8))
        w_new  /= w_new.sum()
        if np.max(np.abs(w_new - w)) < 1e-6:
            break
        w = w_new
    return np.clip(w, W_MIN, W_MAX)


def simulated_annealing(mu: np.ndarray, Sigma: np.ndarray,
                         w_prev: np.ndarray = None,
                         n_iter: int = 500,
                         seed: int = 42) -> np.ndarray:
    """SA to minimise negative Sharpe (crude approximation)."""
    np.random.seed(seed)
    N = len(mu)
    if w_prev is None:
        w_prev = np.ones(N) / N

    def objective(w):
        ret = mu @ w
        vol = np.sqrt(w @ Sigma @ w)
        return -(ret / (vol + 1e-8))

    w = w_prev.copy()
    best_w = w.copy()
    best_obj = objective(w)
    T = 1.0

    for it in range(n_iter):
        T = 1.0 * np.exp(-3 * it / n_iter)   # cooling
        # Propose: perturb two weights
        i, j = np.random.choice(N, 2, replace=False)
        delta = np.random.uniform(0, min(0.05, w[i]))
        w_new = w.copy()
        w_new[i] -= delta
        w_new[j] += delta
        w_new = np.clip(w_new, W_MIN, W_MAX)
        w_new /= w_new.sum()

        dE = objective(w_new) - objective(w)
        if dE < 0 or np.random.rand() < np.exp(-dE / (T + 1e-10)):
            w = w_new
            if objective(w) < best_obj:
                best_w   = w.copy()
                best_obj = objective(w)

    return np.maximum(best_w, 0)


def genetic_algorithm(mu: np.ndarray, Sigma: np.ndarray,
                       K: int = CARDINALITY_K,
                       seed: int = 42) -> np.ndarray:
    """GA portfolio optimisation using DEAP."""
    try:
        import random
        from deap import base, creator, tools, algorithms
    except ImportError:
        log.warning("DEAP not installed -- GA skipped, returning EW.")
        return equal_weight(len(mu))

    random.seed(seed)
    np.random.seed(seed)
    N = len(mu)

    if not hasattr(creator, "FitnessMin_PO"):
        creator.create("FitnessMin_PO", base.Fitness, weights=(-1.0,))
        creator.create("Individual_PO", list, fitness=creator.FitnessMin_PO)

    def random_portfolio():
        sel = np.random.choice(N, K, replace=False)
        w   = np.zeros(N)
        w[sel] = np.random.dirichlet(np.ones(K))
        return list(w)

    def evaluate(individual):
        w = np.array(individual)
        w = np.clip(w, 0, W_MAX)
        w = w / w.sum() if w.sum() > 0 else np.ones(N) / N
        ret = mu @ w
        vol = np.sqrt(w @ Sigma @ w)
        return (-(ret / (vol + 1e-8)),)

    toolbox = base.Toolbox()
    toolbox.register("individual", tools.initIterate, creator.Individual_PO, random_portfolio)
    toolbox.register("population", tools.initRepeat, list, toolbox.individual)
    toolbox.register("evaluate",   evaluate)
    toolbox.register("mate",       tools.cxBlend, alpha=0.3)
    toolbox.register("mutate",     tools.mutGaussian, mu=0, sigma=0.02, indpb=0.2)
    toolbox.register("select",     tools.selTournament, tournsize=5)

    pop = toolbox.population(n=40)
    algorithms.eaSimple(pop, toolbox, cxpb=0.6, mutpb=0.3, ngen=25, verbose=False)

    best = tools.selBest(pop, 1)[0]
    w = np.array(best)
    w = np.clip(w, 0, W_MAX)
    w = w / w.sum() if w.sum() > 0 else equal_weight(N)
    return w


# ---------------------------------------------------------------------------
# Main walk-forward loop
# ---------------------------------------------------------------------------

def main():
    log.info("=" * 70)
    log.info("Phase 7: Classical Portfolio Optimisation (All Models)")
    log.info("=" * 70)

    forecasts = load_forecasts("Ensemble")
    regimes   = load_regimes()
    returns   = pd.read_csv(DATA_PROC / "returns.csv", index_col=0, parse_dates=True)

    formation_dates = sorted(forecasts["date"].unique())
    log.info(f"Rebalancing dates: {len(formation_dates)} months "
             f"({pd.to_datetime(formation_dates[0]).date()} -> "
             f"{pd.to_datetime(formation_dates[-1]).date()})")

    # Models to run
    models = ["A_HistMean_MV", "B_Factor_MV", "C_FactorRegime_MV",
              "D_FactorRegime_CVaR", "E_Full_MIQP",
              "EW", "RP", "SA", "GA"]

    all_weights = {m: [] for m in models}

    prev_weights_map = {}   # dict: model -> dict of {ticker: weight}

    for idx, date in enumerate(formation_dates):
        date = pd.to_datetime(date)

        # Load covariance
        Sigma, tickers = load_covariance(date, cov_type="lw")
        if Sigma is None or len(tickers) < 5:
            log.warning(f"  No covariance for {date.date()} -- skip")
            continue

        N = len(tickers)

        # Expected returns from forecasts
        fc_date  = forecasts[forecasts["date"] == date]
        fc_map   = dict(zip(fc_date["ticker"], fc_date["predicted_return"]))
        mu_factor = np.array([fc_map.get(t, np.nan) for t in tickers])

        # Historical mean
        hist_ret = returns.loc[returns.index < date, tickers].iloc[-252:]
        mu_hist  = hist_ret.mean().reindex(tickers).fillna(0).values * 252

        # Fill missing factor forecasts with historical mean
        mu_factor_filled = np.where(np.isnan(mu_factor), mu_hist, mu_factor * 12)  # annualised

        # Regime-adjusted mu
        mu_regime = regime_adjust_mu(mu_factor_filled, date, regimes)

        # CVaR scenarios
        scenarios = load_returns_for_scenarios(date, tickers)

        # Previous weights (for TC) aligned by ticker
        def get_prev(model):
            if model not in prev_weights_map:
                return np.ones(N) / N
            p_dict = prev_weights_map[model]
            w_p = np.array([p_dict.get(t, 0.0) for t in tickers])
            s = w_p.sum()
            return w_p / s if s > 0 else np.ones(N) / N

        results = {}

        # Model A
        results["A_HistMean_MV"] = solve_markowitz(mu_hist, Sigma)

        # Model B
        results["B_Factor_MV"] = solve_markowitz(mu_factor_filled, Sigma,
                                                    w_prev=get_prev("B_Factor_MV"),
                                                    tc_cost=TC_COST)

        # Model C
        results["C_FactorRegime_MV"] = solve_markowitz(mu_regime, Sigma,
                                                         w_prev=get_prev("C_FactorRegime_MV"),
                                                         tc_cost=TC_COST)

        # Model D
        if len(scenarios) > 20:
            results["D_FactorRegime_CVaR"] = solve_cvar_portfolio(
                mu_regime, Sigma, scenarios,
                w_prev=get_prev("D_FactorRegime_CVaR"), tc_cost=TC_COST)
        else:
            results["D_FactorRegime_CVaR"] = results["C_FactorRegime_MV"].copy()

        # Model E
        if len(scenarios) > 20:
            results["E_Full_MIQP"] = solve_full_miqp(
                mu_regime, Sigma, scenarios, K=min(CARDINALITY_K, N),
                w_prev=get_prev("E_Full_MIQP"), tc_cost=TC_COST)
        else:
            results["E_Full_MIQP"] = results["D_FactorRegime_CVaR"].copy()

        # Benchmarks
        results["EW"] = equal_weight(N)
        results["RP"] = risk_parity(Sigma)
        results["SA"] = simulated_annealing(mu_regime, Sigma, get_prev("SA"))
        results["GA"] = genetic_algorithm(mu_regime, Sigma)

        # Store weights
        for model, w in results.items():
            rec = {"date": date}
            for i, t in enumerate(tickers):
                rec[t] = round(float(w[i]), 6)
            all_weights[model].append(rec)
            prev_weights_map[model] = dict(zip(tickers, w))

        if idx % 12 == 0 or idx == len(formation_dates) - 1:
            log.info(f"  [{date.date()}] Period {idx+1}/{len(formation_dates)} -- All 9 models solved")

    # Save
    for model, records in all_weights.items():
        if records:
            df = pd.DataFrame(records).fillna(0)
            df.to_csv(RESULTS / f"classical_weights_{model}.csv", index=False)
            log.info(f"  Saved: classical_weights_{model}.csv ({len(df)} dates)")

    log.info("\n[OK] Classical optimisation complete.")


if __name__ == "__main__":
    main()
