"""
05_covariance.py
================
Robust covariance estimation for portfolio optimisation.

Three estimators:
  1. Sample covariance (maximum likelihood)
  2. Ledoit-Wolf linear shrinkage (sklearn)
  3. EWMA (exponentially weighted)

All estimated on TRAINING data only at each rebalancing date.
Results are annualised (multiplied by 252).

Outputs:
  - Data/processed/cov_sample_{date}.npy   : (NxN) arrays per date
  - Data/processed/cov_lw_{date}.npy
  - Data/processed/cov_ewma_{date}.npy
  - Data/processed/cov_metadata.csv        : dates and ticker lists
  - Logs/05_covariance.log

Note: These files are large for many dates. We store only month-end estimates.
"""

import sys
import logging
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.covariance import LedoitWolf

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
LOG_DIR   = ROOT / "Logs"
COV_DIR   = DATA_PROC / "covariances"
COV_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "05_covariance.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

TRAIN_WINDOW_DAYS = 504   # ~2 years of trading days for estimation
EWMA_LAMBDA       = 0.94  # RiskMetrics decay factor
MIN_ASSETS        = 5     # minimum tickers with full data in window


def ewma_covariance(returns: np.ndarray, lam: float = EWMA_LAMBDA) -> np.ndarray:
    """Compute EWMA covariance matrix.
    Returns annualised covariance (252 x EWMA daily cov).
    """
    T, N = returns.shape
    # Exponential weights (most recent has highest weight)
    weights = np.array([(1 - lam) * lam ** (T - 1 - t) for t in range(T)])
    weights /= weights.sum()

    mean_r = np.average(returns, axis=0, weights=weights)
    demeaned = returns - mean_r

    cov = np.zeros((N, N))
    for t in range(T):
        cov += weights[t] * np.outer(demeaned[t], demeaned[t])
    return cov * 252


def estimate_covariances(returns_daily: pd.DataFrame,
                          formation_dates: pd.DatetimeIndex) -> pd.DataFrame:
    """
    For each formation date, estimate three covariance matrices on
    data strictly before that date.
    """
    meta_records = []

    for date in formation_dates:
        mask = returns_daily.index < date
        hist = returns_daily.loc[mask].iloc[-TRAIN_WINDOW_DAYS:]

        # Drop tickers with > 10% missing in the window
        pct_missing = hist.isna().mean()
        good_cols   = pct_missing[pct_missing < 0.10].index.tolist()
        hist_clean  = hist[good_cols].dropna()

        if len(good_cols) < MIN_ASSETS or len(hist_clean) < 60:
            log.warning(f"  {date.date()}: insufficient data ({len(good_cols)} tickers, "
                        f"{len(hist_clean)} days) -- skipping")
            continue

        R = hist_clean.values  # (T, N)

        # 1. Sample covariance (annualised)
        cov_sample = np.cov(R, rowvar=False) * 252

        # 2. Ledoit-Wolf shrinkage (annualised)
        lw = LedoitWolf(assume_centered=False)
        lw.fit(R)
        cov_lw = lw.covariance_ * 252

        # 3. EWMA
        cov_ewma = ewma_covariance(R, EWMA_LAMBDA)

        # Save
        date_str = date.strftime("%Y%m%d")
        np.save(COV_DIR / f"cov_sample_{date_str}.npy", cov_sample)
        np.save(COV_DIR / f"cov_lw_{date_str}.npy",     cov_lw)
        np.save(COV_DIR / f"cov_ewma_{date_str}.npy",   cov_ewma)

        meta_records.append({
            "date":          date,
            "n_assets":      len(good_cols),
            "n_obs":         len(hist_clean),
            "tickers_json":  json.dumps(good_cols),
            "lw_shrinkage":  round(float(lw.shrinkage_), 4),
        })

        if len(meta_records) % 12 == 0:
            log.info(f"  {date.date()}: {len(good_cols)} assets, "
                     f"LW shrinkage={lw.shrinkage_:.4f}")

    meta_df = pd.DataFrame(meta_records)
    return meta_df


def main():
    log.info("=" * 70)
    log.info("Phase 5: Covariance Estimation (Sample / LW / EWMA)")
    log.info("=" * 70)

    ret_path = DATA_PROC / "returns.csv"
    if not ret_path.exists():
        log.error("returns.csv not found. Run 01_data_pipeline.py first.")
        sys.exit(1)

    returns = pd.read_csv(ret_path, index_col=0, parse_dates=True)

    # Formation dates = month-ends in the data
    monthly_idx    = returns.resample("ME").last().index
    formation_dates = monthly_idx[monthly_idx >= returns.index.min() +
                                   pd.Timedelta(days=TRAIN_WINDOW_DAYS + 60)]

    log.info(f"Estimating covariances for {len(formation_dates)} month-end dates "
             f"({formation_dates[0].date()} -> {formation_dates[-1].date()})")

    meta_df = estimate_covariances(returns, formation_dates)
    meta_df.to_csv(DATA_PROC / "cov_metadata.csv", index=False)

    log.info(f"\n[OK] Covariance matrices saved to: {COV_DIR}")
    log.info(f"[OK] Metadata: {DATA_PROC / 'cov_metadata.csv'}")
    log.info(f"  Dates with estimates: {len(meta_df)}")
    log.info(f"  Avg assets per date : {meta_df['n_assets'].mean():.1f}")
    log.info(f"  Avg LW shrinkage    : {meta_df['lw_shrinkage'].mean():.4f}")


if __name__ == "__main__":
    main()
