from pathlib import Path
import re

def clean_field_val(val):
    val = val.strip()
    if val.endswith(','):
        val = val[:-1].strip()
    if (val.startswith('{') and val.endswith('}')) or (val.startswith('"') and val.endswith('"')):
        val = val[1:-1].strip()
    return val

def parse_bib_entry(entry_type, key, body):
    entry = {'key': key.strip(), 'type': entry_type.strip().lower()}
    lines = body.split('\n')
    cur_field = None
    cur_val = []
    
    for line in lines:
        line_s = line.strip()
        m = re.match(r'^(\w+)\s*=\s*(.*)$', line_s)
        if m:
            if cur_field:
                entry[cur_field] = clean_field_val(' '.join(cur_val))
            cur_field = m.group(1).lower()
            cur_val = [m.group(2)]
        else:
            if cur_field:
                cur_val.append(line_s)
    if cur_field:
        entry[cur_field] = clean_field_val(' '.join(cur_val))
    return entry

text = Path('RIBAF_Submission/LaTeX/references.bib').read_text(encoding='utf-8')
entries = re.findall(r'@(\w+)\s*\{\s*([^,]+),([\s\S]*?)\n\}', text)
parsed = [parse_bib_entry(t, k, b) for t, k, b in entries]

with_doi = [e for e in parsed if e.get('doi')]
print(f'Total parsed: {len(parsed)}')
print(f'With DOI: {len(with_doi)}')
print(f'Without DOI: {len(parsed) - len(with_doi)}')
for e in parsed:
    if not e.get('doi'):
        print('  Missing DOI:', e['key'], 'Title:', e.get('title'))
