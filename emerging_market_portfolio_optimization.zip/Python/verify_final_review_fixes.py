import pypdf
import re
import os

def check_text(pdf_path):
    reader = pypdf.PdfReader(pdf_path)
    full_text = ''
    for i, p in enumerate(reader.pages):
        full_text += f'\n--- PAGE {i+1} ---\n' + p.extract_text()
    return len(reader.pages), full_text

# 1. Main Manuscripts Verification
manuscripts = [
    r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\main.pdf',
    r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\Manuscript\main.pdf',
    r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\Manuscript\manuscript.pdf',
    r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\Manuscript\Manuscript_Without_Author_Details.pdf',
    r'd:\Quantum finance\22_09_2026\Submission_Package\Manuscript\main.pdf',
    r'd:\Quantum finance\22_09_2026\Submission_Package\Manuscript\manuscript.pdf',
    r'd:\Quantum finance\22_09_2026\Submission_Package\Manuscript\Manuscript_Without_Author_Details.pdf',
]

print('=== CHECKING ALL MANUSCRIPT PDFS ===')
forbidden_main = [
    'Algorithmic Dominance',
    'mitigates drawdowns prior to market contractions',
    'significantly compresses realized out-of-sample tail losses',
    'among all active strategies',
    'under 0.5 seconds',
    'competing portfolio models'
]

required_main = [
    'statistically detectable out-of-sample directional predictability under realistic information-availability lags',
    'Conditioning expected returns on latent Markov states changes portfolio exposures',
    'Incorporating coherent CVaR into the portfolio objective changes the portfolio',
    'Net Economic Value and Computational Benchmarking',
    'Explicit turnover penalization affects net portfolio performance after transaction costs',
    'benchmark-adjusted Sharpe ratio of 0.8389 relative to a standardized 14%',
    'lowest in-sample optimized 95% CVaR among Models A',
    'close to the 14.08% observed for Model D',
    'Throughout the study, the term Sharpe ratio refers to the annualized excess-return ratio calculated relative to the standardized 14% annual benchmark hurdle',
    'A reduced 12-qubit combinatorial benchmark is evaluated using QAOA and VQE under simulated noisy-circuit conditions. Classical exact search solves the investigated benchmark rapidly, and no quantum computational advantage is observed under the tested simulation conditions.'
]

for m_path in manuscripts:
    pages, text = check_text(m_path)
    print(f'\nChecking {os.path.basename(m_path)} ({pages} pages) in {os.path.dirname(m_path)}:')
    
    # Check forbidden
    any_forbidden = False
    for phrase in forbidden_main:
        if phrase.lower() in text.lower():
            print(f'  FAIL: Found forbidden phrase "{phrase}"')
            any_forbidden = True
    if not any_forbidden:
        print('  PASS: All forbidden phrases absent')
        
    # Check required
    norm_text = ' '.join(text.split()).lower()
    all_required = True
    for phrase in required_main:
        norm_phrase = ' '.join(phrase.split()).lower()
        if norm_phrase not in norm_text:
            print(f'  FAIL: Missing required phrase "{phrase[:50]}..."')
            all_required = False
    if all_required:
        print('  PASS: All required phrases present (including updated quantum abstract and hypotheses)')

# 2. Cover Letter Verification
print('\n=== CHECKING COVER LETTERS ===')
cl_path = r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\cover_letter.pdf'
pages_cl, text_cl = check_text(cl_path)
print(f'Checking {cl_path} ({pages_cl} pages):')
norm_text_cl = ' '.join(re.sub(r'-\s+', '', text_cl).split()).lower()

if 'nine competing models' in norm_text_cl:
    print('  FAIL: Found "nine competing models"')
else:
    print('  PASS: "nine competing models" absent')

if 'under 0.5 seconds' in norm_text_cl:
    print('  FAIL: Found "under 0.5 seconds"')
else:
    print('  PASS: "under 0.5 seconds" absent')

if 'demonstrating the risk-return-turnover trade-offs across nine evaluated portfolio strategies'.lower() in norm_text_cl:
    print('  PASS: Found "demonstrating the risk-return-turnover trade-offs across nine evaluated portfolio strategies"')
else:
    print('  FAIL: Missing "demonstrating the risk-return-turnover trade-offs across nine evaluated portfolio strategies"')

# 3. Title Page Verification
print('\n=== CHECKING TITLE PAGES ===')
title_pages = [
    r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\title_page.pdf',
    r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\Title_Page\title_page.pdf',
    r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\Title_Page\Title_Page_with_Author_Details.pdf',
    r'd:\Quantum finance\22_09_2026\Submission_Package\Title_Page\title_page.pdf',
    r'd:\Quantum finance\22_09_2026\Submission_Package\Title_Page\Title_Page_with_Author_Details.pdf'
]

for tp_path in title_pages:
    pages_tp, text_tp = check_text(tp_path)
    norm_tp = ' '.join(text_tp.split()).lower()
    has_correct_title = 'factor- and regime-informed portfolio optimization under tail risk and transaction costs in an emerging market' in norm_tp
    has_old_title = 'hybrid quantum-classical framework for borsa istanbul' in norm_tp
    print(f'{os.path.basename(tp_path)} ({pages_tp} pages) in {os.path.dirname(tp_path)}: CorrectTitle={has_correct_title}, HasOldTitle={has_old_title}')

# 4. Graphical Abstract Verification
print('\n=== CHECKING GRAPHICAL ABSTRACTS ===')
ga_pages = [
    r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\graphical_abstract.pdf',
    r'd:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\Graphical_Abstract\graphical_abstract.pdf',
    r'd:\Quantum finance\22_09_2026\Submission_Package\Graphical_Abstract\graphical_abstract.pdf'
]

for ga_path in ga_pages:
    pages_ga, text_ga = check_text(ga_path)
    norm_ga = ' '.join(text_ga.split()).lower()
    has_correct_title = 'factor- and regime-informed portfolio optimization under tail risk and transaction costs in an emerging market' in norm_ga
    has_old_title = 'hybrid quantum-classical framework for borsa istanbul' in norm_ga
    has_quarterly = '1.7345' in norm_ga
    print(f'{os.path.basename(ga_path)} ({pages_ga} pages): CorrectTitle={has_correct_title}, HasOldTitle={has_old_title}, HasQuarterly={has_quarterly}')

print('\nALL CHECKS COMPLETED.')
