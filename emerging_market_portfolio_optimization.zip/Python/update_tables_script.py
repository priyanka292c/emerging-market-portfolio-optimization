# -*- coding: utf-8 -*-
import os
import re

BASE_DIRS = [
    r'D:\Quantum finance\22_09_2026\RIBAF_Submission\LaTeX',
    r'D:\Quantum finance\22_09_2026\LaTeX'
]

# Update Tables 10, 15, and 16
for base_dir in BASE_DIRS:
    td = os.path.join(base_dir, 'tables')
    
    # Table 10
    t10_path = os.path.join(td, 'table10_portfolio_performance.tex')
    with open(t10_path, 'r', encoding='utf-8') as f:
        t10 = f.read()
    t10 = t10.replace('Sharpe & Sortino', '14\\%-Hurdle Sharpe & Sortino')
    t10 = t10.replace(
        'Transaction costs are modeled as a baseline proportional execution-cost assumption of 20 bps',
        'Crucially, Model~E does not dominate passive benchmarks on realized tail risk or drawdown: Equal Weight and Risk Parity achieve lower realized CVaR (10.68% and 10.25%) and lower maximum drawdown (24.75% and 23.10%). Model~E trades return and realized drawdown for cardinality-constrained implementation (K <= 10) and explicit formation tail-risk optimization. Transaction costs are modeled as a baseline proportional execution-cost assumption of 20 bps'
    )
    with open(t10_path, 'w', encoding='utf-8') as f:
        f.write(t10)
        
    # Table 15
    t15_path = os.path.join(td, 'table15_robustness.tex')
    with open(t15_path, 'r', encoding='utf-8') as f:
        t15 = f.read()
    t15 = t15.replace('Quarterly (\\Delta t = 3\\text{ mo}, N = 49) & Model E (Two-Stage MILP--Conic) & 1.7345',
                      'Quarterly (\\Delta t = 3\\text{ mo}, N = 49) & Model E (Two-Stage MILP--Conic) & 0.7647 (CAGR 41.14\\%, Vol 37.72\\%, MDD 27.08\\%)')
    t15 = t15.replace('Semi-annual (\\Delta t = 6\\text{ mo}, N = 24) & Model E (Two-Stage MILP--Conic) & 2.6258',
                      'Semi-annual (\\Delta t = 6\\text{ mo}, N = 24) & Model E (Two-Stage MILP--Conic) & 0.7721 (CAGR 40.17\\%, Vol 37.84\\%, MDD 21.04\\%)')
    t15 = t15.replace('Monthly (\\Delta t = 1\\text{ mo}, N = 147) & Model E (Two-Stage MILP--Conic) & 0.8389',
                      'Monthly (\\Delta t = 1\\text{ mo}, N = 147) & Model E (Two-Stage MILP--Conic) & 0.8389 (CAGR 41.14\\%, Vol 31.75\\%, MDD 37.24\\%)')
    with open(t15_path, 'w', encoding='utf-8') as f:
        f.write(t15)

    # Table 16
    t16_path = os.path.join(td, 'table16_ablation_study.tex')
    with open(t16_path, 'r', encoding='utf-8') as f:
        t16 = f.read()
    t16 = t16.replace('Systematic Component Ablation Study -- Incremental Economic and Risk Contribution',
                      'Incremental Specification Comparison -- Portfolio Characteristics Across Sequential Constraints and Algorithmic Benchmarks')
    t16 = t16.replace('Algorithmic Optimization Benchmarks on Screened Combinatorial Subproblem ( = 4$ Assets,  = 12$ Qubits)',
                      'Algorithmic Optimization Benchmarks on Reduced Combinatorial Surrogate ( = 4$ Assets,  = 12$ Qubits, {\\max} = 0.25$)')
    with open(t16_path, 'w', encoding='utf-8') as f:
        f.write(t16)

print('Updated Tables 10, 15, and 16 successfully.')
