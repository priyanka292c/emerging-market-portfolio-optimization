import matplotlib.pyplot as plt
import matplotlib.patches as patches
import numpy as np
import os

# Set style
plt.style.use('seaborn-v0_8-whitegrid' if 'seaborn-v0_8-whitegrid' in plt.style.available else 'default')
fig = plt.figure(figsize=(16, 9), dpi=300)

# Background color
fig.patch.set_facecolor('#F8F9FA')

ax = fig.add_axes([0, 0, 1, 1])
ax.axis('off')

# Title Banner - EXACT MANUSCRIPT TITLE
title_box = patches.FancyBboxPatch((0.02, 0.88), 0.96, 0.10, boxstyle="round,pad=0.01",
                                  facecolor='#0A2540', edgecolor='none')
ax.add_patch(title_box)

ax.text(0.50, 0.948, "Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market",
        color='white', fontsize=14.5, fontweight='bold', ha='center', va='center')
ax.text(0.50, 0.905, "An Integrated Allocation Architecture: Point-in-Time Factors, Regime Filtering, Rockafellar--Uryasev CVaR & Two-Stage Optimization",
        color='#639FAB', fontsize=11.5, ha='center', va='center', style='italic')

# Colors for Panels
c_data = '#E3F2FD'
c_data_border = '#1976D2'
c_ml = '#E8F5E9'
c_ml_border = '#388E3C'
c_opt = '#FFF3E0'
c_opt_border = '#F57C00'
c_quant = '#EDE7F6'
c_quant_border = '#512DA8'
c_res = '#ECEFF1'
c_res_border = '#37474F'

# Panel 1: Data & Point-in-Time Factors
p1 = patches.FancyBboxPatch((0.02, 0.47), 0.22, 0.38, boxstyle="round,pad=0.01",
                            facecolor=c_data, edgecolor=c_data_border, linewidth=2)
ax.add_patch(p1)
ax.text(0.13, 0.82, "1. Empirical Foundation", fontsize=13, fontweight='bold', color=c_data_border, ha='center')
ax.text(0.13, 0.65, 
        "• Emerging Market Laboratory:\n"
        "  - Borsa Istanbul Core Equities\n"
        "  - 2010–July 2026 (4,257 Days)\n"
        "  - 147 Walk-Forward Folds\n"
        "• 6 Candidate Factors:\n"
        "  - Momentum (12-2M compound)\n"
        "  - Size, Volatility, Liquidity\n"
        "  - Value & Profitability\n"
        "    (sparse PIT coverage;\n"
        "     neutral median imputation)\n"
        "• Conservative 60-Day KAP Lag\n"
        "  (Aligned with CMB/SPK\n"
        "   reporting framework)",
        fontsize=9.5, color='#1A237E', va='center', ha='center', linespacing=1.35)

# Panel 2: ML & Regime Filtering
p2 = patches.FancyBboxPatch((0.26, 0.47), 0.22, 0.38, boxstyle="round,pad=0.01",
                            facecolor=c_ml, edgecolor=c_ml_border, linewidth=2)
ax.add_patch(p2)
ax.text(0.37, 0.82, "2. Predictive Regimes", fontsize=13, fontweight='bold', color=c_ml_border, ha='center')
ax.text(0.37, 0.65,
        "• Machine Learning Models:\n"
        "  - ElasticNet (DirAcc 56.86%)\n"
        "  - Random Forest (56.09%)\n"
        "  - XGBoost (55.10%)\n"
        "  Panel PT-Test: p < 10^-17\n\n"
        "• 4-State Gaussian HMM Regime Filter:\n"
        "  - Bear · Bull · Normal · Strong Bull\n"
        "  - Walk-forward filtered probabilities P(S_t|Y_1:t)\n"
        "  - No future observations used\n"
        "  147 OOS Folds / 161 Total HMM\n"
        "• Ledoit-Wolf Shrinkage:\n"
        "  Cond. No. 184.2 -> 48.6",
        fontsize=9.5, color='#1B5E20', va='center', ha='center', linespacing=1.35)

# Panel 3: Classical Two-Stage Optimization
p3 = patches.FancyBboxPatch((0.50, 0.47), 0.23, 0.38, boxstyle="round,pad=0.01",
                            facecolor=c_opt, edgecolor=c_opt_border, linewidth=2)
ax.add_patch(p3)
ax.text(0.615, 0.82, "3. Two-Stage Engine", fontsize=13, fontweight='bold', color=c_opt_border, ha='center')
ax.text(0.615, 0.65,
        "• Two-Stage Decomposition:\n"
        "  Stage 1: HiGHS MILP Selection\n"
        "  - Cardinality: K <= 10 assets\n"
        "  - Factor return drift & penalties\n\n"
        "  Stage 2: CLARABEL Conic Optimizer\n"
        "  - Exact empirical CVaR (alpha=0.95)\n"
        "    Rockafellar-Uryasev formulation\n"
        "  - Proportional TC: c = 20 bps\n"
        "  - Ledoit-Wolf shrinkage risk\n"
        "  - Strict continuous w_max = 0.20\n"
        "• Primal Feasibility Verified\n"
        "  in Monthly Workflow",
        fontsize=9.5, color='#E65100', va='center', ha='center', linespacing=1.35)

# Panel 4: Reduced Combinatorial Quantum Benchmark
p4 = patches.FancyBboxPatch((0.75, 0.47), 0.23, 0.38, boxstyle="round,pad=0.01",
                            facecolor=c_quant, edgecolor=c_quant_border, linewidth=2)
ax.add_patch(p4)
ax.text(0.865, 0.82, "4. Quantum Benchmark", fontsize=13, fontweight='bold', color=c_quant_border, ha='center')
ax.text(0.865, 0.65,
        "• Controlled 12-Qubit Quantum Surrogate:\n"
        "  - 4 candidate assets x 3 bits\n"
        "  - M = 12 Logical Qubits (4,096 States)\n"
        "  - Classical exact enumeration vs QAOA/VQE\n\n"
        "• Quantum Algorithms Evaluated:\n"
        "  - QAOA (depths p = 1, 2, 3)\n"
        "  - VQE (TwoLocal ansatz)\n"
        "  - Qiskit Aer noisy-circuit sim.\n\n"
        "• Computational Benchmarking:\n"
        "  - Exact enumeration solves all\n"
        "    4,096 states in 20 ms\n"
        "  - No quantum computational advantage\n"
        "    was observed for the investigated\n"
        "    12-qubit instances under the tested\n"
        "    simulation conditions",
        fontsize=9.5, color='#311B92', va='center', ha='center', linespacing=1.35)

# Connecting Arrows
ax.annotate("", xy=(0.25, 0.66), xytext=(0.23, 0.66),
            arrowprops=dict(arrowstyle="->", color='#0A2540', lw=2.5))
ax.annotate("", xy=(0.49, 0.66), xytext=(0.47, 0.66),
            arrowprops=dict(arrowstyle="->", color='#0A2540', lw=2.5))
ax.annotate("", xy=(0.74, 0.66), xytext=(0.72, 0.66),
            arrowprops=dict(arrowstyle="->", color='#0A2540', lw=2.5))

# Bottom Panel: Key Empirical Findings & Scientific Conclusions
p5 = patches.FancyBboxPatch((0.02, 0.04), 0.96, 0.39, boxstyle="round,pad=0.01",
                            facecolor=c_res, edgecolor=c_res_border, linewidth=2)
ax.add_patch(p5)

ax.text(0.50, 0.39, "KEY EMPIRICAL OUTCOMES & SCIENTIFIC RIGOR", fontsize=14, fontweight='bold', color=c_res_border, ha='center')

# Sub-columns inside bottom panel
# Left subcolumn: Financial Performance
ax.text(0.24, 0.22,
        "MODEL E: RISK–RETURN–IMPLEMENTATION TRADE-OFF\n"
        "-----------------------------------------\n"
        "• Net Performance (20 bps one-way TC):\n"
        "  - 14%-Hurdle Sharpe Ratio: 0.8389\n"
        "  - Conventional risk-free proxy Sharpe: 0.7698\n"
        "  - Sortino = 1.6621 | Calmar = 1.1047 (CAGR/MDD)\n"
        "  - Geometric CAGR = 41.14% (Comp. Ret = 47.94%)\n"
        "  - Realized Volatility = 31.75%\n"
        "• Tail Risk & Cardinality Bounds (K <= 10):\n"
        "  - In-Sample 95% CVaR = 13.90% (lowest in A–E)\n"
        "  - Realized OOS 95% CVaR = 14.12% (close to D's 14.08%)\n"
        "• Implementation: Monthly Turnover = 90.05%\n"
        "  - Execution drag = 18.01 bps/mo (~2.16% p.a.)\n"
        "  (Models B/C achieve higher Sharpe without K bounds)\n"
        "-----------------------------------------\n"
        "*14% standardized annual hurdle vs conventional proxy.",
        fontsize=9.5, color='#263238', ha='center', va='center', linespacing=1.25, family='monospace')

# Right subcolumn: Methodological & Computational Rigor
ax.text(0.74, 0.22,
        "METHODOLOGICAL & COMPUTATIONAL RIGOR:\n"
        "-------------------------------------\n"
        "• Risk-Return Trade-Off: Tail-risk constraints\n"
        "  and cardinality compress left-tail loss while\n"
        "  preserving competitive net risk-adjusted returns.\n"
        "• Two-Stage Decomposition Heuristic:\n"
        "  Primal feasibility verified in workflow at each\n"
        "  monthly rebalancing fold without asserting\n"
        "  global master problem optimality.\n"
        "• Controlled 12-Qubit Benchmark (4 assets x 3 bits):\n"
        "  - Exact enumeration solves all 4,096 states in 20 ms.\n"
        "  - Classical exact enumeration vs QAOA/VQE;\n"
        "  - No quantum computational advantage was observed for the\n"
        "    investigated 12-qubit instances under the tested\n"
        "    simulation conditions.",
        fontsize=9.5, color='#263238', ha='center', va='center', linespacing=1.25, family='monospace')

# Save outputs to all target locations
output_dirs = [
    "Figures/pdf", "Figures/png",
    "LaTeX/figures", "LaTeX",
    "RIBAF_Submission/LaTeX/figures", "RIBAF_Submission/LaTeX",
    "RIBAF_Submission/Submission_PDFs", "RIBAF_Submission/Submission_PDFs/Graphical_Abstract",
    "Submission_Package/Graphical_Abstract"
]

for d in output_dirs:
    os.makedirs(d, exist_ok=True)

# Save high-res PDFs and PNGs
save_targets = [
    ("Figures/pdf/graphical_abstract.pdf", "pdf", 300),
    ("Figures/png/graphical_abstract.png", "png", 600),
    ("LaTeX/figures/graphical_abstract.pdf", "pdf", 300),
    ("LaTeX/figures/graphical_abstract.png", "png", 600),
    ("RIBAF_Submission/LaTeX/figures/graphical_abstract.pdf", "pdf", 300),
    ("RIBAF_Submission/LaTeX/figures/graphical_abstract.png", "png", 600),
    ("RIBAF_Submission/Submission_PDFs/graphical_abstract.pdf", "pdf", 300),
    ("RIBAF_Submission/Submission_PDFs/Graphical_Abstract/graphical_abstract.pdf", "pdf", 300),
    ("RIBAF_Submission/Submission_PDFs/Graphical_Abstract/graphical_abstract.png", "png", 600),
    ("Submission_Package/Graphical_Abstract/graphical_abstract.pdf", "pdf", 300),
    ("Submission_Package/Graphical_Abstract/graphical_abstract.png", "png", 600),
]

for path, fmt, dpi in save_targets:
    plt.savefig(path, bbox_inches='tight', dpi=dpi)
    print(f"Saved {path}")

print("Graphical abstract successfully generated everywhere.")
