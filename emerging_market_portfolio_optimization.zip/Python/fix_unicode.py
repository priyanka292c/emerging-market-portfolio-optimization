"""Fix ALL non-ASCII characters across all Python scripts."""
import pathlib

py_dir = pathlib.Path(r'd:/Quantum finance/22_09_2026/Python')

REPLACEMENTS = {
    '\u2713': '[OK]',
    '\u2717': '[FAIL]',
    '\u26a0': '[WARN]',
    '\u2714': '[OK]',
    '\u2718': '[FAIL]',
    '\u2192': '->',
    '\u2014': '--',
    '\u2013': '-',
    '\u2248': '~',
    '\u2260': '!=',
    '\u2264': '<=',
    '\u2265': '>=',
    '\u03bb': 'lambda',
    '\u03b1': 'alpha',
    '\u03b2': 'beta',
    '\u03b3': 'gamma',
    '\u03bc': 'mu',
    '\u03c3': 'sigma',
    '\u00d7': 'x',
    '\u0394': 'Delta_',
    '\u2208': 'in',
    '\u2022': '*',
    '\u2018': "'",
    '\u2019': "'",
    '\u201c': '"',
    '\u201d': '"',
    '\u00b1': '+/-',
}

files_fixed = []
for f in sorted(py_dir.glob('*.py')):
    if f.name == 'fix_unicode.py':
        continue
    text = f.read_text(encoding='utf-8')
    orig = text
    for bad, good in REPLACEMENTS.items():
        text = text.replace(bad, good)
    if text != orig:
        f.write_text(text, encoding='utf-8')
        files_fixed.append(f.name)

print('Fixed files:', files_fixed)
