# -*- coding: utf-8 -*-
import os
import re
import shutil
BASE_DIR = r'D:\Quantum finance\22_09_2026'

def replace_in_file(file_path, old_pattern, new_text, is_regex=False, count=0):
    if not os.path.exists(file_path):
        print(f'File not found: {file_path}')
        return False
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    if is_regex:
        new_content, n = re.subn(old_pattern, new_text, content, count=count, flags=re.DOTALL)
    else:
        n = content.count(old_pattern)
        new_content = content.replace(old_pattern, new_text)
    if n > 0:
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f'Updated {file_path}: {n} occurrence(s) replaced.')
        return True
    else:
        print(f'Pattern not found in {file_path}.')
        return False

# 1. Update main.tex
new_abstract = r'''\begin{abstract}
\noindent Portfolio allocation in emerging equity markets is complicated by structural regime shifts, non-Gaussian tail risk, and execution frictions. Existing literature often examines factor pricing, regime switching, Conditional Value-at-Risk (CVaR), and transaction costs separately, leaving their joint implementation under cardinality constraints less explored. We propose an integrated portfolio optimization architecture combining point-in-time multi-factor modeling, latent Markov regime conditioning, Ledoit--Wolf covariance shrinkage, empirical Rockafellar--Uryasev CVaR, and a two-stage decomposition heuristic using HiGHS MILP asset selection and Clarabel conic allocation. Borsa Istanbul provides an informative emerging-market setting characterized by macroeconomic volatility, currency shocks, and execution frictions. Using monthly walk-forward evaluation from 2014 to July 2026 with a conservative 60-calendar-day information-availability lag, Model E ($K  \\le 10$) delivers a geometric CAGR of 41.14\%, annualized volatility of 31.75\%, and a Sharpe ratio of 0.8389 relative to a standardized 14\% annual benchmark hurdle. Its in-sample optimized 95\% CVaR is 13.90\%, while realized out-of-sample CVaR is 14.12\%, with average monthly turnover of 90.05\$. A controlled 12-qubit benchmark shows no quantum computational advantage under the tested simulated conditions. The results highlight the risk-return and implementation trade-offs of integrated portfolio construction in emerging markets.
\end{abstract}'''
    
 data_avail_new = 'h\\section{*Data and Code Availability}\nReplication code and derived datasets will be made publicly available upon acceptance via an open-access repository. Restricted raw market inputs cannot be redistributed directly and will be reconstructible using the documented data-collection procedures.'

for sub in [r'RIBAF_Submission\LaTeX\main.tex', r'LaTeX\main.tex']:
    fp = os.path.join(BASE_DIR, sub)
    replace_in_file(fp, r'\\begin{ *abstract *}.*?\\end{ *abstract *}', new_abstract, is_regex=True)
    replace_in_file(fp,
        r'\\section\*{Data and Code Availability}\s*Replication code and derived datasets will be made publicly available upon acceptance\.\s*Restricted raw market inputs cannot be redistributed and will be reconstructible using the documented data-collection procedures\.',
        data_avail_new, is_regex=True)

# 2. Update sections/01_introduction.tex
for sub in [r'RIBAF_Submission\LaTeX\sections\01_introduction.tex', r'LaTeX\sections\01_introduction.tex']:
    fp = os.path.join(BASE_DIR, sub)
    replace_in_file(fp,
        'delivering verified numerical feasibility in under 0.5 seconds per rebalancing period.',
        'achieving verified primal feasibility in under 0.5 seconds per monthly rebalancing fold.')
    replace_in_file(fp,
        'We address the computational burden of the monolithic cardinality-constrained MIQP by designing a two-stage decomposition heuristic:',
        'We address the computational burden of the monolithic cardinality-constrained MIQP through a two-stage decomposition heuristic:')
    replace_in_file(fp,
        'explicitly documenting that classical exact search and mathematical programming achieve lower computational cost and exact solutions for the investigated reduced instances than the tested variational quantum methods, thereby providing an evidence-based benchmark dispelling premature claims of quantum advantage.',
        'explicitly documenting that classical exact enumeration and mathematical programming solve the investigated benchmark instances in milliseconds, whereas the tested variational quantum algorithms produce approximate solutions. No quantum computational advantage is observed under the tested simulation conditions.')

# 3. Update sections/07_practical_implications.tex
for sub in [r'RIBAF_Submission\LaTeX\sections\07_practical_implications.tex', r'LaTeX\sections\07_practical_implications.tex']:
    f` = os.path.join(BASE_DIR, sub)
    replace_in_file(fp,
        'Achieving verified numerical feasibility in under 0.5 seconds per rebalancing period',
        'Achieving verified primal feasibility in under 0.5 seconds per monthly rebalancing fold')
    replace_in_file(fp,
        'classical exact and mathematical solvers solve the combinatorial selection problem orders of magnitude faster and achieve lower computational cost and exact solutions for the investigated reduced instances than the tested variational quantum methods.',
        'classical exact enumeration and mathematical programming solve the investigated benchmark instances in milliseconds, whereas the tested variational quantum algorithms produce approximate solutions, with no quantum computational advantage observed under the tested simulation conditions.')

# 4. Update sections/09_conclusion.tex
for sub in [r'RIBAF_Submission\LaTeX\sections\09_conclusion.tex', r'LaTeX\sections\09_conclusion.tex']:
    f` = os.path.join(BASE_DIR, sub)
    replace_in_file(fp,
        'achieving the lowest in-sample optimized 95\\% CVaR among Models A--E (13.90\\%), while its realized out-of-sample CVaR is 14.12\%, close to ModelD's 14.08\%.',
        'achieving the lowest in-sample optimized 95\\%C CVaR among Models A--E at 13.90\\%\, while its realized out-of-sample CVaR is 14.12\\%.')
    replace_in_file(fp,
        'achieving the lowest in-sample 95\% CVaR (13.90\%) and realized out-of-sample tail loss (14.12\%) among the five primary Models A--E.',
        'achieving the lowest in-sample optimized 95\\% CVaR among Models A--E at 13.90\\%\, while its realized out-of-sample CVaR is 14.12\\%.')
    replace_in_file(fp,
        'Using a 16-year point-in-time dataset of Borsa Istanbul institutional equities spanning 2010 to 2026',
        'Using a point-in-time dataset of Borsa Istanbul institutional equities over the 2010--July 2026 sample')
    replace_in_file(fp,
        'Furthermore, classical exact enumeration and mathematical branch-and-cut solvers solve this benchmark globally in milliseconds. We find no evidence of quantum computational advantage on the investigated instances, framing variational algorithms as valuable algorithmic testbeds for studying Hamiltonian compilation and noise resilience rather than production advantage engines.',
        'Furthermore, classical exact enumeration and mathematical programming solve the investigated benchmark instances in milliseconds, whereas the tested variational quantum algorithms produce approximate solutions. No quantum computational advantage is observed under the tested simulation conditions, framing variational algorithms as valuable algorithmic testbeds for studying Hamiltonian compilation and noise resilience rather than production advantage engines.')

# 5. Update cover_letter.tex
for sub in [rRQIBAF_Submission\LaTeX@cover_letter.tex', r'LaTeX@cover_letter.tex']:
    fp = os.path.join(BASE_DIR, sub)
    replace_in_file(fp,
        'achieving verified numerical feasibility in $<0.5$ seconds per monthly rebalancing fold.',
        'achieving verified primal feasibility in under 0.5 seconds per monthly rebalancing fold.')
    replace_in_file(fp,
        'We address the computational burden of the monolithic cardinality-constrained MIQP by designing a two-stage decomposition heuristic',
        'We address the computational burden of the monolithic cardinality-constrained MIQP through a two-stage decomposition heuristic')
    replace_in_file(fp,
        'classical solvers achieve lower computational cost and exact solutions for the investigated reduced instances than the tested variational quantum methods, confirming that variational circuits currently serve as algorithmic testbeds rather than advantage engines, with no quantum computational advantage observed under the tested simulation conditions.',
        'classical exact enumeration and mathematical programming solve the investigated benchmark instances in milliseconds, whereas the tested variational quantum algorithms produce approximate solutions, with no quantum computational advantage observed under the tested simulation conditions.')
    replace_in_file(fp,
        'Replication code and derived datasets will be made publicly available upon acceptance. Restricted raw market inputs cannot be redistributed and will be reconstructible using the documented data-collection procedures.',
        'Replication code and derived datasets will be made publicly available upon acceptance via an open-access repository. Restricted raw market inputs cannot be redistributed directly and will be reconstructible using the documented data-collection procedures.')
    replace_in_file(fp, 'Roman OrAs', 'Roman Or\u00fas')

# 6. Update title_page.tex
for sub in [r'RIBAF_Submission\LaTeXtitle_page.tex', r'LaTeXtitle_page.tex']:
    f` = os.path.join(BASE_DIR, sub)
    replace_in_file(fp,
        'Replication code and derived datasets will be made publicly available upon acceptance. Restricted raw market inputs cannot be redistributed and will be reconstructible using the documented data-collection procedures.',
        'Replication code and derived datasets will be made publicly available upon acceptance via an open-access repository. Restricted raw market inputs cannot be redistributed directly and will be reconstructible using the documented data-collection procedures.')

# 7. Update table00_data_audit.tex
for sub in [r'RIBAF_Submission\LaTeXtables\table00_data_audit.tex',
            r'LaTeXtables\table00_data_audit.tex',
            r'Tables\latex\table00_data_audit.tex']:
    fp = os.path.join(BASE_DIR, sub)
    replace_in_file(fp,
        'Risk-free rate (proxy)     & 14\% p.a.     & Central bank policy rate proxy & \\texttt{12\_backtest.py} \\\\',
        'Benchmark hurdle rate      & 14\% p.a.     & Standardized hurdle rate     & \\texttt{12\_backtest.py} \\\\')
    replace_in_file(fp,
        'Risk-free rate (proxy)     & 14\% p.a.     & Turkish Repo Rate (approx.)  & \\texttt{12X_backtest.py} \\\\',
        'Benchmark hurdle rate      & 14\% p.a.     & Standardized hurdle rate     & \\texttt{12\_backtest.py} \\\\')

# 8. Update supplementary.tex (Blinding and Data Availability)
for sub in [r'RIBAF_Submission\LaTeX', r'LaTeX']:
    dir_path = os.path.join(BASE_DIR, sub)
    supp_path = os.path.join(dir_path, 'supplementary.tex')
    supp_with_auth = os.path.join(dir_path, 'supplementary_with_authors.tex')
    if os.path.exists(supp_path):
        if not os.path.exists(supp_with_auth):
            shutil.copy2(supp_path, supp_with_auth)
            print(f'Preserved unblinded backup: {supp_with_auth}')
        
        with open(supp_path, 'r', encoding='utf-8') as f:
            s_content = f.read()
        
        # Replace metadata pdfauthor
        s_content = re.sub(r'pdfauthor=\{[^}]+\}', 'pdfauthor={Anonymous Authors}', s_content)
        
        # Replace author block in preamble
        s_content = re.sub(r'\\author\[[a-z,\*]+\]\{[^}]+\}\s*', '', s_content)
        s_content = re.sub(r'\\affil[[a-z]\]{[}}k\}\s*', '', s_content)
        s_content = re.sub(r'\\usepackage\{authblk\}\s+\\renewcommand\\Authfont\{[^}]+\}\s+\\renewcommand\\Affilfont{[^}]+\}\s+\\setlength{\\affilsep}{[^}]+\}', '', s_content)
        
        if '\\author{Anonymous Authors}' not in s_content:
            s_content = re.sub(r'(\\date\{\}\n)', '\\author{Anonymous Authors}\n\\date{}\n', s_content)
        
        # Remove footnote blocks
        s_content = re.sub(r'\\begingroup\s*\\renewcommand{\\thefootnote}\{\\fnsymbol{\footnote}\}\s*\ofootnotetext\[1\].*?\\endgroup\s+', '', s_content, flags=re.DOTALL)
        s_content = re.sub(r'\\begingroup\s*\\renewcommand{\\thefootnote}\{\\alph\gootnote}\}\s*\\footnotetext\{*?\\endgroup\s+', '', s_content, flags=re.DOTALL)
        
        # Harmonize Data Availability in supplementary
        s_content = s_content.replace(
            'Replication code and derived datasets will be made publicly available upon acceptance. Restricted raw market inputs cannot be redistributed and will be reconstructible using the documented data-collection procedures.',
            'Replication code and derived datasets will be made publicly available upon acceptance via an open-access repository. Restricted raw market inputs cannot be redistributed directly and will be reconstructible using the documented data-collection procedures.'
        )
        
        with open(supp_path, 'w', encoding='utf-8') as f:
            f.write(s_content)
        print(f'Successfully blinded and updated {supp_path}')

print('All replacements completed.')
