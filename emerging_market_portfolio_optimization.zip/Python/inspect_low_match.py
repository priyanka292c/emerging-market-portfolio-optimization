import json
from pathlib import Path

data = json.loads(Path('Python/reference_verification_results.json').read_text(encoding='utf-8'))
low_match = [d for d in data if d['title_similarity'] < 50.0]
print(f"Low match count: {len(low_match)}")
for d in low_match:
    print(f"Key: {d['key']}")
    print(f"  Bib Title:      {d['bib_title']}")
    print(f"  Verified Title: {d['verified_title']}")
    print(f"  Bib DOI:        {d['bib_doi']}")
    print()
