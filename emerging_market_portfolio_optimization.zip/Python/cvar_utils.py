"""
cvar_utils.py
=============
Shared CVaR utility functions.
Imported by 06_cvar.py, 07_classical_optimization.py, 12_backtest.py.
"""

import numpy as np


def cvar_exact_cvxpy(w, returns_matrix, alpha=0.95):
    """
    Rockafellar-Uryasev CVaR as CVXPY expression.
    Returns (cvar_expr, constraints, nu).
    """
    import cvxpy as cp
    T, N = returns_matrix.shape
    nu   = cp.Variable()
    u    = cp.Variable(T)
    portfolio_losses = -returns_matrix @ w
    cvar_expr = nu + (1.0 / ((1 - alpha) * T)) * cp.sum(u)
    constraints = [u >= 0, u >= portfolio_losses - nu]
    return cvar_expr, constraints, nu


def compute_realized_cvar(returns_vec, alpha=0.95):
    """Historical CVaR at confidence level alpha."""
    losses = -np.asarray(returns_vec)
    losses_sorted = np.sort(losses)
    var_idx = int(np.ceil(alpha * len(losses))) - 1
    var_idx = max(0, min(var_idx, len(losses) - 1))
    tail    = losses[losses >= losses_sorted[var_idx]]
    return float(np.mean(tail)) if len(tail) > 0 else float(losses_sorted[var_idx])


def compute_var(returns_vec, alpha=0.95):
    """Historical VaR at confidence level alpha."""
    losses = -np.asarray(returns_vec)
    return float(np.percentile(losses, alpha * 100))


def portfolio_risk_report(returns_vec, label="Portfolio", rf_annual=0.0):
    """Full set of risk metrics for a monthly return series."""
    r = np.asarray(returns_vec)
    if len(r) < 2:
        return {"label": label}
    ann_ret  = (1 + r.mean()) ** 12 - 1
    ann_vol  = r.std() * np.sqrt(12)
    rf_m     = (1 + rf_annual) ** (1/12) - 1
    excess_r = r - rf_m
    sharpe   = excess_r.mean() / excess_r.std() * np.sqrt(12) if excess_r.std() > 0 else np.nan
    neg_r    = r[r < rf_m]
    sortino  = (excess_r.mean() * 12) / (neg_r.std() * np.sqrt(12)) \
               if len(neg_r) > 0 and neg_r.std() > 0 else np.nan
    cvar_95  = compute_realized_cvar(r, alpha=0.95)
    cvar_99  = compute_realized_cvar(r, alpha=0.99)
    var_95   = compute_var(r, alpha=0.95)
    wealth   = np.cumprod(1 + r)
    peak     = np.maximum.accumulate(wealth)
    dd       = (peak - wealth) / peak
    mdd      = float(dd.max())
    calmar   = ann_ret / mdd if mdd > 0 else np.nan
    return {
        "label":        label,
        "n_months":     len(r),
        "ann_return":   round(ann_ret, 6),
        "ann_vol":      round(ann_vol, 6),
        "sharpe":       round(sharpe, 4) if not np.isnan(sharpe) else np.nan,
        "sortino":      round(sortino, 4) if not np.isnan(sortino) else np.nan,
        "calmar":       round(calmar, 4) if not np.isnan(calmar) else np.nan,
        "var_95":       round(var_95, 6),
        "cvar_95":      round(cvar_95, 6),
        "cvar_99":      round(cvar_99, 6),
        "max_drawdown": round(mdd, 6),
        "pct_positive": round((r > 0).mean(), 4),
    }
