import sys
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

bib_files = [
    ROOT / "RIBAF_Submission" / "LaTeX" / "references.bib",
    ROOT / "LaTeX" / "references.bib"
]

corrections = {
    "balcilar2013investor": """@article{balcilar2013investor,
  title     = {Investor herds and regime-switching: Evidence from {Gulf Arab} stock markets},
  author    = {Balcilar, Mehmet and Demirer, Riza and Hammoudeh, Shawkat},
  journal   = {Journal of International Financial Markets, Institutions \\& Money},
  volume    = {27},
  pages     = {309--321},
  year      = {2013},
  publisher = {Elsevier},
  doi       = {10.1016/j.intfin.2012.09.007}
}""",

    "balke2000regime": """@article{balke2000regime,
  title     = {Credit and Economic Activity: Credit Regimes and Nonlinear Propagation of Shocks},
  author    = {Balke, Nathan S.},
  journal   = {Review of Economics and Statistics},
  volume    = {82},
  number    = {2},
  pages     = {344--359},
  year      = {2000},
  publisher = {MIT Press},
  doi       = {10.1162/rest.2000.82.2.344}
}""",

    "bekaert2007liquidity": """@article{bekaert2007liquidity,
  title     = {Liquidity and Expected Returns: Lessons from Emerging Markets},
  author    = {Bekaert, Geert and Harvey, Campbell R. and Lundblad, Christian},
  journal   = {Review of Financial Studies},
  volume    = {20},
  number    = {6},
  pages     = {1783--1831},
  year      = {2007},
  publisher = {Oxford University Press},
  doi       = {10.1093/rfs/hhm030}
}""",

    "bouri2019herding": """@article{bouri2019herding,
  title     = {Herding behaviour in cryptocurrencies},
  author    = {Bouri, Elie and Gupta, Rangan and Roubaud, David},
  journal   = {Finance Research Letters},
  volume    = {29},
  pages     = {216--221},
  year      = {2019},
  publisher = {Elsevier},
  doi       = {10.1016/j.frl.2018.07.008}
}""",

    "culjak2022benefits": """@article{culjak2022benefits,
  title     = {Benefits of sectoral cryptocurrency portfolio optimization},
  author    = {\\v{C}uljak, Maria and Tomi{\\'c}, Bojan and \\v{Z}ikovi{\\'c}, Sa{\\v{s}}a},
  journal   = {Research in International Business and Finance},
  volume    = {60},
  pages     = {101615},
  year      = {2022},
  publisher = {Elsevier},
  doi       = {10.1016/j.ribaf.2022.101615}
}""",

    "gurdgiev2020herding": """@article{gurdgiev2020herding,
  title     = {Herding and anchoring in cryptocurrency markets: Investor reaction to fear and uncertainty},
  author    = {Gurdgiev, Constantin and O'Loughlin, Daniel},
  journal   = {Journal of Behavioral and Experimental Finance},
  volume    = {28},
  pages     = {100271},
  year      = {2020},
  publisher = {Elsevier},
  doi       = {10.1016/j.jbef.2020.100271}
}""",

    "mensi2016asymmetric": """@article{mensi2016asymmetric,
  title     = {Asymmetric Linkages between {BRICS} Stock Returns and Country Risk Ratings: Evidence from Dynamic Panel Threshold Models},
  author    = {Mensi, Walid and Hammoudeh, Shawkat and Yoon, Seong-Min and Nguyen, Duc Khuong},
  journal   = {Review of International Economics},
  volume    = {24},
  number    = {1},
  pages     = {1--19},
  year      = {2016},
  publisher = {Wiley},
  doi       = {10.1111/roie.12201}
}""",

    "umutlu2010degree": """@article{umutlu2010degree,
  author    = {Umutlu, Mehmet and Akdeniz, Levent and Altay-Salih, Aslihan},
  title     = {The degree of financial liberalization and aggregated stock-return volatility in emerging markets},
  journal   = {Journal of Banking \\& Finance},
  volume    = {34},
  number    = {3},
  pages     = {509--521},
  year      = {2010},
  publisher = {Elsevier},
  doi       = {10.1016/j.jbankfin.2009.08.010}
}""",

    "kaya2021impact": """@article{citci2023exchange,
  title     = {Exchange rate uncertainty and the connectedness of inflation},
  author    = {{\\c{C}}it{\\c{c}}i, Sadettin Haluk and Kaya, H{\\"u}seyin},
  journal   = {Borsa Istanbul Review},
  volume    = {23},
  number    = {3},
  pages     = {723--735},
  year      = {2023},
  publisher = {Elsevier},
  doi       = {10.1016/j.bir.2023.01.009}
}

@article{kaya2021impact,
  title     = {Exchange rate uncertainty and the connectedness of inflation},
  author    = {{\\c{C}}it{\\c{c}}i, Sadettin Haluk and Kaya, H{\\"u}seyin},
  journal   = {Borsa Istanbul Review},
  volume    = {23},
  number    = {3},
  pages     = {723--735},
  year      = {2023},
  publisher = {Elsevier},
  doi       = {10.1016/j.bir.2023.01.009}
}"""
}

def update_bib_file(path):
    text = path.read_text(encoding="utf-8")
    for key, repl in corrections.items():
        pattern = r'@\w+\s*\{\s*' + key + r',[\s\S]*?\n\}'
        if re.search(pattern, text):
            text = re.sub(pattern, lambda m, r=repl: r, text)
            print(f"[{path.name}] Updated {key}")
        else:
            print(f"[{path.name}] Warning: {key} not found")
    path.write_text(text, encoding="utf-8")

for bf in bib_files:
    if bf.exists():
        update_bib_file(bf)

# Update sections to cite citci2023exchange
sec_files = [
    ROOT / "RIBAF_Submission" / "LaTeX" / "sections" / "01_introduction.tex",
    ROOT / "RIBAF_Submission" / "LaTeX" / "sections" / "02_literature_review.tex",
    ROOT / "RIBAF_Submission" / "LaTeX" / "sections" / "04_data_and_methodology.tex",
    ROOT / "LaTeX" / "sections" / "01_introduction.tex",
    ROOT / "LaTeX" / "sections" / "02_literature_review.tex",
    ROOT / "LaTeX" / "sections" / "04_data_and_methodology.tex",
]

for sf in sec_files:
    if sf.exists():
        content = sf.read_text(encoding="utf-8")
        if "kaya2021impact" in content:
            new_content = content.replace("kaya2021impact", "citci2023exchange")
            sf.write_text(new_content, encoding="utf-8")
            print(f"[{sf.name}] Replaced kaya2021impact with citci2023exchange")
