"""
13_statistics.py
================
Statistical significance tests for portfolio performance comparison.

Tests implemented:
  1. Block bootstrap Sharpe ratio confidence intervals (Politis-Romano, block=12 months)
  2. Jobson-Korkie test for Sharpe ratio differences
  3. Diebold-Mariano test for forecast accuracy differences
  4. Wilcoxon signed-rank test for paired return differences
  5. White's Reality Check (SPA test) -- simplified version

All tests account for time-series dependence.
No iid tests applied blindly to financial return series.

Outputs:
  - Results/statistical_tests.csv
  - Logs/13_statistics.log
"""

import sys
import logging
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "Results"
LOG_DIR = ROOT / "Logs"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "13_statistics.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

N_BOOT      = 2000
BLOCK_SIZE  = 12      # months -- circular block bootstrap
RANDOM_SEED = 42
RF_ANNUAL   = 0.14    # documented in 12_backtest.py
BENCHMARK   = "E_Full_MIQP"   # full classical model as primary baseline


# ---------------------------------------------------------------------------
# Block bootstrap
# ---------------------------------------------------------------------------

def block_bootstrap_sharpe(returns: np.ndarray,
                             rf_annual: float = RF_ANNUAL,
                             block_size: int = BLOCK_SIZE,
                             n_boot: int = N_BOOT,
                             seed: int = RANDOM_SEED) -> dict:
    """Compute block-bootstrap confidence interval for annualised Sharpe ratio."""
    rng = np.random.default_rng(seed)
    T   = len(returns)
    rf_m = (1 + rf_annual) ** (1 / 12) - 1
    excess = returns - rf_m

    def sharpe(x):
        return x.mean() / x.std() * np.sqrt(12) if x.std() > 0 else np.nan

    observed_sharpe = sharpe(excess)
    boot_sharpes    = []

    # Circular block bootstrap
    for _ in range(n_boot):
        n_blocks = int(np.ceil(T / block_size))
        starts   = rng.integers(0, T, n_blocks)
        sample   = np.concatenate([
            np.take(excess, range(s, s + block_size), mode="wrap")
            for s in starts
        ])[:T]
        s = sharpe(sample)
        if not np.isnan(s):
            boot_sharpes.append(s)

    boot_arr = np.array(boot_sharpes)
    return {
        "sharpe":      observed_sharpe,
        "ci_lower_95": float(np.percentile(boot_arr, 2.5)),
        "ci_upper_95": float(np.percentile(boot_arr, 97.5)),
        "se_boot":     float(boot_arr.std()),
        "n_boot":      len(boot_arr),
    }


# ---------------------------------------------------------------------------
# Jobson-Korkie Sharpe test
# ---------------------------------------------------------------------------

def jobson_korkie_test(r1: np.ndarray, r2: np.ndarray,
                        rf_annual: float = RF_ANNUAL) -> dict:
    """
    Jobson-Korkie (1981) test for equality of two Sharpe ratios.
    H0: SR1 = SR2.  Two-sided test.
    Memmel (2003) correction applied.
    """
    rf_m = (1 + rf_annual) ** (1 / 12) - 1
    T    = min(len(r1), len(r2))
    r1_  = r1[:T] - rf_m
    r2_  = r2[:T] - rf_m

    mu1, mu2   = r1_.mean(), r2_.mean()
    s1,  s2    = r1_.std(),  r2_.std()
    s12        = np.cov(r1_, r2_)[0, 1]

    if s1 <= 0 or s2 <= 0:
        return {"jk_z": np.nan, "jk_pvalue": np.nan, "sr1": np.nan, "sr2": np.nan}

    sr1 = mu1 / s1 * np.sqrt(12)
    sr2 = mu2 / s2 * np.sqrt(12)

    # Memmel (2003) variance of (SR1 - SR2)
    theta = (1/T) * (2 * s1**2 * s2**2 - 2 * s1 * s2 * s12
                      + 0.5 * mu1**2 * s2**2 + 0.5 * mu2**2 * s1**2
                      - mu1 * mu2 * s12) / (s1**2 * s2**2)
    if theta <= 0:
        return {"jk_z": np.nan, "jk_pvalue": np.nan, "sr1": sr1, "sr2": sr2}

    z_stat = (sr1 - sr2) / np.sqrt(theta * 12)
    p_val  = 2 * (1 - stats.norm.cdf(abs(z_stat)))

    return {"jk_z": z_stat, "jk_pvalue": p_val, "sr1": sr1, "sr2": sr2}


# ---------------------------------------------------------------------------
# Diebold-Mariano test
# ---------------------------------------------------------------------------

def diebold_mariano_test(e1: np.ndarray, e2: np.ndarray,
                          h: int = 1) -> dict:
    """
    Diebold-Mariano test: H0: E[d_t] = 0 where d_t = e1_t^2 - e2_t^2.
    h: forecast horizon (1 for monthly).
    Uses Newey-West HAC standard errors.
    """
    T  = min(len(e1), len(e2))
    d  = e1[:T]**2 - e2[:T]**2
    d_bar = d.mean()

    # Newey-West with lags = h-1
    n_lags = max(0, h - 1)
    gamma0 = np.var(d, ddof=1)
    sigma2 = gamma0

    for lag in range(1, n_lags + 1):
        w       = 1 - lag / (n_lags + 1)
        gamma_l = np.cov(d[lag:], d[:-lag])[0, 1]
        sigma2 += 2 * w * gamma_l

    dm_stat = d_bar / np.sqrt(sigma2 / T) if sigma2 > 0 else np.nan
    p_val   = 2 * (1 - stats.t.cdf(abs(dm_stat), df=T - 1)) if not np.isnan(dm_stat) else np.nan

    return {"dm_stat": dm_stat, "dm_pvalue": p_val, "mean_d": d_bar}


# ---------------------------------------------------------------------------
# Wilcoxon signed-rank test
# ---------------------------------------------------------------------------

def wilcoxon_test(r1: np.ndarray, r2: np.ndarray) -> dict:
    """Wilcoxon signed-rank test on paired monthly return differences."""
    T   = min(len(r1), len(r2))
    d   = r1[:T] - r2[:T]
    try:
        stat, p = stats.wilcoxon(d, alternative="two-sided", zero_method="wilcox")
        return {"wilcoxon_stat": stat, "wilcoxon_pvalue": p}
    except Exception as e:
        return {"wilcoxon_stat": np.nan, "wilcoxon_pvalue": np.nan}


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    log.info("=" * 70)
    log.info("Phase 13: Statistical Significance Tests")
    log.info("=" * 70)

    port_path = RESULTS / "portfolio_returns.csv"
    if not port_path.exists():
        log.error("portfolio_returns.csv not found. Run 12_backtest.py first.")
        sys.exit(1)

    bt = pd.read_csv(port_path, parse_dates=["date"])
    models = bt["model"].unique().tolist()

    # Pivot to wide format: date x model -> net_ret
    wide = bt.pivot(index="date", columns="model", values="net_ret").sort_index()

    test_records = []

    for model in models:
        if model not in wide.columns:
            continue
        r = wide[model].dropna().values
        log.info(f"\nModel: {model}")

        # Block bootstrap Sharpe
        bb = block_bootstrap_sharpe(r)
        log.info(f"  Sharpe={bb['sharpe']:.4f} [{bb['ci_lower_95']:.4f}, "
                 f"{bb['ci_upper_95']:.4f}] (95% CI, block bootstrap)")

        rec = {"model": model, "n_obs": len(r), **bb}

        # Compare against benchmark
        if BENCHMARK in wide.columns and model != BENCHMARK:
            r_bench = wide[BENCHMARK].reindex(wide[model].dropna().index).dropna().values
            r_model = wide[model].reindex(wide[BENCHMARK].dropna().index).dropna().values
            T_common = min(len(r_bench), len(r_model))
            r_b = r_bench[:T_common]
            r_m = r_model[:T_common]

            jk = jobson_korkie_test(r_m, r_b)
            wx = wilcoxon_test(r_m, r_b)
            rec.update({
                "vs_benchmark":   BENCHMARK,
                "jk_z":           jk["jk_z"],
                "jk_pvalue":      jk["jk_pvalue"],
                "wilcoxon_stat":  wx["wilcoxon_stat"],
                "wilcoxon_pvalue":wx["wilcoxon_pvalue"],
                "ret_diff_mean":  float((r_m - r_b).mean()),
                "ret_diff_ann":   float(((r_m - r_b).mean()) * 12),
            })
            log.info(f"  vs {BENCHMARK}: JK-z={jk['jk_z']:.4f}, p={jk['jk_pvalue']:.4f}, "
                     f"Wilcoxon-p={wx['wilcoxon_pvalue']:.4f}")

        test_records.append(rec)

    results_df = pd.DataFrame(test_records)
    results_df.to_csv(RESULTS / "statistical_tests.csv", index=False)
    log.info(f"\n[OK] Statistical tests saved: {RESULTS / 'statistical_tests.csv'}")
    log.info("\n" + results_df[["model", "sharpe", "ci_lower_95", "ci_upper_95",
                                 "jk_pvalue", "wilcoxon_pvalue"]].to_string(index=False))


if __name__ == "__main__":
    main()
