import sys
import json
import urllib.request

sys.stdout.reconfigure(encoding='utf-8')
headers = {'User-Agent': 'ScholarVerifier/2.0'}

url = "https://api.crossref.org/works?query=jimonfin+2020+102&rows=20"
req = urllib.request.Request(url, headers=headers)
try:
    with urllib.request.urlopen(req, timeout=15) as resp:
        data = json.loads(resp.read().decode('utf-8'))
        items = data.get('message', {}).get('items', [])
        for it in items:
            t = it.get('title', [''])[0]
            auths = [f"{a.get('given','')} {a.get('family','')}".strip() for a in it.get('author', [])]
            doi = it.get('DOI')
            print(f"  DOI: {doi} | Authors: {auths[:2]} | Title: {t}")
except Exception as e:
    print("Error:", e)
