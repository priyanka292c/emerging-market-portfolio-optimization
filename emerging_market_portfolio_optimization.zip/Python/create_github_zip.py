"""
Create an optimized GitHub-ready ZIP archive of the complete repository.
Enforces the maximum file size limit of 25 MB (GitHub release / web upload limit).
"""

import os
import io
import zipfile
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
ZIP_NAME = ROOT / "Borsa_Istanbul_Quantum_Portfolio_GitHub.zip"

EXCLUDE_EXTS = {
    ".aux", ".log", ".out", ".toc", ".synctex.gz",
    ".fls", ".fdb_latexmk", ".bbl", ".blg", ".pyc"
}
EXCLUDE_DIRS = {"__pycache__", ".git", ".idea", ".vscode", "Submission_Package"}

def build_zip():
    print(f"Creating GitHub archive at: {ZIP_NAME.name}...")
    
    total_files = 0
    with zipfile.ZipFile(ZIP_NAME, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for root, dirs, files in os.walk(ROOT):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            
            # Avoid duplicate PNGs inside LaTeX/figures since LaTeX exclusively compiles with .pdf vector figures
            if "LaTeX" in root and "figures" in root:
                files = [f for f in files if not f.endswith(".png")]
                
            for f in sorted(files):
                if f.endswith(".zip") or f.endswith(".tmp") or f.startswith("opt_"):
                    continue
                ext = os.path.splitext(f)[1].lower()
                if ext in EXCLUDE_EXTS:
                    continue
                if "test_noauthblk" in f:
                    continue
                if f in ["manuscript.pdf", "supplementary_material.pdf"]:
                    continue
                # Avoid duplicate compiled PDFs in RIBAF_Submission/LaTeX (sources are there, compiled PDFs are in Submission_PDFs and LaTeX)
                if "RIBAF_Submission" in root and "LaTeX" in root and ext == ".pdf" and "figures" not in root:
                    continue
                # Avoid loose duplicate PDFs at root of Submission_PDFs
                if os.path.basename(root) == "Submission_PDFs" and ext == ".pdf":
                    continue
                # Avoid duplicate main.pdf in Submission_PDFs/Manuscript (Manuscript_Without_Author_Details.pdf is the official one)
                if "Submission_PDFs" in root and "Manuscript" in root and f == "main.pdf":
                    continue
                # Avoid duplicate supplementary.pdf in Submission_PDFs/Supplementary (Supplementary_Material_Anonymous.pdf is the official one)
                if "Submission_PDFs" in root and "Supplementary" in root and f in ["supplementary.pdf", "supplementary_with_authors.pdf"]:
                    continue
                # Avoid duplicate title_page.pdf in Submission_PDFs/Title_Page (Title_Page_with_Author_Details.pdf is official)
                if "Submission_PDFs" in root and "Title_Page" in root and f == "title_page.pdf":
                    continue

                fp = Path(root) / f
                arcname = fp.relative_to(ROOT)
                
                # Web-optimize high-resolution PNGs for GitHub preview
                if ext == ".png":
                    try:
                        im = Image.open(fp)
                        if im.width > 1400:
                            h = int(im.height * (1400 / im.width))
                            im = im.resize((1400, h), Image.Resampling.LANCZOS)
                        buf = io.BytesIO()
                        im.save(buf, format="PNG", optimize=True)
                        zf.writestr(str(arcname).replace("\\", "/"), buf.getvalue())
                    except Exception as e:
                        zf.write(fp, str(arcname).replace("\\", "/"))
                else:
                    zf.write(fp, str(arcname).replace("\\", "/"))
                    
                total_files += 1

    # Verify archive integrity
    with zipfile.ZipFile(ZIP_NAME, "r") as zf_test:
        bad_file = zf_test.testzip()
        if bad_file:
            print(f"[ERROR] Corrupt file detected in archive: {bad_file}")
        else:
            print("[INTEGRITY] Archive integrity test PASSED (0 errors).")

    sz_bytes = ZIP_NAME.stat().st_size
    sz_mb = sz_bytes / (1024 * 1024)
    print(f"\n[SUCCESS] Archive created: {ZIP_NAME.name}")
    print(f"Total files archived: {total_files}")
    print(f"Archive size: {sz_mb:.2f} MB ({sz_bytes:,} bytes)")
    
    if sz_mb <= 25.0:
        print(f"[OK] Strict constraint met: {sz_mb:.2f} MB <= 25.00 MB (margin: {25.0 - sz_mb:.2f} MB)")
    else:
        print(f"[WARNING] Size exceeds 25 MB: {sz_mb:.2f} MB")

if __name__ == "__main__":
    build_zip()
