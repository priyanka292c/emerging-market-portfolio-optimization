import os
import shutil
import pandas as pd
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def add_styled_heading(doc, text, level):
    h = doc.add_heading(text, level=level)
    h.paragraph_format.space_before = Pt(12)
    h.paragraph_format.space_after = Pt(4)
    for run in h.runs:
        run.font.name = 'Calibri'
        run.font.color.rgb = RGBColor(10, 37, 64) if level == 1 else RGBColor(25, 118, 210)
    return h

def add_dataframe_table(doc, df, caption):
    p_cap = doc.add_paragraph()
    p_cap.paragraph_format.space_before = Pt(10)
    p_cap.paragraph_format.space_after = Pt(4)
    run_cap = p_cap.add_run(caption)
    run_cap.bold = True
    run_cap.font.name = 'Calibri'
    run_cap.font.size = Pt(10)
    run_cap.font.color.rgb = RGBColor(10, 37, 64)

    table = doc.add_table(rows=df.shape[0] + 1, cols=df.shape[1])
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # Header Row
    for col_idx, col_name in enumerate(df.columns):
        cell = table.cell(0, col_idx)
        cell.text = str(col_name)
        set_cell_background(cell, "0A2540")
        for p in cell.paragraphs:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in p.runs:
                run.bold = True
                run.font.name = 'Calibri'
                run.font.size = Pt(9.5)
                run.font.color.rgb = RGBColor(255, 255, 255)

    # Data Rows
    for row_idx in range(df.shape[0]):
        bg_color = "F8F9FA" if row_idx % 2 == 1 else "FFFFFF"
        for col_idx in range(df.shape[1]):
            cell = table.cell(row_idx + 1, col_idx)
            val = df.iloc[row_idx, col_idx]
            if isinstance(val, float):
                cell.text = f"{val:.4f}" if abs(val) < 100 else f"{val:.1f}"
            else:
                cell.text = str(val)
            set_cell_background(cell, bg_color)
            for p in cell.paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER if col_idx > 0 else WD_ALIGN_PARAGRAPH.LEFT
                for run in p.runs:
                    run.font.name = 'Calibri'
                    run.font.size = Pt(9)
                    run.font.color.rgb = RGBColor(40, 40, 40)

    doc.add_paragraph().paragraph_format.space_after = Pt(6)

def add_figure_image(doc, img_path, caption, width_in=6.0):
    if not os.path.exists(img_path):
        return
    import io
    from PIL import Image
    try:
        im = Image.open(img_path)
        if im.width > 1400:
            h = int(im.height * (1400 / im.width))
            im = im.resize((1400, h), Image.Resampling.LANCZOS)
        buf = io.BytesIO()
        im.save(buf, format="PNG", optimize=True)
        buf.seek(0)
        img_source = buf
    except Exception:
        img_source = img_path

    p_img = doc.add_paragraph()
    p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_img.paragraph_format.space_before = Pt(8)
    p_img.paragraph_format.space_after = Pt(4)
    run_img = p_img.add_run()
    run_img.add_picture(img_source, width=Inches(width_in))

    p_cap = doc.add_paragraph()
    p_cap.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_cap.paragraph_format.space_after = Pt(12)
    run_cap = p_cap.add_run(caption)
    run_cap.italic = True
    run_cap.font.name = 'Calibri'
    run_cap.font.size = Pt(9.5)
    run_cap.font.color.rgb = RGBColor(80, 80, 80)

def generate_cover_letter_docx(out_path):
    doc = Document()
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

    # Sender Info
    p_from = doc.add_paragraph()
    r = p_from.add_run("Ram Soorat (Corresponding Author)\nAssistant Professor, School of Technology, Woxsen University\nKamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\nEmail: ram.soorat@woxsen.edu.in | Telephone: +91 8455 305555 | ORCID: https://orcid.org/0000-0001-7875-9197\nSeptember 29, 2026")
    r.font.name = 'Calibri'
    r.font.size = Pt(10.5)

    p_to = doc.add_paragraph()
    p_to.paragraph_format.space_before = Pt(12)
    r_to = p_to.add_run("To the Editor-in-Chief\nResearch in International Business and Finance\nElsevier")
    r_to.bold = True
    r_to.font.name = 'Calibri'
    r_to.font.size = Pt(10.5)

    p_subj = doc.add_paragraph()
    p_subj.paragraph_format.space_before = Pt(10)
    p_subj.paragraph_format.space_after = Pt(10)
    r_sub = p_subj.add_run("Subject: Submission of Original Research Article titled \"Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market\"")
    r_sub.bold = True
    r_sub.font.name = 'Calibri'
    r_sub.font.size = Pt(11)
    r_sub.font.color.rgb = RGBColor(10, 37, 64)

    body = [
        "Dear Editor-in-Chief,",
        "We submit our original research manuscript entitled \"Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market\" for publication consideration in Research in International Business and Finance (RIBAF).",
        "Research Problem and Journal Scope Alignment:\nPortfolio allocation in emerging markets is challenged by sudden macroeconomic regime shifts, non-Gaussian tail risk, noisy factor signals, and substantial execution costs. While prior literature typically treats factor selection, regime switching, Conditional Value-at-Risk (CVaR), and transaction costs as isolated topics, their joint operational implementation under real-world cardinality constraints remains less explored. RIBAF specifically prioritizes rigorous empirical methodologies that address critical investment challenges in international and emerging capital markets. Our paper speaks directly to this mission by developing and evaluating an integrated allocation architecture in a dynamic emerging market setting.",
        "Core Contributions and Implementation Framework:\nUsing Borsa Istanbul (2010–July 2026, 147 monthly walk-forward folds) as an empirical laboratory, we examine the practical trade-offs created by institutional portfolio constraints:",
        "1. Integrated Architecture: We combine point-in-time multi-factor modeling (incorporating a conservative 60-calendar-day information-availability lag aligned with CMB/SPK reporting; Directional Accuracy: 55.10%–56.86%; the primary Pesaran–Timmermann test provides strong evidence of directional predictability (p < 10⁻¹⁷ for the reported primary specification)), latent Markov regime conditioning, Ledoit–Wolf covariance shrinkage, and empirical Rockafellar–Uryasev CVaR.",
        "2. Two-Stage Decomposition Heuristic: To circumvent the computational intractability of monolithic mixed-integer quadratic programming (MIQP), we design a two-stage decomposition (HiGHS MILP asset selection + Clarabel continuous conic optimization) that executes in <0.30 seconds per fold with verified primal feasibility across all 147 rebalancing periods.",
        "3. Trade-Off Framing and Passive Comparison: Model E (K <= 10) achieves a nominal CAGR of 41.14% in Turkish Lira (14%-hurdle-adjusted Sharpe ratio of 0.8389; in-sample optimized CVaR of 13.90%; realized out-of-sample CVaR of 14.12%). Rather than asserting universal outperformance, we explicitly document the trade-offs: Model E trades return and realized drawdown relative to unconstrained models and simple passive benchmarks (Equal Weight and Risk Parity achieve lower realized CVaR of 10.68% and 10.25%) in exchange for cardinality restriction and formation tail-risk control.",
        "4. Currency and Inflation Robustness: In USD terms, Model E delivers a 9.70% CAGR (USD Sharpe of 0.4000), closely mirroring its domestic inflation-adjusted real return of 9.84% p.a., showing that the high nominal TRY return is substantially reduced when expressed in USD terms or after domestic CPI adjustment, consistent with the effects of currency depreciation and inflation.",
        "5. Controlled Quantum Surrogate Benchmark: On a reduced 12-qubit surrogate (N_q = 4 assets, w_max = 0.25, linear tail-risk surrogate), classical exact search solves the combinatorial problem in milliseconds. Tested variational quantum algorithms (QAOA, VQE) achieve approximation ratios between 90.7% and 99.5%, with no quantum computational advantage observed for the investigated 12-qubit instances under the tested simulation conditions.",
        "Declarations: The manuscript is original, has not been published elsewhere, and is not under consideration by any other journal. All authors have approved the submission and declare no conflicts of interest. Replication code and derived datasets will be made openly available upon acceptance and permanently archived on Zenodo.",
        "Suggested Expert Reviewers:\n1. Prof. Riza Demirer (Southern Illinois University Edwardsville, USA; rdemire@siue.edu) -- Emerging market finance, regime-switching, and Borsa Istanbul asset pricing.\n2. Prof. Walid Mensi (Sultan Qaboos University, Oman; walid.mensi@squ.edu.om) -- International financial integration, asymmetric risk spillovers, and emerging-market portfolios.\n3. Prof. Daniel Palomar (Hong Kong University of Science and Technology; palomar@ust.hk) -- Convex portfolio optimization, risk budgeting, and transaction cost modeling.\n4. Prof. Román Orús (Donostia International Physics Center / Multiverse Computing, Spain; roman.orus@dipc.org) -- Quantum computing and tensor networks for financial optimization.\n5. Prof. Stefan Woerner (IBM Quantum, Switzerland; wor@zurich.ibm.com) -- Variational quantum algorithms (QAOA, VQE) and financial applications.",
        "Sincerely,\nRam Soorat (Corresponding Author)\nAssistant Professor, School of Technology, Woxsen University, Hyderabad, India\nEmail: ram.soorat@woxsen.edu.in\n\nOn behalf of all co-authors:\nShahrukh Saleem, Araby Madbouly, Uvesh Husain, Ram Soorat, Priyanka, and Afzalur Rahman"
    ]

    for paragraph in body:
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(6)
        r_p = p.add_run(paragraph)
        r_p.font.name = 'Calibri'
        r_p.font.size = Pt(10.5)

    doc.add_page_break()
    p_ci_title = doc.add_paragraph()
    r_ci = p_ci_title.add_run("Co-Author Contact Information and Institutional Affiliations")
    r_ci.bold = True
    r_ci.font.name = 'Calibri'
    r_ci.font.size = Pt(13)
    r_ci.font.color.rgb = RGBColor(10, 37, 64)

    table_data = [
        ["Author", "Academic Rank", "Institution & Department", "Institutional Contact"],
        ["Shahrukh Saleem", "Assistant Professor", "VIT Business School, Vellore Institute of Technology, India", "Email: shahrukh.saleem@vit.ac.in\nORCID: 0000-0003-2949-6188"],
        ["Araby Madbouly", "Associate Professor", "Business & Accounting Dept., Muscat College, Oman", "Email: araby@muscatcollege.edu.om\nORCID: 0000-0002-7981-4191"],
        ["Uvesh Husain", "Associate Professor", "Economics & Business Studies Dept., Mazoon College, Oman", "Email: owais.husain@mazcol.edu.om\nORCID: 0000-0002-8502-8488"],
        ["Ram Soorat\n(Corresponding)", "Assistant Professor", "School of Technology, Woxsen University, Hyderabad, India", "Email: ram.soorat@woxsen.edu.in\nORCID: 0000-0001-7875-9197"],
        ["Priyanka", "Researcher", "Dept. of Physics & Astrophysics, University of Delhi, India", "Email: priyanka1@physics.du.ac.in\nORCID: 0009-0008-1520-0706"],
        ["Afzalur Rahman", "Faculty", "School of Business, Woxsen University, Hyderabad, India", "Email: afzalur.rahman@woxsen.edu.in\nORCID: 0000-0002-1561-561X"]
    ]

    t = doc.add_table(rows=len(table_data), cols=4)
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    col_widths = [Inches(1.4), Inches(1.2), Inches(2.1), Inches(2.3)]
    for r_idx, row in enumerate(table_data):
        for c_idx, val in enumerate(row):
            cell = t.cell(r_idx, c_idx)
            cell.width = col_widths[c_idx]
            cell.text = val
            if r_idx == 0:
                set_cell_background(cell, "0A2540")
                for p in cell.paragraphs:
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    for r in p.runs:
                        r.bold = True
                        r.font.name = 'Calibri'
                        r.font.size = Pt(9.5)
                        r.font.color.rgb = RGBColor(255, 255, 255)
            else:
                bg = "F8F9FA" if r_idx % 2 == 1 else "FFFFFF"
                set_cell_background(cell, bg)
                for p in cell.paragraphs:
                    p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                    for r in p.runs:
                        r.font.name = 'Calibri'
                        r.font.size = Pt(9)
                        r.font.color.rgb = RGBColor(40, 40, 40)

    doc.save(out_path)
    print(f"Cover letter docx saved to: {out_path}")

def generate_graphical_abstract_docx(out_path):
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.5)
    section.bottom_margin = Inches(0.5)
    section.left_margin = Inches(0.5)
    section.right_margin = Inches(0.5)

    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_t = p_title.add_run("GRAPHICAL ABSTRACT")
    r_t.bold = True
    r_t.font.name = 'Calibri'
    r_t.font.size = Pt(16)
    r_t.font.color.rgb = RGBColor(10, 37, 64)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.space_after = Pt(10)
    r_s = p_sub.add_run("Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market\nShahrukh Saleem, Araby Madbouly, Uvesh Husain, Ram Soorat, Priyanka, Afzalur Rahman (September 2026)")
    r_s.italic = True
    r_s.font.name = 'Calibri'
    r_s.font.size = Pt(11)
    r_s.font.color.rgb = RGBColor(80, 80, 80)

    # Insert Image
    img_path = r"D:/Quantum finance/22_09_2026/Figures/png/graphical_abstract.png"
    if os.path.exists(img_path):
        add_figure_image(doc, img_path, "Figure GA.1: End-to-end quantitative research framework, two-stage optimization engine, hybrid quantum protocol, and empirical findings.", width_in=7.2)

    highlights = [
        "Point-in-Time Integrity: Mitigates financial ML look-ahead bias across 16 years of Borsa Istanbul data (2010–2026, 31 assets, 147 out-of-sample monthly rebalancings following 14-month validation burn-in; 161 total HMM months) under CMB/SPK Communique II-14.1 filing lags.",
        "Predictive & Macro Regimes: Machine learning models achieve Directional Accuracy: 55.10%–56.86%; the primary Pesaran–Timmermann test provides strong evidence of directional predictability (p < 10⁻¹⁷ for the reported primary specification); 4-state Gaussian HMM stabilizes Ledoit–Wolf covariance shrinkage (condition number reduced from 184.2 to 48.6).",
        "Exact Tail Risk Containment: Model E (Full Two-Stage Architecture, K <= 10) delivers a geometric CAGR of 41.14% in nominal TRY, 14%-hurdle Sharpe ratio of 0.8389 (conventional risk-free proxy Sharpe: 0.7698), and bounds empirical 95% CVaR to 13.90% in-sample and 14.12% realized out-of-sample (vs. 14.26% for classical MV and 15.94% for genetic algorithms).",
        "Currency & Inflation Robustness: The USD-denominated CAGR (9.70%) is close to the domestic CPI-adjusted real CAGR (9.84%), indicating that currency depreciation and domestic inflation materially reduce the nominal TRY return when expressed in real or foreign-currency terms.",
        "Quantum Benchmark Finding: No quantum computational advantage was observed for the investigated 12-qubit instances under the tested simulation conditions. On the controlled 12-qubit surrogate (4 assets × 3 bits = 12 logical qubits), classical exact enumeration solves all 4,096 states in 20 ms vs QAOA/VQE."
    ]

    p_h_title = doc.add_paragraph()
    p_h_title.paragraph_format.space_before = Pt(8)
    r_ht = p_h_title.add_run("Research Highlights:")
    r_ht.bold = True
    r_ht.font.name = 'Calibri'
    r_ht.font.size = Pt(11)
    r_ht.font.color.rgb = RGBColor(10, 37, 64)

    for item in highlights:
        p_item = doc.add_paragraph(style='List Bullet')
        p_item.paragraph_format.space_after = Pt(3)
        r_item = p_item.add_run(item)
        r_item.font.name = 'Calibri'
        r_item.font.size = Pt(10)

    doc.save(out_path)
    print(f"Graphical abstract docx saved to: {out_path}")

def generate_supplementary_docx(out_path):
    doc = Document()
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_t = p_title.add_run("SUPPLEMENTARY MATERIAL")
    r_t.bold = True
    r_t.font.name = 'Calibri'
    r_t.font.size = Pt(18)
    r_t.font.color.rgb = RGBColor(10, 37, 64)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.space_after = Pt(16)
    r_s = p_sub.add_run("Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market\nShahrukh Saleem, Araby Madbouly, Uvesh Husain, Ram Soorat, Priyanka, Afzalur Rahman (September 2026)")
    r_s.italic = True
    r_s.font.name = 'Calibri'
    r_s.font.size = Pt(12)
    r_s.font.color.rgb = RGBColor(80, 80, 80)

    # Journal Author and Affiliation Block
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_a = p_auth.add_run("Shahrukh Saleem1, Araby Madbouly2, Uvesh Husain3, Ram Soorat4,*, Priyanka5, Afzalur Rahman6\n"
                         "1 VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore, India\n"
                         "2 Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman\n"
                         "3 Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman\n"
                         "4 School of Technology, Woxsen University, Hyderabad, Telangana, India\n"
                         "5 Department of Physics and Astrophysics, University of Delhi, New Delhi, India\n"
                         "6 School of Business, Woxsen University, Hyderabad, Telangana, India\n\n"
                         "*Corresponding Author: Assistant Professor, School of Technology, Woxsen University. Email: ram.soorat@woxsen.edu.in | ORCID: 0000-0001-7875-9197\n"
                         "Co-Author Emails: shahrukh.saleem@vit.ac.in, araby@muscatcollege.edu.om, owais.husain@mazcol.edu.om, priyanka1@physics.du.ac.in, afzalur.rahman@woxsen.edu.in\n"
                         "Co-Author ORCIDs: S. Saleem (0000-0003-2949-6188), A. Madbouly (0000-0002-7981-4191), U. Husain (0000-0002-8502-8488), Priyanka (0009-0008-1520-0706), A. Rahman (0000-0002-1561-561X)")
    r_a.font.name = 'Calibri'
    r_a.font.size = Pt(9.5)
    r_a.font.color.rgb = RGBColor(60, 60, 60)

    doc.add_page_break()

    # Section S.1
    add_styled_heading(doc, "Section S.1: Detailed Mathematical Proofs and Theoretical Derivations", level=1)
    p_p1 = doc.add_paragraph()
    p_p1.add_run("Theorem S.1 (Exact QUBO to Ising Spin Transformation):\n"
                 "Let Q in R^{M x M} be a real symmetric matrix and c in R be a scalar constant. For any binary vector x in {0, 1}^M and corresponding spin configuration z in {+1, -1}^M defined by the affine bijection x_i = (1 - z_i)/2, the QUBO objective f(x) = x^T Q x + c is identically equal to the expectation value of the Ising Hamiltonian H_C(z) = sum_{i < j} J_{ij} z_i z_j + sum_{i=1}^M h_i z_i + C_0, with exact parameters:\n"
                 "  J_{ij} = Q_{ij} / 2,\n"
                 "  h_i = -0.5 sum_{j=1}^M Q_{ij} = -0.5 (Q 1)_i,\n"
                 "  C_0 = 0.25 1^T Q 1 + 0.25 Tr(Q) + c.\n\n"
                 "Proof: Expanding x = 0.5(1 - z) in the quadratic form yields 0.25(1 - z)^T Q (1 - z) + c. Because z_i^2 = 1 identically for all spin configurations, z^T Q z decomposes into off-diagonal couplings sum_{i != j} Q_{ij} z_i z_j and the trace Tr(Q). Regrouping terms reproduces J_{ij}, h_i, and C_0 exactly. Numerical evaluation across all 4,096 basis states confirms |Delta E| = 0.00e+00.\n\n"
                 "Theorem S.2 (Rockafellar-Uryasev Linear Programming Equivalence):\n"
                 "The Conditional Value-at-Risk CVaR_alpha(w) is the global minimum of the convex auxiliary function F_alpha(w, zeta) = zeta + (1 / ((1 - alpha) S)) sum_{s=1}^S u_s, subject to linear scenario constraints u_s >= -w^T r_s - zeta and u_s >= 0. Minimization over zeta yields VaR_alpha as the optimal threshold zeta*, and CVaR_alpha as the optimal objective.\n\n"
                 "Definition S.3 (Quantum Approximation Ratio):\n"
                 "The approximation ratio alpha measures the quality of the state produced by a variational quantum algorithm relative to the exact classical ground-state energy:\n"
                 "  alpha = <H_C> / E_min = <psi(theta)| H_C |psi(theta)> / min_{z in {+1,-1}^M} H_C(z).\n"
                 "For a minimization problem with ground state energy E_min < 0, an approximation ratio alpha in [0, 1] closer to 1 indicates near-optimal convergence.")

    # Section S.2: Assets and Survivorship
    add_styled_heading(doc, "Section S.2: Borsa Istanbul Constituent Asset Directory and Survivorship Context", level=1)
    p_surv = doc.add_paragraph()
    p_surv.add_run("Historical Index Reconstitution and Survivorship Conditioning:\n"
                   "In Borsa Istanbul, index constituents for the BIST-30 benchmark are reviewed and reconstituted quarterly (effective January, April, July, and October) by the Borsa Istanbul Index Committee based on total market capitalization and average daily trading volume over the preceding two quarters. Requiring continuous trading and complete financial disclosures across the entire 16-year horizon (2010-2026) imposes a survivorship conditioning constraint.\n"
                   "While survivorship bias can exert a modest upward drift on unconditional mean returns in emerging markets, constituent departures may reflect index-rank changes, corporate reorganizations, mergers, privatizations, delistings, or other corporate events; because the empirical universe requires continuous listing and disclosure coverage, the resulting estimates should be interpreted as conditional on this survivorship criterion. Furthermore, because our portfolio construction methodology relies on cross-sectional factor ranking and relative tail-risk optimization within the active peer group, the comparative performance advantages of regime-informed CVaR allocation over classical mean-variance remain structurally robust.")

    df_desc = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table02_descriptive_statistics.csv")
    add_dataframe_table(doc, df_desc, "Table S.1: Complete Descriptive Statistics for All 31 BIST Constituent Equities (2010-2026)")

    # Section S.3: ML Details
    add_styled_heading(doc, "Section S.3: Machine Learning Model Architectures and Hyperparameters", level=1)
    df_ml = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table05_ml_performance.csv")
    add_dataframe_table(doc, df_ml, "Table S.2: Out-of-Sample Validation Errors and Directional Accuracy")

    # Section S.4: Regimes & Chronology
    add_styled_heading(doc, "Section S.4: Hidden Markov Model Regime Characteristics and Chronology Reconciliation", level=1)
    p_chrono = doc.add_paragraph()
    p_chrono.add_run("Chronology Reconciliation (198 Total Months):\n"
                     "• Phase I (2010.01 - 2013.01, 37 Months): Rolling factor lookback warm-up (calculating 36-month momentum, fundamental ratios, rolling volatility).\n"
                     "• Phase II (2013.02 - 2014.03, 14 Months): Initial HMM training and ML validation burn-in (Bull 7, Strong Bull 4, Normal 2, Bear 1).\n"
                     "• Phase III (2014.04 - 2026.07, 147 Months): Out-of-sample portfolio walk-forward backtest (Bull 59, Normal 36, Strong Bull 29, Bear 23).\n"
                     "Total Filtered HMM Horizon = Phase II + Phase III = 14 + 147 = 161 months (Bull 66, Normal 38, Strong Bull 33, Bear 24).")

    df_reg = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table04_regime_characteristics.csv")
    add_dataframe_table(doc, df_reg, "Table S.3: Four-State Gaussian HMM Macroeconomic Characteristics")
    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig05_regime_probs.png", "Figure S.1: Filtered state probabilities across walk-forward historical periods.")

    # Section S.5: Quantum Details
    add_styled_heading(doc, "Section S.5: Quantum Circuit Parameters and Noise Simulations", level=1)
    p_noise_desc = doc.add_paragraph()
    p_noise_desc.add_run("Noise Model Specifications on Qiskit Aer:\n"
                         "• Depolarizing Gate Noise: Two-qubit CNOT gate error rates swept across lambda in {0.0001, 0.001, 0.005, 0.01, 0.02, 0.05}.\n"
                         "• Measurement Readout Error: Probabilities of bit-flip during measurement swept across p_ro in {0.001, 0.005, 0.01, 0.02, 0.05}.\n"
                         "• Shot Sampling Noise: Measurement repetitions swept across N_shots in {128, 256, 512, 1024, 2048, 4096, 8192}.")

    df_noise = pd.read_csv(r"D:/Quantum finance/22_09_2026/Results/noise_sensitivity.csv")
    add_dataframe_table(doc, df_noise, "Table S.4: Physical Noise Sweep Telemetry on Qiskit Aer Simulator")
    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig21_noise_sensitivity.png", "Figure S.2: Energy degradation under depolarizing, readout, and shot sampling noise.")

    # Section S.6: Hardware & Environment
    add_styled_heading(doc, "Section S.6: Computational Environment and Hardware Specifications", level=1)
    p_env = doc.add_paragraph()
    p_env.add_run("• Operating System: Microsoft Windows 11 Enterprise (64-bit, x86-64)\n"
                  "• CPU: Intel(R) Core(TM) i7 Processor (16 logical cores @ 3.40 GHz)\n"
                  "• RAM: 32.0 GB DDR4\n"
                  "• Python: Python 3.12.10 (64-bit)\n"
                  "• Quantum SDK: Qiskit 2.5.2 with qiskit-aer 0.14.0\n"
                  "• Solvers: cvxpy 1.5.0, CLARABEL 0.9.0, HiGHS 1.7.1 via scipy.optimize.milp\n"
                  "• LaTeX: MiKTeX 25.12 with pdfTeX 3.141592653")

    doc.save(out_path)
    print(f"Supplementary docx saved to: {out_path}")

def generate_title_page_docx(out_path):
    doc = Document()
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

    # Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_t = p_title.add_run("Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market")
    r_t.bold = True
    r_t.font.name = 'Calibri'
    r_t.font.size = Pt(18)
    r_t.font.color.rgb = RGBColor(10, 37, 64)

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_sub.paragraph_format.space_after = Pt(14)
    r_sub = p_sub.add_run("Title Page with Complete Author & Institutional Contact Information")
    r_sub.bold = True
    r_sub.italic = True
    r_sub.font.name = 'Calibri'
    r_sub.font.size = Pt(12)
    r_sub.font.color.rgb = RGBColor(70, 70, 70)

    # Authors
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_auth.paragraph_format.space_after = Pt(6)
    
    authors = [
        ("Shahrukh Saleem", ",*"),
        ("Araby Madbouly", " b"),
        ("Uvesh Husain", " c"),
        ("Ram Soorat", " d"),
        ("Priyanka", " e"),
        ("Afzalur Rahman", " f")
    ]
    for idx, (name, aff) in enumerate(authors):
        r_n = p_auth.add_run(name)
        r_n.bold = True
        r_n.font.name = 'Calibri'
        r_n.font.size = Pt(11)
        r_sup = p_auth.add_run(aff)
        r_sup.font.superscript = True
        r_sup.font.name = 'Calibri'
        r_sup.font.size = Pt(9)
        if idx < len(authors) - 1:
            p_auth.add_run(", ")

    # Affiliations
    affils = [
        ("a", "VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore 632014, Tamil Nadu, India"),
        ("b", "Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman"),
        ("c", "Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman"),
        ("d", "School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India"),
        ("e", "Department of Physics and Astrophysics, University of Delhi, New Delhi 110007, Delhi, India"),
        ("f", "School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India")
    ]
    p_aff = doc.add_paragraph()
    p_aff.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_aff.paragraph_format.space_after = Pt(14)
    for tag, text in affils:
        r_tag = p_aff.add_run(tag + " ")
        r_tag.font.superscript = True
        r_tag.font.name = 'Calibri'
        r_tag.font.size = Pt(8.5)
        r_t = p_aff.add_run(text + "\n")
        r_t.font.name = 'Calibri'
        r_t.font.size = Pt(9)
        r_t.font.italic = True
        r_t.font.color.rgb = RGBColor(90, 90, 90)

    # Corresponding Author Details
    add_styled_heading(doc, "Corresponding Author Contact Details", level=2)
    p_corr = doc.add_paragraph()
    p_corr.paragraph_format.space_after = Pt(12)
    r_c = p_corr.add_run(
        "Ram Soorat\n"
        "Assistant Professor, School of Technology\n"
        "Woxsen University\n"
        "Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\n"
        "E-mail address: ram.soorat@woxsen.edu.in\n"
        "Telephone: +91 8455 305555\n"
        "ORCID: https://orcid.org/0000-0001-7875-9197"
    )
    r_c.font.name = 'Calibri'
    r_c.font.size = Pt(10)

    # Complete Co-Author Directory
    add_styled_heading(doc, "Complete Co-Author Contact and Institutional Directory", level=2)
    
    coauthor_rows = [
        ["Shahrukh Saleem", "Assistant Professor", "VIT Business School, Vellore Institute of Technology, India", "shahrukh.saleem@vit.ac.in\nORCID: 0000-0003-2949-6188"],
        ["Araby Madbouly", "Associate Professor", "Business & Accounting Dept., Muscat College, Oman", "araby@muscatcollege.edu.om\nORCID: 0000-0002-7981-4191"],
        ["Uvesh Husain", "Associate Professor", "Economics & Business Studies Dept., Mazoon College, Oman", "owais.husain@mazcol.edu.om\nORCID: 0000-0002-8502-8488"],
        ["Ram Soorat\n(Corresponding)", "Assistant Professor", "School of Technology, Woxsen University, Hyderabad, India", "ram.soorat@woxsen.edu.in\nORCID: 0000-0001-7875-9197"],
        ["Priyanka", "Researcher", "Dept. of Physics & Astrophysics, University of Delhi, India", "priyanka1@physics.du.ac.in\nORCID: 0009-0008-1520-0706"],
        ["Afzalur Rahman", "Faculty", "School of Business, Woxsen University, Hyderabad, India", "afzalur.rahman@woxsen.edu.in\nORCID: 0000-0002-1561-561X"]
    ]
    
    table = doc.add_table(rows=len(coauthor_rows) + 1, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    headers = ["Author", "Academic Rank", "Institution & Department", "Institutional Contact & ORCID"]
    col_widths = [Inches(1.5), Inches(1.3), Inches(2.2), Inches(1.8)]

    for c_idx, h_text in enumerate(headers):
        cell = table.cell(0, c_idx)
        cell.width = col_widths[c_idx]
        cell.text = h_text
        set_cell_background(cell, "0A2540")
        for p in cell.paragraphs:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for r in p.runs:
                r.bold = True
                r.font.name = 'Calibri'
                r.font.size = Pt(9.5)
                r.font.color.rgb = RGBColor(255, 255, 255)

    for r_idx, r_data in enumerate(coauthor_rows):
        bg = "F8F9FA" if r_idx % 2 == 1 else "FFFFFF"
        for c_idx, val in enumerate(r_data):
            cell = table.cell(r_idx + 1, c_idx)
            cell.width = col_widths[c_idx]
            cell.text = val
            set_cell_background(cell, bg)
            for p in cell.paragraphs:
                p.alignment = WD_ALIGN_PARAGRAPH.LEFT
                for r in p.runs:
                    r.font.name = 'Calibri'
                    r.font.size = Pt(9)
                    r.font.color.rgb = RGBColor(40, 40, 40)

    # Author Declarations
    add_styled_heading(doc, "Author Declarations", level=2)
    decls = [
        ("Funding: ", "This research received no specific grant from any funding agency in the public, commercial, or not-for-profit sectors."),
        ("Conflicts of Interest: ", "The authors declare that they have no competing financial interests or personal relationships that could have appeared to influence the work reported in this paper."),
        ("Data and Code Availability: ", "Replication code and derived datasets are provided in the accompanying replication package, with instructions for reconstructing restricted raw market inputs, and are accessible in the project repository: https://github.com/rsoorat/borsa-istanbul-quantum-portfolio."),
        ("Declaration of Generative AI and AI-Assisted Technologies: ", "During the preparation of this manuscript, the authors utilized AI-assisted technologies for code validation, bibliographic verification, and grammatical refinement. Following the use of these tools, the authors reviewed, validated, and edited all materials and accept full responsibility for the contents of the published work."),
        ("Author Contributions: ", "Shahrukh Saleem: Conceptualization, Methodology, Formal analysis, Data curation, Writing—original draft, Writing—review and editing. Araby Madbouly: Investigation, Validation, Writing—review and editing. Uvesh Husain: Conceptualization, Formal analysis, Investigation, Writing—review and editing. Ram Soorat: Methodology, Software, Data curation, Formal analysis, Writing—original draft, Writing—review and editing. Priyanka: Methodology, Software, Investigation, Writing—review and editing. Afzalur Rahman: Conceptualization, Investigation, Writing—review and editing, Supervision.")
    ]
    for d_title, d_desc in decls:
        p_d = doc.add_paragraph(style='List Bullet')
        p_d.paragraph_format.space_after = Pt(3)
        r_dt = p_d.add_run(d_title)
        r_dt.bold = True
        r_dt.font.name = 'Calibri'
        r_dt.font.size = Pt(9.5)
        r_dd = p_d.add_run(d_desc)
        r_dd.font.name = 'Calibri'
        r_dd.font.size = Pt(9.5)

    doc.save(out_path)
    print(f"Title Page docx saved to: {out_path}")

def generate_manuscript_docx(out_path):
    doc = Document()
    for section in doc.sections:
        section.top_margin = Inches(1.0)
        section.bottom_margin = Inches(1.0)
        section.left_margin = Inches(1.0)
        section.right_margin = Inches(1.0)

    # Title
    p_title = doc.add_paragraph()
    p_title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r_t = p_title.add_run("Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market")
    r_t.bold = True
    r_t.font.name = 'Calibri'
    r_t.font.size = Pt(18)
    r_t.font.color.rgb = RGBColor(10, 37, 64)

    # Authors
    p_auth = doc.add_paragraph()
    p_auth.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_auth.paragraph_format.space_after = Pt(4)
    authors = [
        ("Shahrukh Saleem", ",*"),
        ("Araby Madbouly", " b"),
        ("Uvesh Husain", " c"),
        ("Ram Soorat", " d"),
        ("Priyanka", " e"),
        ("Afzalur Rahman", " f")
    ]
    for idx, (name, aff) in enumerate(authors):
        r_n = p_auth.add_run(name)
        r_n.bold = True
        r_n.font.name = 'Calibri'
        r_n.font.size = Pt(11)
        r_sup = p_auth.add_run(aff)
        r_sup.font.superscript = True
        r_sup.font.name = 'Calibri'
        r_sup.font.size = Pt(9)
        if idx < len(authors) - 1:
            p_auth.add_run(", ")

    # Affiliations
    affils = [
        ("a", "VIT Business School, Vellore Institute of Technology (Deemed to be University), Vellore 632014, Tamil Nadu, India"),
        ("b", "Business and Accounting Department, Muscat College, Muscat, Sultanate of Oman"),
        ("c", "Economics and Business Studies Department, Mazoon College, Muscat, Sultanate of Oman"),
        ("d", "School of Technology, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India"),
        ("e", "Department of Physics and Astrophysics, University of Delhi, New Delhi 110007, Delhi, India"),
        ("f", "School of Business, Woxsen University, Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India")
    ]
    p_aff = doc.add_paragraph()
    p_aff.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p_aff.paragraph_format.space_after = Pt(8)
    for tag, text in affils:
        r_tag = p_aff.add_run(tag + " ")
        r_tag.font.superscript = True
        r_tag.font.name = 'Calibri'
        r_tag.font.size = Pt(8.5)
        r_t = p_aff.add_run(text + "\n")
        r_t.font.name = 'Calibri'
        r_t.font.size = Pt(8.5)
        r_t.font.italic = True
        r_t.font.color.rgb = RGBColor(90, 90, 90)

    # Footnote / Correspondence block
    p_fn = doc.add_paragraph()
    p_fn.paragraph_format.space_after = Pt(12)
    r_fn_star = p_fn.add_run("* ")
    r_fn_star.font.superscript = True
    r_fn_corr = p_fn.add_run("Corresponding author: Ram Soorat (Assistant Professor, School of Technology, Woxsen University). E-mail address: ram.soorat@woxsen.edu.in. ORCID: 0000-0001-7875-9197.\n")
    r_fn_corr.font.name = 'Calibri'
    r_fn_corr.font.size = Pt(8.5)
    r_fn_corr.font.color.rgb = RGBColor(70, 70, 70)
    
    r_fn_co = p_fn.add_run(
        "Co-author contacts: S. Saleem (Assistant Professor, shahrukh.saleem@vit.ac.in, ORCID: 0000-0003-2949-6188); "
        "A. Madbouly (Associate Professor, araby@muscatcollege.edu.om, ORCID: 0000-0002-7981-4191); "
        "U. Husain (Associate Professor, owais.husain@mazcol.edu.om, ORCID: 0000-0002-8502-8488); "
        "Priyanka (Researcher, priyanka1@physics.du.ac.in, ORCID: 0009-0008-1520-0706); "
        "A. Rahman (Faculty, afzalur.rahman@woxsen.edu.in, ORCID: 0000-0002-1561-561X)."
    )
    r_fn_co.font.name = 'Calibri'
    r_fn_co.font.size = Pt(8.5)
    r_fn_co.font.color.rgb = RGBColor(70, 70, 70)

    # Abstract Box
    p_abs = doc.add_paragraph()
    p_abs.paragraph_format.space_before = Pt(14)
    p_abs.paragraph_format.space_after = Pt(14)
    r_abs_lbl = p_abs.add_run("Abstract—")
    r_abs_lbl.bold = True
    r_abs_lbl.font.name = 'Calibri'
    r_abs_lbl.font.size = Pt(10.5)

    abstract_text = (
        "We formulate, implement, and empirically evaluate a hybrid quantum-classical portfolio optimization "
        "architecture tailored to emerging equity markets under macroeconomic turbulence, non-normal tail risk, "
        "and real-world execution frictions. Using a 16-year point-in-time dataset from Borsa Istanbul (BIST-30, 31 assets) "
        "spanning 2010 to 2026 across 147 walk-forward out-of-sample monthly rebalancing periods (following a 37-month "
        "rolling warm-up and 14-month validation burn-in; 161 total filtered HMM months), we systematically integrate: "
        "(i) point-in-time cross-sectional multi-factor modeling (momentum, size, value, profitability, volatility, and liquidity) "
        "strictly enforcing a 60-day reporting lag aligned with CMB/SPK Communique II-14.1 filing rules to prevent look-ahead bias; "
        "(ii) walk-forward machine learning return forecasts (ElasticNet, Random Forest, XGBoost) statistically validated via "
        "Pesaran-Timmermann and Diebold-Mariano tests alongside a 4-state Gaussian Hidden Markov Model (HMM) for regime-conditioned "
        "Ledoit-Wolf covariance shrinkage; (iii) a two-stage optimization architecture decoupling discrete cardinality selection "
        "(HiGHS mixed-integer linear programming) from continuous risk allocation (Clarabel conic quadratic programming), "
        "simultaneously enforcing cardinality (K <= 10), proportional transaction costs (c = 20 bps), and empirical "
        "Rockafellar-Uryasev Conditional Value-at-Risk (95% CVaR); and (iv) a two-scale hybrid quantum protocol mapping a screened "
        "12-qubit combinatorial subproblem (4,096 states) to an exact Ising Hamiltonian evaluated via QAOA (p in {1, 2, 3}), VQE, "
        "and noisy Qiskit Aer simulation. Out of sample, net of transaction costs, the full factor-regime model achieves an annualized "
        "compounded return of 47.94% (realized CAGR of 41.14%) and a Sharpe ratio of 0.8389, with an in-sample optimized CVaR of 13.90% and a realized out-of-sample "
        "CVaR of 14.12% (relative to 14.26% for classical mean-variance and 15.94% for genetic algorithms). In quantum benchmarks, "
        "QAOA attains an approximation ratio of alpha = 0.9367 at p=1 and alpha = 0.9539 at p=2, but degrades to alpha = 0.9072 "
        "at p=3, consistent with optimization difficulty in the higher-dimensional non-convex parameter landscape, whereas VQE achieves alpha = 0.9954. Parametric noise modeling "
        "reveals severe vulnerability to two-qubit depolarizing gate noise, contrasted with high resilience to readout errors "
        "and shot noise (N_shots >= 4,096). Classical exact solvers resolve these benchmark instances orders of magnitude "
        "faster (20 ms) than quantum simulators without noise susceptibility. Our findings substantiate that across the tested "
        "12-qubit instances under Qiskit Aer simulation conditions, no quantum computational advantage is observed over classical solvers, positioning "
        "variational quantum circuits as valuable algorithmic testbeds rather than production deployment engines."
    )
    r_abs = p_abs.add_run(abstract_text)
    r_abs.font.name = 'Calibri'
    r_abs.font.size = Pt(10)

    # Keywords
    p_kw = doc.add_paragraph()
    r_kw_lbl = p_kw.add_run("Keywords: ")
    r_kw_lbl.bold = True
    r_kw_lbl.font.name = 'Calibri'
    r_kw_lbl.font.size = Pt(10)
    r_kw = p_kw.add_run("Portfolio Optimization, Quantum Computing, QAOA, VQE, Conditional Value-at-Risk, Hidden Markov Models, Machine Learning, Artificial Intelligence, Transaction Costs, Emerging Markets.")
    r_kw.font.name = 'Calibri'
    r_kw.font.size = Pt(10)

    # Section 1: Introduction
    add_styled_heading(doc, "1. Introduction", level=1)
    p_intro = doc.add_paragraph()
    p_intro.add_run("Modern portfolio theory originated with Markowitz (1952), framing asset allocation as a mathematical trade-off between expected return and variance. While mathematically foundational, classical mean-variance optimization exhibits severe limitations when applied to empirical financial markets, particularly in emerging capital markets. First, sample means and covariance matrices suffer from substantial estimation error, leading to error-maximization where optimal weights concentrate excessively in estimation outliers (Black and Litterman, 1992; Ledoit and Wolf, 2004). Second, the assumption of normality fails in the presence of heavy tails, asymmetric skewness, and non-linear contagion, rendering variance an inadequate measure of downside tail risk (Artzner et al., 1999; Rockafellar and Uryasev, 2000). Third, real-world portfolio management is constrained by structural market frictions, including cardinality constraints and transaction costs (Perold, 1988; Almgren and Chriss, 2000).\n\n"
                    "Emerging equity markets, such as Turkey's Borsa Istanbul (BIST), amplify these operational and econometric challenges. Over the 2010-2026 period, the Turkish equity market has witnessed persistent macroeconomic volatility, rapid exchange-rate depreciation, and double-digit inflation cycles. In such an environment, unconditional historical mean returns provide little forward-looking predictive signal, and unconditional covariance matrices fail to capture time-varying systematic correlations (Bekaert and Harvey, 1995; Ang and Bekaert, 2002).\n\n"
                    "Incorporating cardinality constraints (K << N) and discrete transaction costs transforms portfolio selection into a combinatorial problem. Rather than claiming an intractable monolithic MIQP, practical quantitative finance decouples discrete asset selection from continuous risk allocation via a two-stage optimization architecture. In parallel, quantum computing has motivated financial researchers to investigate whether hybrid quantum-classical algorithms, such as QAOA (Farhi et al., 2014) and VQE (Peruzzo et al., 2014; Kandala et al., 2017), can offer novel computational paradigms for combinatorial subproblems.\n\n"
                    "However, current quantum finance literature frequently suffers from three critical flaws: (i) look-ahead bias from contemporaneous fundamentals, (ii) conflation between multi-asset financial backtests and small-scale quantum circuits, and (iii) unsupported claims of quantum advantage on NISQ hardware. This study directly resolves all three limitations through an authentic, transparent two-stage empirical implementation and disciplined quantum benchmarking.")

    # Section 2: Literature Review
    add_styled_heading(doc, "2. Literature Review", level=1)
    p_lit = doc.add_paragraph()
    p_lit.add_run("The cross-sectional asset pricing literature has evolved from the single-factor CAPM (Sharpe, 1964) to multi-factor models (Fama and French, 1992, 1993; Carhart, 1997; Asness et al., 2013). More recently, empirical finance has transitioned toward machine learning techniques capable of processing high-dimensional feature spaces and non-linear interactions (Gu, Kelly, and Xiu, 2020; Freyberger et al., 2020).\n\n"
                  "Simultaneously, regime-switching econometrics has shown that equity correlations and volatilities shift substantially across market cycles (Hamilton, 1989; Ang and Bekaert, 2002; Guidolin and Timmermann, 2007; Nystrup et al., 2017). To address tail risk, Rockafellar and Uryasev (2000, 2002) proved that Conditional Value-at-Risk (CVaR) can be optimized efficiently via linear programming.\n\n"
                  "In quantum optimization, QAOA and VQE parameterize shallow quantum circuits to approximate combinatorial ground states. Foundational studies (Egger et al., 2020; Herman et al., 2023) benchmarked toy portfolio instances. We bridge this literature by implementing an empirically grounded, two-scale hybrid framework with exact CVaR, transaction costs, and honest computational benchmarking.")

    # Section 3: Methodology
    add_styled_heading(doc, "3. Quantitative Methodology", level=1)
    p_meth = doc.add_paragraph()
    p_meth.add_run("Our quantitative architecture integrates five interconnected modules: (i) point-in-time factor construction with 60-day reporting lags under CMB/SPK Communique II-14.1, (ii) walk-forward ML return forecasting, (iii) 4-state Gaussian HMM regime detection, (iv) Ledoit-Wolf covariance shrinkage, and (v) a two-stage optimization architecture decoupling discrete cardinality selection (HiGHS MILP) from continuous risk allocation (Clarabel conic QP) alongside a 12-qubit quantum Ising benchmark.")
    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig01.png", "Figure 1: End-to-end quantitative research framework integrating multi-factor modeling, regime filtering, and two-stage classical/quantum optimization.")

    df_constraints = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table07_portfolio_constraints.csv")
    add_dataframe_table(doc, df_constraints, "Table 1: Portfolio Optimization Constraints and Mathematical Formulations")

    # Section 4: Data & Empirical Setup
    add_styled_heading(doc, "4. Data and Empirical Setup", level=1)
    p_data_desc = doc.add_paragraph()
    p_data_desc.add_run("Data Provenance, Regulatory Filing Rules, and Survivorship Context:\n"
                        "Our empirical dataset comprises 31 major constituent equities of Borsa Istanbul (BIST-30 core), spanning January 2010 through July 2026 (198 total monthly observations). In Turkey, public financial reporting is governed by Capital Markets Board (CMB/SPK) Communique II-14.1, requiring standalone financial statements within 30-40 calendar days and consolidated statements within 50-60 calendar days following the fiscal quarter. To guarantee econometric point-in-time integrity and eliminate look-ahead bias, we impose a strict 60-day financial disclosure lag before any balance sheet or income statement item enters the cross-sectional factor ranking.\n"
                        "The constituent sample represents a continuously trading survivor-conditioned core of BIST-30. Quarterly index reconstitutions by the Borsa Istanbul Index Committee are documented, noting that constituent departures may reflect index-rank changes, corporate reorganizations, mergers, privatizations, delistings, or other corporate events; because the empirical universe requires continuous listing and disclosure coverage, the resulting estimates should be interpreted as conditional on this survivorship criterion.")

    df_dataset = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table01_dataset_description.csv")
    add_dataframe_table(doc, df_dataset, "Table 2: Dataset Description and Market Parameters")

    df_factors = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table03_factor_statistics.csv")
    add_dataframe_table(doc, df_factors, "Table 3: Point-in-Time Factor Summary Statistics")

    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig04.png", "Figure 2: Pairwise correlation matrix across standardized point-in-time factor signals.")

    df_regimes = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table04_regime_characteristics.csv")
    add_dataframe_table(doc, df_regimes, "Table 4: Market-State and Volatility Regime Characteristics from 4-State Gaussian HMM")

    # Section 5: Empirical Results
    add_styled_heading(doc, "5. Empirical Results", level=1)
    p_res_desc = doc.add_paragraph()
    p_res_desc.add_run("Statistical Validation and Economic Performance:\n"
                       "Machine learning return forecasts demonstrate statistically significant directional predictability across out-of-sample periods: binomial sign test z = 9.24 (p < 10^-19), Pesaran-Timmermann non-parametric directional test PT = 8.76 (p < 10^-17), and Diebold-Mariano test DM = 3.42 (p = 0.0006) relative to unconditional historical mean benchmarks. In-sample optimized 95% CVaR is bounded to 13.90%, while realized out-of-sample monthly CVaR is 14.12% (close to Model D's 14.08%), demonstrating strong risk containment without severe parameter overfitting.")

    df_perf = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table10_portfolio_performance.csv")
    add_dataframe_table(doc, df_perf, "Table 5: Out-of-Sample Portfolio Performance Net of Transaction Costs (2014-2026)")

    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig15_cumulative_wealth.png", "Figure 3: Out-of-sample cumulative wealth trajectories (logarithmic scale, base = 1.0) across competing portfolio models.")
    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig16_drawdown.png", "Figure 4: Historical drawdown paths illustrating downside tail containment across models.")
    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig17_cvar_comparison.png", "Figure 5: Historical Conditional Value-at-Risk (95% confidence level) comparison.")

    df_tc = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table12_turnover_tc.csv")
    add_dataframe_table(doc, df_tc, "Table 6: Portfolio Turnover Dynamics and Cumulative Summed Transaction Cost Charges")

    df_stats = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table14_statistical_tests.csv")
    add_dataframe_table(doc, df_stats, "Table 7: Statistical Significance Tests for Sharpe Ratios Relative to Model E")

    df_ablation = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table16_ablation_study.csv")
    add_dataframe_table(doc, df_ablation, "Table 8: Ablation Study - Incremental Economic Contribution of Model Modules")

    # Section 6: Quantum Optimization Results
    add_styled_heading(doc, "6. Quantum Optimization Results", level=1)
    p_q_desc = doc.add_paragraph()
    p_q_desc.add_run("Screened 12-Qubit Combinatorial Benchmark Subproblem:\n"
                     "To benchmark NISQ quantum algorithms rigorously without unphysical qubit resource assumptions, the full 31-asset portfolio problem is pre-screened to a 12-qubit combinatorial subproblem (N_q = 4 assets x 3 discretization bits = 4,096 basis states). Exact energy equivalence (|Delta E| = 0.00e+00) between QUBO and Ising spin Hamiltonians is analytically proved and numerically verified. Approximation ratios are defined as alpha = <H_C> / E_min.")

    df_qaoa = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table09_qaoa_results.csv")
    add_dataframe_table(doc, df_qaoa, "Table 9: QAOA Layer Depth Convergence and Approximation Ratios (12-Qubit Portfolio)")

    df_qc = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table13_quantum_classical.csv")
    add_dataframe_table(doc, df_qc, "Table 10: Quantum Variational Solvers vs. Exact Classical Benchmark")

    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig10.png", "Figure 6: Heatmap of the 12 x 12 QUBO interaction matrix Q showing pairwise qubit couplings.")
    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig12_qaoa_convergence.png", "Figure 7: QAOA parameter optimization trajectory across classical function evaluations.")
    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig13_qaoa_vs_depth.png", "Figure 8: QAOA approximation ratio as a function of circuit depth p.")
    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig21_noise_sensitivity.png", "Figure 9: Quantum expectation energy degradation under depolarizing, readout, and shot noise.")

    # Section 7: Robustness Checks
    add_styled_heading(doc, "7. Robustness Checks and Sensitivity Analysis", level=1)
    p_rob_desc = doc.add_paragraph()
    p_rob_desc.add_run("Rebalancing Frequency Sensitivity Analysis:\n"
                       "The rebalancing-frequency sensitivity analysis indicates materially lower turnover and higher estimated Sharpe ratios at quarterly and semi-annual frequencies; however, these estimates are based on substantially fewer observations and therefore have greater sampling uncertainty. These results should consequently be interpreted as sensitivity evidence rather than as evidence for a universally superior rebalancing frequency.")

    df_robust = pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/table15_robustness.csv")
    add_dataframe_table(doc, df_robust, "Table 11: Robustness Analysis across Rebalancing Frequencies and Cost Tiers")

    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig20.png", "Figure 10: Cumulative wealth trajectories under alternative rebalancing frequencies and cost tiers.")
    add_figure_image(doc, r"D:/Quantum finance/22_09_2026/Figures/png/fig22_robustness_heatmap.png", "Figure 11: Two-dimensional robustness heatmap of annualized Sharpe ratios.")

    # Section 8: Conclusion
    add_styled_heading(doc, "8. Conclusion and Future Directions", level=1)
    p_conc = doc.add_paragraph()
    p_conc.add_run("This study developed and empirically evaluated a comprehensive hybrid quantum-classical portfolio optimization framework designed specifically for emerging-market equities. Our conclusions provide evidence-based answers to all six research questions:\n"
                   "1. Machine Learning Factor Predictability (RQ1): Point-in-time factor signals provide persistent out-of-sample predictability (DirAcc 55.1%-56.9%, PT = 8.76, DM = 3.42), generating superior net risk-adjusted returns net of realistic execution frictions.\n"
                   "2. Market-State and Volatility Regime Conditioning (RQ2): Hidden Markov Model regime filtering dynamically adapts covariance shrinkage, shielding portfolios against market volatility shocks.\n"
                   "3. Coherent Tail Risk Containment (RQ3): Empirical Rockafellar-Uryasev CVaR optimization produced a lower optimized in-sample tail-risk objective while introducing an explicit risk-return-implementation trade-off. Model E achieved an optimized CVaR of 13.90% and realized out-of-sample CVaR of 14.12%, but this tail-risk discipline was accompanied by lower return and Sharpe ratio than the unconstrained factor models and a realized maximum drawdown of 37.24%.\n"
                   "4. Transaction Cost Discipline (RQ4): Explicit transaction costs materially affect net portfolio performance through turnover-related drag. The 20-bps baseline assumption generates an average monthly transaction-cost drag of 0.1801% for Model E, with cumulative summed charges of 26.47% over the 147-month out-of-sample horizon (net geometric CAGR of 41.14% vs. 50.10% gross). Explicit transaction-cost penalization in both optimization stages dampens unnecessary rebalancing churn while maintaining execution feasibility under sparse cardinality (K <= 10).\n"
                   "5. Quantum Variational Performance and Optimizer Landscapes (RQ5): On the 12-qubit reduced portfolio subproblem, QAOA achieved approximation ratios of 0.9367, 0.9539, and 0.9072 for p = 1, 2, 3, respectively, while VQE achieved 0.9954. The results demonstrate non-monotonic QAOA behavior and the sensitivity of variational optimization to circuit depth and classical parameter optimization in non-convex landscapes. Classical exact enumeration solves this 12-qubit benchmark in 20 milliseconds, positioning variational quantum algorithms as valuable experimental testbeds.\n"
                   "6. Parametric Noise Resilience (RQ6): Under the investigated Qiskit Aer parametric noise model, two-qubit depolarizing errors produced substantially larger expectation-energy degradation than the tested readout-error and finite-shot conditions. The findings therefore characterize noise sensitivity for the investigated simulation setting rather than establishing hardware-level performance.")

    add_styled_heading(doc, "Data and Code Availability", level=1)
    p_avail = doc.add_paragraph()
    r_av = p_avail.add_run(
        "The complete computational pipeline, replication codebase, derived empirical datasets, and simulation routines for both classical "
        "(HiGHS, Clarabel) and quantum (QAOA, VQE, and Qiskit Aer noise models) portfolio optimization architectures are provided in the accompanying "
        "replication package and in the project repository: https://github.com/rsoorat/borsa-istanbul-quantum-portfolio, with instructions for reconstructing restricted raw market inputs."
    )
    r_av.font.name = 'Calibri'
    r_av.font.size = Pt(11)

    add_styled_heading(doc, "Declaration of Generative AI and AI-Assisted Technologies in the Writing Process", level=1)
    p_ai = doc.add_paragraph()
    r_ai = p_ai.add_run(
        "During the preparation of this manuscript, the authors utilized AI-assisted technologies for computational code verification, "
        "reference consistency cross-checks, and grammatical refinement. After utilizing these tools, the authors thoroughly reviewed, "
        "evaluated, and edited all text, mathematical formulations, and empirical findings, and take full responsibility for the content, "
        "originality, and integrity of the published work."
    )
    r_ai.font.name = 'Calibri'
    r_ai.font.size = Pt(11)

    doc.save(out_path)
    print(f"Manuscript docx saved to: {out_path}")

def main():
    base_dir = r"D:/Quantum finance/22_09_2026/Submission_Package"
    os.makedirs(os.path.join(base_dir, "Title_Page"), exist_ok=True)
    os.makedirs(os.path.join(base_dir, "Manuscript"), exist_ok=True)
    os.makedirs(os.path.join(base_dir, "Supplementary"), exist_ok=True)
    os.makedirs(os.path.join(base_dir, "Cover_Letter"), exist_ok=True)
    os.makedirs(os.path.join(base_dir, "Graphical_Abstract"), exist_ok=True)

    print("Generating Title Page DOCX...")
    generate_title_page_docx(os.path.join(base_dir, "Title_Page", "title_page.docx"))

    print("Generating Cover Letter DOCX...")
    generate_cover_letter_docx(os.path.join(base_dir, "Cover_Letter", "cover_letter.docx"))

    print("Generating Graphical Abstract DOCX...")
    generate_graphical_abstract_docx(os.path.join(base_dir, "Graphical_Abstract", "graphical_abstract.docx"))

    print("Generating Supplementary Material DOCX...")
    generate_supplementary_docx(os.path.join(base_dir, "Supplementary", "supplementary_material.docx"))

    print("Generating Full Manuscript DOCX...")
    generate_manuscript_docx(os.path.join(base_dir, "Manuscript", "manuscript.docx"))

    print("Copying compiled deliverables to Submission_Package and RIBAF_Submission...")
    ribaf_pdf_dir = r"D:/Quantum finance/22_09_2026/RIBAF_Submission/Submission_PDFs"
    for sub in ["Title_Page", "Manuscript", "Supplementary", "Cover_Letter", "Graphical_Abstract"]:
        os.makedirs(os.path.join(ribaf_pdf_dir, sub), exist_ok=True)
    
    # Copy docx deliverables
    shutil.copy2(os.path.join(base_dir, "Title_Page", "title_page.docx"), os.path.join(ribaf_pdf_dir, "Title_Page", "title_page.docx"))
    shutil.copy2(os.path.join(base_dir, "Cover_Letter", "cover_letter.docx"), os.path.join(ribaf_pdf_dir, "Cover_Letter", "cover_letter.docx"))
    shutil.copy2(os.path.join(base_dir, "Graphical_Abstract", "graphical_abstract.docx"), os.path.join(ribaf_pdf_dir, "Graphical_Abstract", "graphical_abstract.docx"))
    shutil.copy2(os.path.join(base_dir, "Supplementary", "supplementary_material.docx"), os.path.join(ribaf_pdf_dir, "Supplementary", "supplementary_material.docx"))
    shutil.copy2(os.path.join(base_dir, "Manuscript", "manuscript.docx"), os.path.join(ribaf_pdf_dir, "Manuscript", "manuscript.docx"))
    print("All deliverables generated and organized in Submission_Package/ and RIBAF_Submission/!")

if __name__ == "__main__":
    main()
