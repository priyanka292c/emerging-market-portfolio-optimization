"""
08_qubo_builder.py
==================
QUBO formulation for the cardinality-constrained portfolio sub-problem.
Operates on the PRE-SCREENED quantum universe of 10-15 assets.

Mathematical derivation:

1. Weight discretisation
   Asset i allocated n_bits binary variables: x_{i,0}, ..., x_{i,B-1}
   Weight: w_i(x) = sum_{b=0}^{B-1} 2^b * x_{i,b} / (2^B - 1) * w_max
   This maps the [0, w_max] continuous weight to B-bit binary encoding.

2. Portfolio objective (mapped to binary variables x):
   f(x) = -mu^T w(x) + lam1 * w(x)^T Sigma w(x) + lam2 * CVaR_approx(x)
         + lam3 * TC(x, w_prev)
   Note: CVaR_approx enters as linear term (Path B from 06_cvar.py).
   TC: |w_i(x) - w_{i,prev}| linearised as: max-abs handled by squaring and
       constant shift (valid since only affects diagonal and is monotone in deviation).

3. QUBO formulation:
   Q(x) = x^T Q x + c   where x in {0,1}^(N*B)

4. Constraint penalties (quadratic penalty method):
   Budget:     P_budget = lambda_pen * (1 - sum_i w_i(x))^2
   Cardinality: P_card = lambda_pen * (K - sum_i z_i)^2
               where z_i = sign(sum_b x_{i,b}) (max of bits)

5. Ising mapping:
   x_{i,b} = (1 - Z_{i,b}) / 2  where Z in {-1, +1}
   H_C = sum_{ij} J_{ij} Z_i Z_j + sum_i h_i Z_i

Outputs:
  - QUBO Q matrix and constant c  (numpy)
  - Ising J, h, offset            (numpy)
  - Logs/08_qubo_builder.log
  - Data/processed/qubo_metadata.csv
"""

import sys
import logging
import json
from pathlib import Path
from itertools import product

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
LOG_DIR   = ROOT / "Logs"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "08_qubo_builder.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# QUBO Configuration
# ---------------------------------------------------------------------------
N_BITS    = 3       # bits per asset -> 8 levels, max ~12.5% per asset with w_max=1/N
W_MAX     = 0.25    # maximum single-asset weight in quantum sub-problem
LAMBDA_PEN = 5.0    # penalty coefficient for equality constraints
LAMBDA1   = 1.0     # variance
LAMBDA2   = 0.5     # CVaR
LAMBDA3   = 2.0     # TC
TC_COST   = 0.002   # 20bps
ALPHA     = 0.95


# ---------------------------------------------------------------------------
# Weight encoding
# ---------------------------------------------------------------------------

def weight_from_bits(bits: np.ndarray, n_bits: int, w_max: float) -> float:
    """Convert n_bits binary array to continuous weight in [0, w_max]."""
    levels = 2 ** n_bits - 1
    return (sum(b * (2 ** i) for i, b in enumerate(bits)) / levels) * w_max


def weight_vector_from_x(x: np.ndarray, N: int, n_bits: int,
                           w_max: float) -> np.ndarray:
    """Convert full binary vector x (length N*n_bits) to weight vector (N,)."""
    w = np.zeros(N)
    for i in range(N):
        bits = x[i * n_bits: (i + 1) * n_bits]
        w[i] = weight_from_bits(bits, n_bits, w_max)
    return w


def asset_weight_coeffs(i: int, N: int, n_bits: int,
                         w_max: float) -> np.ndarray:
    """
    Returns coefficient vector a_i such that w_i = a_i^T x  (linear in x).
    Shape: (N * n_bits,).
    """
    levels = 2 ** n_bits - 1
    a = np.zeros(N * n_bits)
    for b in range(n_bits):
        a[i * n_bits + b] = (2 ** b) / levels * w_max
    return a


# ---------------------------------------------------------------------------
# QUBO matrix construction
# ---------------------------------------------------------------------------

def build_qubo(mu: np.ndarray, Sigma: np.ndarray,
                cvar_penalty: np.ndarray,   # linear penalty from Path B (06_cvar.py)
                w_prev: np.ndarray,
                K: int,                     # cardinality target
                n_bits: int = N_BITS,
                w_max: float = W_MAX,
                lam1: float = LAMBDA1,
                lam2: float = LAMBDA2,
                lam3: float = LAMBDA3,
                tc_cost: float = TC_COST,
                lambda_pen: float = LAMBDA_PEN,
                alpha: float = ALPHA) -> tuple[np.ndarray, float, dict]:
    """
    Build the QUBO matrix Q and constant offset c.

    Returns:
        Q_qubo : (M, M) QUBO matrix where M = N * n_bits
        c      : scalar constant offset
        info   : dict of metadata
    """
    N = len(mu)
    M = N * n_bits          # total binary variables
    Q = np.zeros((M, M))
    c = 0.0

    # Coefficient vectors a_i such that w_i = a_i^T x
    A = np.array([asset_weight_coeffs(i, N, n_bits, w_max) for i in range(N)])  # (N, M)

    # -----------------------------------------------------------------------
    # Term 1: Return (linear in x)  ->  diagonal: -mu_i * a_{i,b}
    # -----------------------------------------------------------------------
    for i in range(N):
        for b in range(n_bits):
            idx = i * n_bits + b
            Q[idx, idx] -= mu[i] * A[i, idx]

    # -----------------------------------------------------------------------
    # Term 2: Variance   lam1 * w^T Sigma w = lam1 * x^T (A^T Sigma A) x
    # -----------------------------------------------------------------------
    Q_var = A.T @ Sigma @ A   # (M, M)
    Q += lam1 * Q_var

    # -----------------------------------------------------------------------
    # Term 3: CVaR (linear penalty from Path B) -> diagonal
    # cvar_penalty[i] is the per-asset linear coefficient
    # Enters QUBO as: lam2 * sum_i cvar_penalty[i] * w_i
    #               = lam2 * sum_i cvar_penalty[i] * A[i] @ x
    # -----------------------------------------------------------------------
    for i in range(N):
        for b in range(n_bits):
            idx = i * n_bits + b
            Q[idx, idx] += lam2 * cvar_penalty[i] * A[i, idx]

    # -----------------------------------------------------------------------
    # Term 4: TC penalty   lam3 * tc_cost * sum_i (w_i - w_prev_i)^2
    # (Using squared deviation as QUBO-compatible proxy for |w_i - w_prev_i|.
    #  This is an approximation: |x| ~ x^2 for small deviations.
    #  Documented as approximation in manuscript.)
    # TC = lam3 * tc_cost * sum_i [(A[i]@x)^2 - 2*w_prev_i*(A[i]@x) + w_prev_i^2]
    # Quadratic: lam3*tc_cost * A.T@A (summed over assets)
    # Linear:   -2 * lam3*tc_cost * w_prev_i * A[i] (diagonal)
    # Constant:  lam3*tc_cost * sum_i w_prev_i^2
    # -----------------------------------------------------------------------
    for i in range(N):
        ai = A[i]   # (M,)
        Q += lam3 * tc_cost * np.outer(ai, ai)
        for b in range(n_bits):
            idx = i * n_bits + b
            Q[idx, idx] -= 2 * lam3 * tc_cost * w_prev[i] * ai[idx]
        c += lam3 * tc_cost * w_prev[i] ** 2

    # -----------------------------------------------------------------------
    # Penalty 1: Budget constraint  lambda_pen * (1 - sum_i w_i)^2
    # sum_i w_i = sum_i A[i] @ x = (sum_i A[i]) @ x
    # Let v = sum_i A[i]  (M,)
    # (1 - v@x)^2 = 1 - 2*v@x + (v@x)^2 = 1 - 2*v@x + x^T (v v^T) x
    # -----------------------------------------------------------------------
    v = A.sum(axis=0)   # (M,)
    Q += lambda_pen * np.outer(v, v)
    for b_idx in range(M):
        Q[b_idx, b_idx] -= 2 * lambda_pen * v[b_idx]
    c += lambda_pen

    # -----------------------------------------------------------------------
    # Penalty 2: Cardinality  lambda_pen * (K - sum_i z_i)^2
    # z_i = 1 iff asset i selected; approximate z_i by OR of its bits.
    # OR approximation: z_i ~ (1/n_bits) * sum_b x_{i,b} (soft version).
    # This is a known approximation for QUBO cardinality constraints.
    # For exact cardinality, slack variables would be needed (documented).
    # -----------------------------------------------------------------------
    z_coeff = np.zeros(M)
    for i in range(N):
        for b in range(n_bits):
            z_coeff[i * n_bits + b] = 1.0 / n_bits

    Q += lambda_pen * np.outer(z_coeff, z_coeff)
    for b_idx in range(M):
        Q[b_idx, b_idx] -= 2 * lambda_pen * K * z_coeff[b_idx]
    c += lambda_pen * K ** 2

    # Make Q symmetric (upper triangular convention -> symmetrize)
    Q = 0.5 * (Q + Q.T)

    info = {
        "N":          N,
        "n_bits":     n_bits,
        "M":          M,
        "K":          K,
        "lambda_pen": lambda_pen,
        "w_max":      w_max,
        "qubo_density": float((Q != 0).mean()),
        "qubo_norm":  float(np.linalg.norm(Q)),
    }
    return Q, c, info


# ---------------------------------------------------------------------------
# QUBO -> Ising transformation
# ---------------------------------------------------------------------------

def qubo_to_ising(Q: np.ndarray, c: float) -> tuple[np.ndarray, np.ndarray, float]:
    """
    Transform QUBO Q(x) = x^T Q x + c to Ising H(z) = sum_{ij} J_{ij} z_i z_j + sum_i h_i z_i + offset
    using the substitution x_i = (1 - z_i) / 2, z_i in {-1, +1}.

    Derivation:
        x_i = (1 - z_i)/2
        x_i x_j = (1 - z_i)(1 - z_j)/4 = (1 - z_i - z_j + z_i z_j)/4

    Expanding:
        Q(x) = sum_{ij} Q_{ij} x_i x_j + sum_i Q_{ii} x_i + c

    After substitution:
        Pairwise coupling: J_{ij} = Q_{ij} / 2 for i < j (or J_{ij} = Q_{ij} / 4 for double-sum i != j)
        Local fields: h_i = -0.5 * sum_j Q_{ij} = -0.5 * (Q 1)_i
        Offset: offset = 0.25 * 1^T Q 1 + 0.25 * Tr(Q) + c

    Returns:
        J      : (M, M) coupling matrix (symmetric, zero diagonal)
        h      : (M,) local fields
        offset : scalar constant
    """
    M = Q.shape[0]
    J = np.zeros((M, M))
    for i in range(M):
        for j in range(M):
            if i != j:
                J[i, j] = Q[i, j] / 4.0

    h = np.zeros(M)
    for i in range(M):
        h[i] = -0.5 * Q[i, :].sum()

    offset = 0.25 * Q.sum() + 0.25 * np.trace(Q) + c

    return J, h, offset


# ---------------------------------------------------------------------------
# Asset pre-screening (for quantum sub-universe)
# ---------------------------------------------------------------------------

def prescreen_assets(mu: np.ndarray, Sigma: np.ndarray,
                      liquidity_scores: np.ndarray,
                      tickers: list[str],
                      N_q: int = 12) -> list[str]:
    """
    Select N_q assets for the quantum sub-experiment.
    Ranking criterion: composite score = 0.5 * rank(mu) + 0.5 * rank(liquidity)
    Both rankings computed on TRAINING data.
    Returns selected ticker list.
    """
    N = len(tickers)
    N_q = min(N_q, N)

    # Rank by expected return and liquidity (higher = better)
    mu_rank  = pd.Series(mu).rank(pct=True).values
    liq_rank = pd.Series(liquidity_scores).rank(pct=True).values if liquidity_scores is not None \
               else np.ones(N) / N

    composite = 0.5 * mu_rank + 0.5 * liq_rank
    top_idx   = np.argsort(composite)[-N_q:]
    selected  = [tickers[i] for i in sorted(top_idx)]
    log.info(f"Pre-screened {N_q} assets from {N}: {selected}")
    return selected


# ---------------------------------------------------------------------------
# Self-test
# ---------------------------------------------------------------------------

def main():
    log.info("=" * 70)
    log.info("Phase 8: QUBO Builder Self-Test")
    log.info("=" * 70)

    np.random.seed(42)
    N = 4           # small quantum universe for exact statevector benchmark (M=12 qubits)
    n_bits = 3
    M = N * n_bits

    # Synthetic data
    mu     = np.random.randn(N) * 0.05 + 0.01
    A_mat  = np.random.randn(N, N)
    Sigma  = A_mat @ A_mat.T / N
    cvar_p = np.random.rand(N) * 0.01
    w_prev = np.ones(N) / N
    K      = 2

    Q, c, info = build_qubo(mu, Sigma, cvar_p, w_prev, K,
                              n_bits=n_bits, w_max=W_MAX)

    log.info(f"QUBO dimensions: {Q.shape}")
    log.info(f"QUBO density   : {info['qubo_density']:.3f}")
    log.info(f"QUBO norm      : {info['qubo_norm']:.4f}")
    log.info(f"Constant c     : {c:.4f}")

    J, h, offset = qubo_to_ising(Q, c)
    log.info(f"Ising J norm   : {np.linalg.norm(J):.4f}")
    log.info(f"Ising h norm   : {np.linalg.norm(h):.4f}")
    log.info(f"Ising offset   : {offset:.4f}")

    # Verify QUBO -> Ising consistency on a random binary vector
    x_test  = np.random.randint(0, 2, M).astype(float)
    z_test  = 1 - 2 * x_test                # z = 1-2x
    qubo_val  = x_test @ Q @ x_test + c
    ising_val = z_test @ J @ z_test + h @ z_test + offset

    log.info(f"\nConsistency check (random x):")
    log.info(f"  QUBO value : {qubo_val:.6f}")
    log.info(f"  Ising value: {ising_val:.6f}")
    log.info(f"  Difference : {abs(qubo_val - ising_val):.2e}")
    assert abs(qubo_val - ising_val) < 1e-6, \
        f"QUBO->Ising mismatch: {abs(qubo_val - ising_val):.2e}"

    log.info("[OK] QUBO->Ising transformation verified.")

    # Save test matrices
    np.save(DATA_PROC / "test_qubo_Q.npy", Q)
    np.save(DATA_PROC / "test_ising_J.npy", J)
    np.save(DATA_PROC / "test_ising_h.npy", h)
    log.info("[OK] Test matrices saved.")


if __name__ == "__main__":
    main()
