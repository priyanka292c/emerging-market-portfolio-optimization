"""
10_vqe.py
=========
VQE (Variational Quantum Eigensolver) for the same portfolio QUBO
as a second quantum benchmark alongside QAOA.

VQE differs from QAOA in its ansatz: rather than a problem-inspired
phase-separation/mixing structure, VQE uses hardware-efficient parametric
circuits (RealAmplitudes, EfficientSU2) with classically optimised parameters.

Comparison with QAOA:
  - QAOA: problem-inspired, approximation ratio directly interpretable
  - VQE : hardware-efficient, more expressive but less interpretable
  - Both run on same pre-screened 10-15 asset universe
  - Comparison reported honestly: neither claimed superior without evidence

Outputs:
  - Results/vqe_performance.csv
  - Results/vqe_convergence.csv
  - Logs/10_vqe.log
"""

import sys
import logging
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
RESULTS   = ROOT / "Results"
LOG_DIR   = ROOT / "Logs"
RESULTS.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "10_vqe.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

VQE_REPS       = [1, 2]    # ansatz repetitions
RANDOM_STATE   = 42
MAX_RESTARTS   = 2
N_QUBITS_MAX   = 24        # limit for VQE statevector


def build_ising_operator(J: np.ndarray, h: np.ndarray, offset: float):
    """
    Build Qiskit SparsePauliOp for Ising Hamiltonian.
    H = sum_{ij} J_{ij} Z_i Z_j + sum_i h_i Z_i + offset

    Returns SparsePauliOp (Qiskit 2.x).
    """
    try:
        from qiskit.quantum_info import SparsePauliOp
    except ImportError:
        log.error("Qiskit not found.")
        sys.exit(1)

    M = len(h)
    pauli_list = []

    # ZZ terms
    for i in range(M):
        for j in range(i + 1, M):
            if abs(J[i, j]) > 1e-10:
                pauli_str = ["I"] * M
                pauli_str[i] = "Z"
                pauli_str[j] = "Z"
                # Qiskit: qubit 0 is rightmost in string
                pauli_list.append(("".join(reversed(pauli_str)), 2 * J[i, j]))

    # Z terms
    for i in range(M):
        if abs(h[i]) > 1e-10:
            pauli_str = ["I"] * M
            pauli_str[i] = "Z"
            pauli_list.append(("".join(reversed(pauli_str)), h[i]))

    # Constant offset -> identity
    pauli_list.append(("I" * M, offset))

    if not pauli_list:
        pauli_list = [("I" * M, 0.0)]

    return SparsePauliOp.from_list(pauli_list)


def build_real_amplitudes_ansatz(n_qubits: int, reps: int = 1):
    """
    Hardware-efficient ansatz: RealAmplitudes with linear entanglement.
    All parameters are rotation angles on Ry gates.
    Qiskit 2.x: qiskit.circuit.library.RealAmplitudes
    """
    try:
        from qiskit.circuit.library import RealAmplitudes
        return RealAmplitudes(n_qubits, entanglement="linear", reps=reps)
    except ImportError:
        log.warning("RealAmplitudes not found -- building manually.")
        from qiskit import QuantumCircuit
        from qiskit.circuit import ParameterVector
        qc = QuantumCircuit(n_qubits)
        params = ParameterVector("theta", n_qubits * (reps + 1))
        idx = 0
        for _ in range(reps):
            for q in range(n_qubits):
                qc.ry(params[idx], q)
                idx += 1
            for q in range(n_qubits - 1):
                qc.cx(q, q + 1)
        for q in range(n_qubits):
            qc.ry(params[idx], q)
            idx += 1
        return qc


def get_e_all(J, h, offset, M):
    Z_all = np.array([[1 - 2 * int(b) for b in format(i, f'0{M}b')] for i in range(2 ** M)])
    return np.einsum('ki,ij,kj->k', Z_all, J, Z_all) + Z_all @ h + offset


def run_vqe(ansatz, E_all, max_iter: int = 500,
            n_restarts: int = MAX_RESTARTS, seed: int = RANDOM_STATE) -> dict:
    """
    Run VQE using gradient-free COBYLA optimisation.
    Returns best energy, parameters, and convergence history.
    """
    from qiskit.quantum_info import Statevector
    from scipy.optimize import minimize as sp_minimize

    n_params = ansatz.num_parameters
    rng      = np.random.default_rng(seed)
    convergence = []
    n_eval = [0]
    best_energy = np.inf
    best_params = None

    def energy(params):
        n_eval[0] += 1
        try:
            bound_circuit = ansatz.assign_parameters(dict(zip(ansatz.parameters, params)))
            sv  = Statevector(bound_circuit)
            probs = sv.probabilities()
            exp = float(probs @ E_all)
        except Exception as e:
            log.warning(f"VQE evaluation error: {e}")
            exp = 1e6
        convergence.append((n_eval[0], exp))
        return exp

    for restart in range(n_restarts):
        theta0 = rng.uniform(-np.pi, np.pi, n_params)
        res = sp_minimize(energy, theta0, method="COBYLA",
                           options={"maxiter": max_iter, "rhobeg": 0.5})
        if res.fun < best_energy:
            best_energy = res.fun
            best_params = res.x.copy()
        log.info(f"    Restart {restart+1}/{n_restarts}: energy={res.fun:.6f}, nfev={res.nfev}")

    return {
        "best_energy":   best_energy,
        "best_params":   best_params.tolist() if best_params is not None else None,
        "n_evaluations": n_eval[0],
        "convergence":   convergence,
    }


def main():
    log.info("=" * 70)
    log.info("Phase 10: VQE Quantum Portfolio Optimisation")
    log.info("=" * 70)

    try:
        import qiskit
        log.info(f"Qiskit: {qiskit.__version__}")
    except ImportError:
        log.error("qiskit not installed.")
        sys.exit(1)

    # Load Ising operators from QUBO test run
    Q_path = DATA_PROC / "test_qubo_Q.npy"
    J_path = DATA_PROC / "test_ising_J.npy"
    h_path = DATA_PROC / "test_ising_h.npy"
    if not (Q_path.exists() and J_path.exists() and h_path.exists()):
        log.error("QUBO / Ising matrices not found. Run 08_qubo_builder.py first.")
        sys.exit(1)

    Q = np.load(Q_path)
    J = np.load(J_path)
    h = np.load(h_path)
    offset = float(0.25 * Q.sum() + 0.25 * np.trace(Q))
    M = len(h)

    if M > N_QUBITS_MAX:
        log.warning(f"M={M} > {N_QUBITS_MAX}. Truncating for statevector feasibility.")
        M = N_QUBITS_MAX
        J = J[:M, :M]
        h = h[:M]
        Q = Q[:M, :M]

    log.info(f"VQE problem: M={M} qubits")

    # Precompute all state energies
    E_all = get_e_all(J, h, offset, M)
    bf_min = float(E_all.min())
    bf_max = float(E_all.max())
    log.info(f"Exact benchmark: E_min={bf_min:.6f}, E_max={bf_max:.6f}")

    vqe_results = []

    for reps in VQE_REPS:
        log.info(f"\n--- VQE ansatz reps={reps} ---")
        ansatz = build_real_amplitudes_ansatz(M, reps=reps)
        log.info(f"  Parameters: {ansatz.num_parameters}, "
                 f"Depth: {ansatz.depth()}")

        result = run_vqe(ansatz, E_all, max_iter=500, n_restarts=MAX_RESTARTS, seed=RANDOM_STATE)

        approx_ratio = (bf_max - result["best_energy"]) / (bf_max - bf_min) if bf_max > bf_min else np.nan

        log.info(f"  Best energy: {result['best_energy']:.6f}, "
                 f"N_eval: {result['n_evaluations']}, "
                 f"approx_ratio: {approx_ratio:.4f}")

        vqe_results.append({
            "ansatz_reps":   reps,
            "n_qubits":      M,
            "n_parameters":  ansatz.num_parameters,
            "best_energy":   result["best_energy"],
            "n_evaluations": result["n_evaluations"],
            "approx_ratio":  approx_ratio,
            "bf_optimum":    bf_min,
        })

        # Convergence
        conv_df = pd.DataFrame(result["convergence"], columns=["iteration", "energy"])
        conv_df["reps"] = reps
        conv_df.to_csv(RESULTS / f"vqe_convergence_reps{reps}.csv", index=False)

    res_df = pd.DataFrame(vqe_results)
    res_df.to_csv(RESULTS / "vqe_performance.csv", index=False)
    log.info(f"\n[OK] VQE results saved: {RESULTS / 'vqe_performance.csv'}")
    log.info("\nVQE Summary:")
    log.info(res_df.to_string(index=False))


if __name__ == "__main__":
    main()
