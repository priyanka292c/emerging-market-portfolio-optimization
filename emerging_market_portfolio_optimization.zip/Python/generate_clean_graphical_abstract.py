import matplotlib.pyplot as plt
import matplotlib.patches as patches
import os

fig = plt.figure(figsize=(16, 9), dpi=300)
fig.patch.set_facecolor("#FFFFFF")
ax = fig.add_axes([0, 0, 1, 1])
ax.axis("off")

# Top Banner
title_box = patches.FancyBboxPatch((0.03, 0.86), 0.94, 0.11, boxstyle="round,pad=0.015",
                                  facecolor="#0A2540", edgecolor="none")
ax.add_patch(title_box)

ax.text(0.50, 0.935, "Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market",
        color="white", fontsize=14.5, fontweight="bold", ha="center", va="center")
ax.text(0.50, 0.888, "Evidence from Borsa Istanbul -- Integrated Quantitative Architecture, Implementation Trade-Offs & Quantum Surrogate Benchmark",
        color="#81D4FA", fontsize=11.5, ha="center", va="center", style="italic")

# Cards Configuration: 2 rows of 3 cards
# Row 1 (Top): Data & Factors -> Regime Filtering -> Two-Stage Optimization
# Row 2 (Bottom): Empirical Outcomes -> Trade-Off vs Passive -> Quantum Surrogate Benchmark

boxes = [
    # Box 1: Data & Features
    {
        "x": 0.03, "y": 0.46, "w": 0.29, "h": 0.36,
        "title": "1. Empirical Foundation & ML Factors",
        "bg": "#F0F4F8", "border": "#1976D2", "title_col": "#0D47A1",
        "lines": [
            ("• Market Laboratory:", True, "#0D47A1"),
            ("   Borsa Istanbul Institutional Core (31 Equities)", False, "#333333"),
            ("   2010–2026 (4,257 Days, 147 Walk-Forward Folds)", False, "#333333"),
            ("• 6 Candidate Factors (60-Day KAP Lag):", True, "#0D47A1"),
            ("   Momentum · Size · Volatility · Liquidity · Value · Profitability", False, "#333333"),
            ("   Value/Profitability: sparse point-in-time coverage; neutral imputation", False, "#555555"),
            ("• ML Walk-Forward Ensembles (EN, RF, XGB):", True, "#0D47A1"),
            ("   Directional Accuracy: 55.10%–56.86%; primary PT-test p < 10⁻¹⁷", True, "#D32F2F"),
        ]
    },
    # Box 2: Regime Filtering & Risk
    {
        "x": 0.355, "y": 0.46, "w": 0.29, "h": 0.36,
        "title": "2. Regime Conditioning & Tail Risk",
        "bg": "#F5F7FA", "border": "#388E3C", "title_col": "#1B5E20",
        "lines": [
            ("• 4-State Gaussian HMM Regime Filter:", True, "#1B5E20"),
            ("   Bear · Bull · Normal · Strong Bull", True, "#2E7D32"),
            ("   Walk-forward filtered probabilities P(S_t | Y_1:t)", False, "#333333"),
            ("   No future observations used", False, "#555555"),
            ("• Coherent Risk & Shrinkage Covariance:", True, "#1B5E20"),
            ("   Ledoit–Wolf Linear Shrinkage (Mitigates Ill-Conditioning)", False, "#333333"),
            ("   Empirical Rockafellar–Uryasev CVaR (95% Tail, 20 bps TC)", False, "#333333"),
        ]
    },
    # Box 3: Two-Stage Optimization Heuristic
    {
        "x": 0.68, "y": 0.46, "w": 0.29, "h": 0.36,
        "title": "3. Two-Stage Decomposition Heuristic",
        "bg": "#FFF8E1", "border": "#F57C00", "title_col": "#E65100",
        "lines": [
            ("• Monolithic MIQP Challenge:", True, "#E65100"),
            ("   Binary Selection + Continuous Covariance + CVaR", False, "#333333"),
            ("   Stalls Standard Solvers (18.5s+ latency per fold)", False, "#777777"),
            ("• Decoupled Two-Stage Solution:", True, "#E65100"),
            ("   Stage 1: HiGHS MILP Discrete Selection (K ≤ 10)", False, "#333333"),
            ("   Stage 2: Clarabel Conic QP Continuous Allocation", False, "#333333"),
            ("   Mean Total Latency: 0.27s (100% Primal Feasibility)", True, "#2E7D32"),
        ]
    },
    # Box 4: Model E Performance
    {
        "x": 0.03, "y": 0.05, "w": 0.29, "h": 0.37,
        "title": "4. Model E Realized Performance",
        "bg": "#E8F5E9", "border": "#2E7D32", "title_col": "#1B5E20",
        "lines": [
            ("• Nominal Turkish Lira Performance:", True, "#1B5E20"),
            ("   Realized Geometric CAGR: 41.14%", True, "#2E7D32"),
            ("   14%-Hurdle Sharpe Ratio: 0.8389", True, "#2E7D32"),
            ("   Conventional risk-free proxy Sharpe: 0.7698", False, "#1B5E20"),
            ("   Annualized Volatility: 31.75% | Turnover: 90.05%", False, "#333333"),
            ("• Foreign-Investor USD & Real Returns:", True, "#1B5E20"),
            ("   USD CAGR: 9.70% (USD Sharpe: 0.4000)", True, "#0D47A1"),
            ("   Domestic Real CAGR: 9.84% (CPI-Adjusted)", True, "#0D47A1"),
            ("   USD-denominated CAGR (9.70%) close to real CAGR (9.84%),", False, "#444444"),
            ("   indicating that currency depreciation & inflation materially", False, "#444444"),
            ("   reduce nominal TRY return in real or foreign-currency terms", False, "#444444"),
        ]
    },
    # Box 5: Trade-Offs vs Passive
    {
        "x": 0.355, "y": 0.05, "w": 0.29, "h": 0.37,
        "title": "5. Implementation & Risk Trade-Offs",
        "bg": "#FFF3E0", "border": "#D84315", "title_col": "#BF360C",
        "lines": [
            ("• Realized Downside Metrics (OOS):", True, "#BF360C"),
            ("   Formation-Period Optimized CVaR: 13.90%", False, "#333333"),
            ("   Realized Out-of-Sample CVaR: 14.12%", False, "#333333"),
            ("   Realized Maximum Drawdown: 37.24%", False, "#333333"),
            ("• Realistic Comparison vs Passive:", True, "#BF360C"),
            ("   Equal Weight: OOS CVaR 10.68% | MDD 24.75%", False, "#444444"),
            ("   Risk Parity: OOS CVaR 10.25% | MDD 23.10%", False, "#444444"),
            ("   Model E Trades Return/Drawdown for Implementation", True, "#D84315"),
        ]
    },
    # Box 6: Quantum Surrogate Benchmark
    {
        "x": 0.68, "y": 0.05, "w": 0.29, "h": 0.37,
        "title": "6. Controlled 12-Qubit Quantum Surrogate",
        "bg": "#EDE7F6", "border": "#512DA8", "title_col": "#311B92",
        "lines": [
            ("• Controlled 12-Qubit Quantum Surrogate:", True, "#311B92"),
            ("   4 assets × 3 bits = 12 logical qubits", False, "#333333"),
            ("   Classical exact enumeration vs QAOA/VQE", False, "#333333"),
            ("• Algorithmic Benchmarking (w_max = 0.25):", True, "#311B92"),
            ("   Classical Exact Search: 20 ms (E_min = -24.58)", False, "#333333"),
            ("   VQE TwoLocal: α = 0.9954 | QAOA (p=2): α = 0.9539", False, "#333333"),
            ("   No quantum computational advantage was observed for the", True, "#C2185B"),
            ("   investigated 12-qubit instances under the tested simulation conditions.", True, "#C2185B"),
        ]
    }
]

for b in boxes:
    # Card Background
    card = patches.FancyBboxPatch((b["x"], b["y"]), b["w"], b["h"], boxstyle="round,pad=0.015",
                                 facecolor=b["bg"], edgecolor=b["border"], linewidth=2)
    ax.add_patch(card)
    
    # Title
    ax.text(b["x"] + b["w"]/2, b["y"] + b["h"] - 0.035, b["title"],
            fontsize=12, fontweight="bold", color=b["title_col"], ha="center", va="center")
    
    # Text Lines
    start_y = b["y"] + b["h"] - 0.070
    gap = 0.029 if len(b["lines"]) >= 9 else 0.033
    for idx, (txt, bold, col) in enumerate(b["lines"]):
        ax.text(b["x"] + 0.015, start_y - idx * gap, txt,
                fontsize=9.0 if len(b["lines"]) >= 9 else 9.5,
                fontweight="bold" if bold else "normal", color=col, ha="left", va="center")

# Connecting Arrows
ax.annotate("", xy=(0.345, 0.64), xytext=(0.325, 0.64),
            arrowprops=dict(arrowstyle="->", lw=2.5, color="#1976D2"))
ax.annotate("", xy=(0.670, 0.64), xytext=(0.650, 0.64),
            arrowprops=dict(arrowstyle="->", lw=2.5, color="#388E3C"))
ax.annotate("", xy=(0.175, 0.435), xytext=(0.175, 0.455),
            arrowprops=dict(arrowstyle="->", lw=2.5, color="#F57C00"))
ax.annotate("", xy=(0.345, 0.235), xytext=(0.325, 0.235),
            arrowprops=dict(arrowstyle="->", lw=2.5, color="#2E7D32"))
ax.annotate("", xy=(0.670, 0.235), xytext=(0.650, 0.235),
            arrowprops=dict(arrowstyle="->", lw=2.5, color="#D84315"))

# Output paths
out_dirs = [
    r"D:\Quantum finance\22_09_2026\RIBAF_Submission\LaTeX\figures",
    r"D:\Quantum finance\22_09_2026\LaTeX\figures",
    r"D:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs\Graphical_Abstract",
    r"D:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs",
    r"D:\Quantum finance\22_09_2026\Submission_Package\Graphical_Abstract",
    r"D:\Quantum finance\22_09_2026\Figures\pdf",
    r"D:\Quantum finance\22_09_2026\Figures\png",
]

for od in out_dirs:
    os.makedirs(od, exist_ok=True)
    pdf_path = os.path.join(od, "graphical_abstract.pdf")
    png_path = os.path.join(od, "graphical_abstract.png")
    fig.savefig(pdf_path, bbox_inches="tight", dpi=300)
    fig.savefig(png_path, bbox_inches="tight", dpi=300)
    print(f"Exported clean graphical abstract to {od}")

plt.close(fig)
print("Graphical abstract generated successfully!")
