#!/usr/bin/env python3
"""
run_pipeline.py
===============
Master orchestration script. Runs all pipeline stages in sequence.
Checks inter-stage dependencies and logs overall progress.

Usage:
  python run_pipeline.py [--from STAGE] [--to STAGE] [--skip STAGE1,STAGE2]

Stages:
  01  data_pipeline
  02  factor_model
  03  ml_prediction
  04  regime_detection
  05  covariance
  06  cvar (self-test)
  07  classical_optimization
  08  qubo_builder (self-test)
  09  qaoa
  10  vqe
  11  noise_simulation
  12  backtest
  13  statistics
  14  robustness
  15  tables
  16  figures
"""

import sys
import subprocess
import logging
import argparse
import time
from pathlib import Path
from datetime import datetime

ROOT    = Path(__file__).resolve().parent.parent
PYTHON  = Path(__file__).resolve().parent
LOG_DIR = ROOT / "Logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "run_pipeline.log", mode="a", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

STAGES = [
    ("01", "01_data_pipeline.py",       "Data ingestion (BIST, 2010-2026)"),
    ("02", "02_factor_model.py",         "Point-in-time factor construction"),
    ("03", "03_ml_prediction.py",        "Walk-forward ML return forecasting"),
    ("04", "04_regime_detection.py",     "Walk-forward HMM regime detection"),
    ("05", "05_covariance.py",           "Covariance estimation (Sample/LW/EWMA)"),
    ("06", "06_cvar.py",                 "CVaR module self-test"),
    ("07", "07_classical_optimization.py","Classical portfolio optimisation"),
    ("08", "08_qubo_builder.py",         "QUBO builder self-test + Ising verify"),
    ("09", "09_qaoa.py",                 "QAOA quantum optimisation"),
    ("10", "10_vqe.py",                  "VQE quantum optimisation"),
    ("11", "11_noise_simulation.py",     "Quantum noise sensitivity analysis"),
    ("12", "12_backtest.py",             "Walk-forward backtesting"),
    ("13", "13_statistics.py",           "Statistical significance tests"),
    ("14", "14_robustness.py",           "Robustness analysis"),
    ("15", "15_generate_tables.py",      "Publication table generation"),
    ("16", "16_generate_figures.py",     "Publication figure generation"),
]

STAGE_OUTPUTS = {
    "01": ["Data/processed/prices.csv", "Data/processed/returns.csv"],
    "02": ["Data/processed/factors_monthly.csv"],
    "03": ["Data/processed/ml_forecasts.csv"],
    "04": ["Data/processed/regime_states.csv"],
    "05": ["Data/processed/cov_metadata.csv"],
    "07": [],   # checked by weight files
    "08": ["Data/processed/test_qubo_Q.npy"],
    "09": ["Results/qaoa_performance.csv"],
    "10": ["Results/vqe_performance.csv"],
    "11": ["Results/noise_sensitivity.csv"],
    "12": ["Results/portfolio_performance.csv"],
    "13": ["Results/statistical_tests.csv"],
    "14": ["Results/robustness_results.csv"],
    "15": ["Tables/csv/table01_dataset_description.csv"],
    "16": ["Figures/pdf/fig01_research_framework.pdf"],
}


def check_outputs(stage_id: str) -> bool:
    """Return True if all expected outputs of a stage exist."""
    expected = STAGE_OUTPUTS.get(stage_id, [])
    for p in expected:
        if not (ROOT / p).exists():
            return False
    return True


def run_stage(script: str, description: str) -> tuple[bool, float]:
    """Run a single pipeline stage. Returns (success, elapsed_seconds)."""
    script_path = PYTHON / script
    if not script_path.exists():
        log.error(f"Script not found: {script_path}")
        return False, 0.0

    log.info(f"  Running: {script}  [{description}]")
    t0 = time.time()
    result = subprocess.run(
        [sys.executable, str(script_path)],
        cwd=str(PYTHON),
        capture_output=False,   # let output stream directly
    )
    elapsed = time.time() - t0

    if result.returncode == 0:
        log.info(f"  [OK] Done in {elapsed:.1f}s")
        return True, elapsed
    else:
        log.error(f"  [FAIL] FAILED (returncode={result.returncode}) after {elapsed:.1f}s")
        return False, elapsed


def main():
    parser = argparse.ArgumentParser(description="Quantum Finance Pipeline Master Runner")
    parser.add_argument("--from", dest="from_stage", default="01",
                        help="Start from stage ID (e.g. '05')")
    parser.add_argument("--to",   dest="to_stage",   default="16",
                        help="Stop after stage ID (e.g. '12')")
    parser.add_argument("--skip", dest="skip",        default="",
                        help="Comma-separated stage IDs to skip")
    parser.add_argument("--continue-on-error", action="store_true",
                        help="Continue pipeline even if a stage fails")
    args = parser.parse_args()

    skip_set = set(s.strip() for s in args.skip.split(",") if s.strip())
    run_from = args.from_stage.zfill(2)
    run_to   = args.to_stage.zfill(2)

    log.info("=" * 70)
    log.info("QUANTUM FINANCE PIPELINE -- MASTER RUNNER")
    log.info(f"Start  : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    log.info(f"Stages : {run_from} -> {run_to}  (skip: {skip_set or 'none'})")
    log.info(f"Root   : {ROOT}")
    log.info("=" * 70)

    results = []
    pipeline_ok = True

    for stage_id, script, description in STAGES:
        if stage_id < run_from or stage_id > run_to:
            continue
        if stage_id in skip_set:
            log.info(f"\n[SKIP] Stage {stage_id}: {description}")
            continue

        log.info(f"\n{'─'*60}")
        log.info(f"[{stage_id}] {description}")
        log.info(f"{'─'*60}")

        ok, elapsed = run_stage(script, description)
        results.append({
            "stage": stage_id, "script": script,
            "status": "OK" if ok else "FAILED",
            "elapsed_s": round(elapsed, 1),
        })

        if not ok:
            pipeline_ok = False
            if not args.continue_on_error:
                log.error(f"\nPipeline stopped at stage {stage_id}. "
                           f"Use --continue-on-error to proceed.")
                break
        else:
            # Verify expected outputs
            if not check_outputs(stage_id):
                log.warning(f"  [WARN] Expected outputs for stage {stage_id} not all found.")

    # Summary
    log.info("\n" + "=" * 70)
    log.info("PIPELINE SUMMARY")
    log.info("=" * 70)
    total_time = sum(r["elapsed_s"] for r in results)
    for r in results:
        status_icon = "[OK]" if r["status"] == "OK" else "[FAIL]"
        log.info(f"  {status_icon} [{r['stage']}] {r['script']:40s} {r['elapsed_s']:6.1f}s")
    log.info(f"\nTotal elapsed: {total_time:.1f}s ({total_time/60:.1f} min)")
    log.info(f"Status: {'ALL STAGES COMPLETE [OK]' if pipeline_ok else 'SOME STAGES FAILED [FAIL]'}")
    log.info("=" * 70)

    sys.exit(0 if pipeline_ok else 1)


if __name__ == "__main__":
    main()
