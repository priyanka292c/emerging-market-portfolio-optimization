﻿import os
import re

BASE_DIRS = [
    r"D:\Quantum finance\22_09_2026\RIBAF_Submission\LaTeX",
    r"D:\Quantum finance\22_09_2026\LaTeX"
]

def run_updates():
    for base_dir in BASE_DIRS:
        sec = os.path.join(base_dir, "sections")
        
        # 1. main.tex
        main_p = os.path.join(base_dir, "main.tex")
        with open(main_p, "r", encoding="utf-8") as f:
            mt = f.read()
            
        old_abs_match = re.search(r"\\begin\{abstract\}.*?\\end\{abstract\}", mt, flags=re.DOTALL)
        if old_abs_match:
            new_abs = r"""\begin{abstract}
\noindent Portfolio allocation in emerging equity markets is complicated by structural regime shifts, non-Gaussian tail risk, and execution frictions. Existing literature often examines factor pricing, regime switching, Conditional Value-at-Risk (CVaR), and transaction costs separately, leaving their joint implementation under cardinality constraints less explored. We propose an integrated portfolio optimization architecture combining point-in-time multi-factor modeling, latent Markov regime conditioning, Ledoit--Wolf covariance shrinkage, empirical Rockafellar--Uryasev CVaR, and a two-stage decomposition heuristic using HiGHS MILP asset selection and Clarabel conic allocation. Borsa Istanbul provides an informative emerging-market setting characterized by macroeconomic volatility, currency shocks, and execution frictions. The empirical results apply to a survivorship-conditioned 31-stock institutional core universe and should not be interpreted as estimates of the unconditional historical Borsa Istanbul opportunity set. Using monthly walk-forward evaluation from 2014 to July 2026 with a conservative 60-calendar-day information-availability lag, Model E ($K \le 10$) delivers a geometric CAGR of 41.14\% in nominal Turkish Lira (equivalent to 9.70\% in USD terms and 9.84\% in real inflation-adjusted terms; compounded mean annualization: 47.94\%), annualized volatility of 31.75\%, and a 14\%-hurdle-adjusted Sharpe ratio of 0.8389 relative to a standardized 14\% annual benchmark hurdle rate (conventional risk-free proxy Sharpe: 0.7698; foreign-investor USD Sharpe: 0.4000). Model E minimizes formation-period CVaR (13.90\%) under the imposed cardinality and transaction-cost constraints, while realized out-of-sample CVaR is 14.12\% (comparable to Model D's 14.08\%) with average monthly turnover of 90.05\%. Model E does not dominate simple passive benchmarks on realized tail risk or drawdown, but provides a computationally feasible framework that explicitly incorporates tail risk and transaction costs, illustrating real-world implementation trade-offs rather than universal performance dominance. A reduced 12-qubit surrogate of the portfolio-selection problem ($N_q = 4$ assets, $w_{\max} = 0.25$, linear tail-risk surrogate) is evaluated using QAOA and VQE under simulated noisy-circuit conditions. Classical exact search solves the benchmark in milliseconds, and no quantum computational advantage is observed under the tested simulation conditions.
\end{abstract}"""
            mt = mt[:old_abs_match.start()] + new_abs + mt[old_abs_match.end():]
            with open(main_p, "w", encoding="utf-8") as f:
                f.write(mt)
            print(f"Updated abstract in {main_p}")
            
        # 2. 01_introduction.tex
        p1 = os.path.join(sec, "01_introduction.tex")
        with open(p1, "r", encoding="utf-8") as f:
            t1 = f.read()
        t1 = t1.replace(
            "To provide empirical grounding, we deploy this architecture on Borsa Istanbul (Turkey), an informative emerging-market laboratory characterized by substantial macroeconomic volatility, inflation dynamics, and exchange-rate depreciation.",
            r"""To provide empirical grounding, we deploy this architecture on Borsa Istanbul (Turkey), an informative emerging-market laboratory characterized by substantial macroeconomic volatility, inflation dynamics, and exchange-rate depreciation. We emphasize at the outset that our empirical results apply to a survivorship-conditioned 31-stock institutional core universe of continuously traded equities and should not be interpreted as estimates of the unconditional historical Borsa Istanbul opportunity set. Furthermore, while nominal domestic returns reflect Turkey's high-inflation environment (geometric CAGR of 41.14\%), we evaluate performance from the perspective of both domestic real investors (real CAGR of 9.84\%) and international USD investors (USD CAGR of 9.70\%), demonstrating that domestic nominal gains are closely aligned with long-run currency depreciation and purchasing power parity."""
        )
        t1 = t1.replace(
            "We show that the complete Model E architecture effectively compresses downside risk while maintaining competitive risk-adjusted returns.",
            r"""We show that Model E provides a computationally feasible, cardinality-constrained portfolio construction framework that explicitly incorporates tail risk and transaction costs, with empirical results illustrating the associated risk--return--turnover trade-offs rather than universal performance dominance."""
        )
        t1 = t1.replace("a controlled 12-qubit quantum benchmark", "a reduced 12-qubit quantum surrogate of the portfolio-selection problem")
        with open(p1, "w", encoding="utf-8") as f:
            f.write(t1)
        print(f"Updated {p1}")

        # 3. 04_data_and_methodology.tex
        p4 = os.path.join(sec, "04_data_and_methodology.tex")
        with open(p4, "r", encoding="utf-8") as f:
            t4 = f.read()
        t4 = t4.replace(
            "State identification is performed out-of-sample using expanding windows to avoid look-ahead bias.",
            r"""State identification is performed out-of-sample using expanding windows to avoid look-ahead bias. Crucially, only causal filtered probabilities $P(S_t \mid Y_{1:t})$ available at the formation date are used; smoothed probabilities incorporating future observations are never used in portfolio formation."""
        )
        t4 = t4.replace(
            "All factors are standardized cross-sectionally to zero mean and unit variance each month.",
            r"""All factors are standardized cross-sectionally to zero mean and unit variance each month. Because quarterly financial disclosures under CMB/SPK and KAP regulations yield point-in-time Value (Book-to-Market) and Profitability (ROE) coverage for only 7.1\% of the complete 2011--2026 firm-month panel, unobserved historical observations are assigned a standardized z-score of 0.0 (representing a neutral cross-sectional median imputation). Consequently, early-sample machine learning models rely predominantly on the four 100\%-coverage market/technical factors (Momentum, Size, Volatility, Liquidity). As demonstrated in Table~\ref{tab:missing_data_robustness}, restricting the factor model strictly to these four pure market factors yields nearly identical directional accuracy (57.29\% vs.\ 56.65\%) and downstream portfolio performance, confirming that our results are not driven by structural artifacts of zero imputation."""
        )
        t4 = t4.replace(
            r"Performance evaluation is conducted relative to a standardized 14% annual benchmark hurdle rate ($r_h = 14\%$ p.a., corresponding to a monthly equivalent of $(1.14)^{1/12}-1 \approx 1.098\%$) applied consistently across all models.",
            r"""Performance evaluation is conducted relative to a standardized 14\% annual benchmark hurdle rate ($r_h = 14\%$ p.a., corresponding to a monthly equivalent of $(1.14)^{1/12}-1 \approx 1.098\%$) applied consistently across all models. The 14\% hurdle represents the historical sample average policy/repo rate of the Central Bank of the Republic of Turkey (TCMB) across the pre-hyperinflation formation period (2014--2020), which served as an institutional cost-of-capital benchmark. To eliminate any reliance on a single hurdle choice, we also report performance across alternative hurdle rates ($r_h \in \{0\%, 10\%, 14\%, 20\%, 25\%\}$) and an empirical time-varying TCMB repo rate proxy in Table~\ref{tab:hurdle_sensitivity}."""
        )
        t4 = t4.replace(
            r"\subsection{Controlled Combinatorial Quantum Benchmark}",
            r"\subsection{Reduced 12-Qubit Quantum Surrogate of the Portfolio-Selection Problem}"
        )
        t4 = t4.replace(
            "A reduced four-asset, 12-qubit combinatorial benchmark was constructed to evaluate QAOA and VQE against an exact classical solution.",
            r"""A reduced four-asset, 12-qubit combinatorial surrogate was constructed to evaluate QAOA and VQE against an exact classical solution. We emphasize that this reduced surrogate is not an implementation of the full 31-asset Model~E master problem. Specifically, to satisfy the unit budget constraint $\sum_{i=1}^4 w_i = 1.0$ across only four assets, the maximum asset weight is adjusted to $w_{\max} = 0.25$ (whereas the classical 31-asset model uses $w_{\max} = 0.20$). Furthermore, the quantum objective incorporates a linear tail-loss surrogate rather than the full empirical scenario CVaR formulation, as non-smooth auxiliary variables cannot be embedded into a compact QUBO without introducing hundreds of auxiliary slack qubits."""
        )
        with open(p4, "w", encoding="utf-8") as f:
            f.write(t4)
        print(f"Updated {p4}")

        # 4. 05_empirical_results.tex
        p5 = os.path.join(sec, "05_empirical_results.tex")
        with open(p5, "r", encoding="utf-8") as f:
            t5 = f.read()

        old_sh_pat = r"""\textbf{Sharpe Ratio and Benchmark Hurdle Convention:} In high-inflation emerging markets where central bank policy rates fluctuated across the sample horizon, excess returns and Sharpe ratios are evaluated relative to a standardized 14\% annual benchmark hurdle rate ($r_h = 14\%$~p.a., $r_{h,m} = (1.14)^{1/12} - 1 \approx 1.098\%$ monthly) used consistently across strategies; this hurdle is not interpreted as a time-varying risk-free rate:
\begin{equation}
\text{SR} = \frac{\mathbb{E}[r_t - r_{h,m}]}{\sigma(r_t - r_{h,m})} \times \sqrt{12}.
\end{equation}
For Model E: $\text{SR} = (0.022194 / 0.091647) \times \sqrt{12} = 0.8389$ ($\text{ddof}=0$; $\text{ddof}=1$ yields 0.8360; see Supplementary Table~S.14 for independent audit). Because the analysis uses a standardized hurdle rather than a time-varying risk-free asset return series, the reported Sharpe ratios should be interpreted as hurdle-relative performance measures rather than conventional risk-free-rate Sharpe ratios. Relative rankings remain invariant across alternative benchmark rates ($r_h \in \{0\%, 10\%, 14\%, 20\%\}$)."""

        new_sh_pat = r"""\textbf{Hurdle-Adjusted Sharpe Ratio and Benchmark Rate Sensitivity:} In high-inflation emerging markets where central bank policy rates fluctuated substantially across the sample horizon, excess returns and risk-adjusted ratios are evaluated relative to a standardized 14\% annual benchmark hurdle rate ($r_h = 14\%$~p.a., $r_{h,m} = (1.14)^{1/12} - 1 \approx 1.098\%$ monthly) used consistently across strategies, reflecting the historical average TCMB policy rate across the pre-hyperinflation formation period (2014--2020); this hurdle is not interpreted as a time-varying risk-free rate:
\begin{equation}
\text{SR}(r_h) = \frac{\mathbb{E}[r_t - r_{h,m}]}{\sigma(r_t - r_{h,m})} \times \sqrt{12}.
\end{equation}
For Model E, the baseline 14\%-hurdle-adjusted Sharpe ratio is $\text{SR} = (0.022194 / 0.091647) \times \sqrt{12} = 0.8389$ ($\text{ddof}=0$; $\text{ddof}=1$ yields 0.8360; see Supplementary Table~S.14 for independent audit). To directly address the sensitivity of this benchmark convention, Table~\ref{tab:hurdle_sensitivity} reports risk-adjusted return ratios across alternative hurdle rates ($0\%, 10\%, 14\%, 20\%, 25\%$) as well as an empirical time-varying TCMB one-week repo rate proxy ($\bar{r}_f = 16.5\%$). Relative strategy rankings remain invariant across all hurdle rates, confirming that strategy comparison is robust to benchmark selection.

\input{tables/table_hurdle_sensitivity.tex}

\textbf{Foreign-Investor USD and Real Inflation-Adjusted Performance:} For international investors, nominal Turkish Lira returns do not represent the realized investment experience. Table~\ref{tab:currency_robustness} presents portfolio performance converted into US Dollars using point-in-time exchange rates from \texttt{macro.csv} ($R_t^{\text{USD}} = (1 + R_t^{\text{TRY}}) \frac{\text{FX}_{t-1}}{\text{FX}_t} - 1$), as well as domestic real returns deflated by Turkish CPI inflation. Over the 147-month evaluation horizon, USD/TRY depreciated from 2.12 to 33.50. Under this foreign-investor perspective, Model~E delivers a geometric CAGR of 9.70\% in USD (annualized volatility 34.25\%, USD Sharpe 0.4000 relative to US T-bills), which aligns closely with its domestic inflation-adjusted real CAGR of 9.84\%. This alignment confirms that Turkey's high nominal returns reflect long-run purchasing power parity and currency pass-through rather than anomalous equity-market outperformance.

\input{tables/table_currency_robustness.tex}"""

        t5 = t5.replace(old_sh_pat, new_sh_pat)
        
        old_it2 = r"""\item \textbf{Model E Risk--Return--Implementation Trade-Off:} Model E achieves a realized geometric CAGR of 41.14\% (compounded annualization of 47.94\%), annualized volatility of 31.75\%, and a Sharpe ratio of 0.8389. While unconstrained factor models (Model B: Sharpe 0.9207, CAGR 46.12\%; Model C: Sharpe 0.9239, CAGR 45.75\%) generate higher unconstrained returns by investing across all 31 assets, Model E operates under strict institutional cardinality ($K \le 10$) and explicit tail-loss penalties. This constraint introduces a deliberate risk--return--implementation trade-off: Model E accepts a modest reduction in unconstrained return to compress downside tail risk and maintain operational implementability. Model E represents a constrained risk--return--implementation trade-off rather than a universally dominant strategy."""
        
        new_it2 = r"""\item \textbf{Model E Risk--Return--Implementation Trade-Off:} Model E achieves a realized geometric CAGR of 41.14\% (compounded annualization of 47.94\%; USD CAGR of 9.70\%; real CAGR of 9.84\%), annualized volatility of 31.75\%, and a 14\%-hurdle-adjusted Sharpe ratio of 0.8389. While unconstrained factor models (Model B: Sharpe 0.9207, CAGR 46.12\%; Model C: Sharpe 0.9239, CAGR 45.75\%) generate higher unconstrained returns by investing across all 31 assets, Model E operates under strict institutional cardinality ($K \le 10$) and explicit tail-loss penalties. Model E trades return and some realized downside metrics for cardinality-constrained implementation and explicit formation tail-risk optimization. Crucially, Model E does not dominate simple passive allocation on realized downside risk or drawdown: Equal Weight and Risk Parity achieve lower realized CVaR (10.68\% and 10.25\%) and lower maximum drawdown (24.75\% and 23.10\%) than Model E (14.12\% and 37.24\%). Model E represents a practical institutional framework illustrating implementation trade-offs rather than universal performance dominance."""

        t5 = t5.replace(old_it2, new_it2)
        
        extra_txt = r"""
\textbf{Computational Feasibility and Monolithic Solver Comparison:} Table~\ref{tab:monolithic_benchmark} compares the computational performance of our two-stage decomposition heuristic against a monolithic MIQP solver. While monolithic MIQP requires specialized commercial mixed-integer non-linear solvers (such as \texttt{Gurobi} or \texttt{SCIP}) that exhibit subproblem timeouts and unpredictable branch-and-cut latency, the two-stage heuristic solves Stage~1 via \texttt{HiGHS} in 0.2358 seconds and Stage~2 via \texttt{CLARABEL} in 0.0322 seconds (mean total latency of 0.2680 seconds per fold), achieving 100\% primal feasibility without stalling.

\input{tables/table_monolithic_benchmark.tex}

\textbf{Factor Missing-Data Robustness:} Table~\ref{tab:missing_data_robustness} evaluates the sensitivity of the machine-learning pipeline to the handling of unavailable accounting disclosures. Comparing the baseline 6-factor model (with zero imputation for early unobserved Value and Profitability disclosures) against a restricted 4-factor pure-market model confirms that directional accuracy (57.29\% vs.\ 56.65\%) and downstream Model~E performance remain virtually unchanged, demonstrating that factor predictability is anchored in high-coverage market signals.

\input{tables/table_missing_data_robustness.tex}
"""
        if r"\input{tables/table_monolithic_benchmark.tex}" not in t5:
            t5 = t5.replace(r"\subsection{Tail-Risk Decomposition and Downside Protection}", extra_txt + "\n" + r"\subsection{Tail-Risk Decomposition and Downside Protection}")

        t5 = t5.replace(
            "Model E achieves the lowest in-sample optimized 95% CVaR among Models A--E (13.90%), while its realized out-of-sample CVaR is 14.12%, close to Model D's 14.08% (evaluating actual monthly returns in the worst 5% out-of-sample periods).",
            r"""Model E minimizes in-sample formation-period 95\% CVaR (13.90\%, lowest among Models A--E), while its realized out-of-sample CVaR is 14.12\%, closely matching Model D's 14.08\%. We emphasize that in-sample optimization does not guarantee lowest realized out-of-sample tail risk: unmanaged passive allocations (Equal Weight and Risk Parity) achieve lower realized OOS CVaR (10.68\% and 10.25\%) due to zero turnover and broad cross-sectional diversification."""
        )
        
        with open(p5, "w", encoding="utf-8") as f:
            f.write(t5)
        print(f"Updated {p5}")

        # 5. 06_discussion.tex
        p6 = os.path.join(sec, "06_discussion.tex")
        with open(p6, "r", encoding="utf-8") as f:
            t6 = f.read()
        t6 = t6.replace(
            "Model E represents a constrained risk--return--implementation trade-off rather than a universally dominant strategy.",
            r"""Model E provides a computationally feasible, cardinality-constrained portfolio construction framework that explicitly incorporates tail risk and transaction costs, with empirical results illustrating the associated risk--return--turnover trade-offs rather than universal performance dominance."""
        )
        with open(p6, "w", encoding="utf-8") as f:
            f.write(t6)
        print(f"Updated {p6}")

        # 6. 08_limitations_and_future_research.tex
        p8 = os.path.join(sec, "08_limitations_and_future_research.tex")
        with open(p8, "r", encoding="utf-8") as f:
            t8 = f.read()
        t8 = t8.replace(
            "Our 31-asset universe requires continuous listing and financial disclosure coverage across the full 2010--July 2026 sample period",
            r"Our 31-asset universe requires continuous listing and financial disclosure coverage across the full 2010--July 2026 sample period (survivorship conditioning)"
        )
        with open(p8, "w", encoding="utf-8") as f:
            f.write(t8)
        print(f"Updated {p8}")

        # 7. 09_conclusion.tex
        p9 = os.path.join(sec, "09_conclusion.tex")
        with open(p9, "r", encoding="utf-8") as f:
            t9 = f.read()
        t9 = t9.replace(
            "Model E achieves a CAGR of 41.14% and Sharpe ratio of 0.8389",
            r"Model E achieves a CAGR of 41.14% (USD CAGR of 9.70%; real CAGR of 9.84%) and a 14\%-hurdle-adjusted Sharpe ratio of 0.8389"
        )
        t9 = t9.replace("controlled 12-qubit benchmark", "reduced 12-qubit quantum surrogate")
        with open(p9, "w", encoding="utf-8") as f:
            f.write(t9)
        print(f"Updated {p9}")

    print("All section updates completed successfully!")

if __name__ == "__main__":
    run_updates()
