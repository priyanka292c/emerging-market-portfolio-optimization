import urllib.request
import json

dois = [
    ('demiguel2009optimal', '10.1093/rfs/hhm075'),
    ('hansen2005test', '10.1198/073500105000000063'),
    ('politis1994stationary', '10.1080/01621459.1994.10476870'),
    ('white2000reality', '10.1111/1468-0262.00152'),
]

for key, doi in dois:
    url = f'https://api.crossref.org/works/{doi}'
    req = urllib.request.Request(url, headers={'User-Agent': 'AntigravityVerifier/1.0 (mailto:scholar@example.org)'})
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode('utf-8'))['message']
            print(f"[SUCCESS] {key}: {data.get('title')} | Authors: {len(data.get('author', []))}")
    except Exception as e:
        print(f"[FAIL] {key}: {e}")
