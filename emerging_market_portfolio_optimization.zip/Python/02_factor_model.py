"""
02_factor_model.py
==================
Constructs six point-in-time factor signals for each asset at each
monthly portfolio-formation date. Strictly no look-ahead bias.

Factors implemented:
  1. Momentum    -- 12-1 month cumulative return (Jegadeesh-Titman)
  2. Size        -- log(price x shares_approx) -- approximation documented
  3. Value       -- Book-to-Market proxy: book_equity / market_cap
  4. Profitability -- ROE = net_income / book_equity (trailing annual)
  5. Volatility  -- 60-day rolling std of daily log returns
  6. Liquidity   -- 20-day avg daily turnover (volumexprice / market_cap)

Point-in-time discipline:
  - Momentum, Volatility, Liquidity: use only prices/volumes strictly
    before the formation date -> zero look-ahead by construction.
  - Value, Profitability: use the most recently *reported* fundamental
    (report_date <= formation_date) from fundamentals.csv.
  - Size: uses price x shares_outstanding (approximation) -- limitation noted.

Outputs:
  - Data/processed/factors_monthly.csv : factors at each month-end
  - Logs/02_factor_model.log
"""

import sys
import logging
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
LOG_DIR   = ROOT / "Logs"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "02_factor_model.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
MOM_LONG  = 12   # months
MOM_SKIP  = 1    # skip last month
VOL_DAYS  = 60   # rolling volatility window (trading days)
LIQ_DAYS  = 20   # rolling liquidity window (trading days)
MIN_OBS_MOM = 200  # minimum trading days required to compute momentum

# ---------------------------------------------------------------------------
# PointInTimeDataset
# ---------------------------------------------------------------------------

class PointInTimeDataset:
    """
    Enforces point-in-time discipline for all factor computations.
    At each formation_date, only data with index < formation_date is used
    for price-based factors, and only fundamentals with
    report_date <= formation_date are used for fundamental factors.
    """

    def __init__(self, prices: pd.DataFrame, volumes: pd.DataFrame,
                 fundamentals: pd.DataFrame):
        self.prices       = prices.copy()
        self.volumes      = volumes.copy()
        self.fundamentals = fundamentals.copy() if fundamentals is not None else pd.DataFrame()

        # Ensure datetime index
        self.prices.index  = pd.to_datetime(self.prices.index)
        self.volumes.index = pd.to_datetime(self.volumes.index)
        if not self.fundamentals.empty:
            self.fundamentals["report_date"] = pd.to_datetime(
                self.fundamentals["report_date"])
            if "shares_outstanding" in self.fundamentals.columns:
                self.shares_map = (
                    self.fundamentals.dropna(subset=["shares_outstanding"])
                    .groupby("ticker")["shares_outstanding"]
                    .last()
                    .to_dict()
                )
            else:
                self.shares_map = {}
        else:
            self.shares_map = {}

    def prices_as_of(self, date: pd.Timestamp) -> pd.Series:
        """Last available price strictly before (or on) date."""
        mask = self.prices.index <= date
        if not mask.any():
            return pd.Series(dtype=float)
        return self.prices.loc[mask].iloc[-1]

    def price_history_before(self, date: pd.Timestamp, n_days: int) -> pd.DataFrame:
        """Last n_days of prices strictly up to date."""
        mask = self.prices.index <= date
        sub  = self.prices.loc[mask]
        return sub.iloc[-n_days:] if len(sub) >= n_days else sub

    def return_history_before(self, date: pd.Timestamp, n_days: int) -> pd.DataFrame:
        """Log returns computed on prices up to date, last n_days of returns."""
        sub  = self.price_history_before(date, n_days + 1)
        if len(sub) < 2:
            return pd.DataFrame()
        ret = np.log(sub / sub.shift(1)).dropna()
        return ret.iloc[-n_days:]

    def volume_history_before(self, date: pd.Timestamp, n_days: int) -> pd.DataFrame:
        """Last n_days of volume strictly up to date."""
        mask = self.volumes.index <= date
        sub  = self.volumes.loc[mask]
        return sub.iloc[-n_days:] if len(sub) >= n_days else sub

    def latest_fundamental(self, date: pd.Timestamp,
                           field: str, ticker: str):
        """
        Return the most recent value of `field` for `ticker` where
        report_date <= date. Returns NaN if unavailable (with fallback for shares).
        """
        if self.fundamentals.empty:
            if field == "shares_outstanding":
                return self.shares_map.get(ticker, np.nan)
            return np.nan
        mask = (
            (self.fundamentals["ticker"] == ticker) &
            (self.fundamentals["report_date"] <= date) &
            self.fundamentals[field].notna()
        )
        sub = self.fundamentals.loc[mask]
        if sub.empty:
            if field == "shares_outstanding":
                return self.shares_map.get(ticker, np.nan)
            return np.nan
        return float(sub.sort_values("report_date").iloc[-1][field])


# ---------------------------------------------------------------------------
# Individual factor functions
# ---------------------------------------------------------------------------

def compute_momentum(pit: PointInTimeDataset, date: pd.Timestamp,
                     long_months: int = 12, skip: int = 1) -> pd.Series:
    """
    Momentum = cumulative return from (date - long_months) to (date - skip months).
    Uses only prices strictly before date.
    """
    end_date   = date - pd.offsets.MonthBegin(skip)
    start_date = date - pd.offsets.MonthBegin(long_months)

    mask = (pit.prices.index >= start_date) & (pit.prices.index < end_date)
    sub  = pit.prices.loc[mask]
    if len(sub) < MIN_OBS_MOM // 4:   # at least 3 months of data
        return pd.Series(np.nan, index=pit.prices.columns)

    p_start = sub.iloc[0]
    p_end   = sub.iloc[-1]
    mom     = (p_end / p_start) - 1.0
    return mom


def compute_size(pit: PointInTimeDataset, date: pd.Timestamp) -> pd.Series:
    """
    Size = log(market_cap) where market_cap ~ price x shares_outstanding.
    Shares outstanding is approximated as constant (limitation documented).
    """
    price = pit.prices_as_of(date)
    # Shares outstanding from fundamentals (use most recent shares field if available)
    if not pit.fundamentals.empty and "shares_outstanding" in pit.fundamentals.columns:
        sizes = {}
        for ticker in price.index:
            shares = pit.latest_fundamental(date, "shares_outstanding", ticker)
            if not np.isnan(shares) and not np.isnan(price.get(ticker, np.nan)):
                sizes[ticker] = np.log(price[ticker] * shares + 1e-10)
            else:
                sizes[ticker] = np.nan
        return pd.Series(sizes)
    else:
        # Fallback: log price only (monotone proxy if shares unavailable)
        log.debug("Shares outstanding unavailable; using log(price) as size proxy.")
        return np.log(price.clip(lower=1e-10))


def compute_value(pit: PointInTimeDataset, date: pd.Timestamp) -> pd.Series:
    """
    Value = Book Equity / Market Cap (book-to-market ratio).
    Book equity uses point-in-time fundamental with reporting lag.
    """
    price = pit.prices_as_of(date)
    result = {}
    for ticker in price.index:
        be = pit.latest_fundamental(date, "book_equity", ticker)
        sh = pit.latest_fundamental(date, "shares_outstanding", ticker)
        p  = price.get(ticker, np.nan)
        if np.isnan(be) or np.isnan(sh) or np.isnan(p) or sh <= 0 or p <= 0:
            result[ticker] = np.nan
        else:
            mc = p * sh
            result[ticker] = be / mc if mc > 0 else np.nan
    return pd.Series(result)


def compute_profitability(pit: PointInTimeDataset, date: pd.Timestamp) -> pd.Series:
    """
    Profitability = ROE = Net Income (trailing 4 quarters) / Book Equity.
    Point-in-time: uses most recent reported values before date.
    """
    result = {}
    if pit.fundamentals.empty:
        return pd.Series(np.nan, index=pit.prices.columns)

    for ticker in pit.prices.columns:
        ni = pit.latest_fundamental(date, "net_income",   ticker)
        be = pit.latest_fundamental(date, "book_equity",  ticker)
        if np.isnan(ni) or np.isnan(be) or be == 0:
            result[ticker] = np.nan
        else:
            result[ticker] = ni / abs(be)
    return pd.Series(result)


def compute_volatility(pit: PointInTimeDataset, date: pd.Timestamp,
                       window: int = VOL_DAYS) -> pd.Series:
    """
    Volatility = annualised std dev of daily log returns over last `window` trading days.
    Entirely price-based -- zero look-ahead.
    """
    ret = pit.return_history_before(date, window)
    if ret.empty or len(ret) < window // 2:
        return pd.Series(np.nan, index=pit.prices.columns)
    return ret.std() * np.sqrt(252)


def compute_liquidity(pit: PointInTimeDataset, date: pd.Timestamp,
                      window: int = LIQ_DAYS) -> pd.Series:
    """
    Liquidity = avg daily turnover ratio = avg(volume x price) / market_cap_approx.
    Higher = more liquid.
    """
    prices_w = pit.price_history_before(date, window)
    volumes_w = pit.volume_history_before(date, window)

    if prices_w.empty or volumes_w.empty:
        return pd.Series(np.nan, index=pit.prices.columns)

    # Align
    common_idx = prices_w.index.intersection(volumes_w.index)
    pv   = prices_w.loc[common_idx]
    vv   = volumes_w.loc[common_idx]
    cols = pv.columns.intersection(vv.columns)
    if cols.empty:
        return pd.Series(np.nan, index=pit.prices.columns)

    dollar_vol = (pv[cols] * vv[cols]).mean()          # avg daily $ volume
    price_now  = pit.prices_as_of(date).reindex(cols)

    # Market cap approximation using shares_outstanding
    liq = {}
    for ticker in cols:
        sh = np.nan
        if not pit.fundamentals.empty and "shares_outstanding" in pit.fundamentals.columns:
            sh = pit.latest_fundamental(date, "shares_outstanding", ticker)
        mc = price_now.get(ticker, np.nan) * sh if not np.isnan(sh) else np.nan
        if np.isnan(mc) or mc <= 0:
            liq[ticker] = np.nan
        else:
            liq[ticker] = dollar_vol.get(ticker, np.nan) / mc
    return pd.Series(liq)


# ---------------------------------------------------------------------------
# Cross-sectional normalisation (rank-based z-score)
# ---------------------------------------------------------------------------

def rank_zscore(series: pd.Series) -> pd.Series:
    """Convert raw factor values to cross-sectional rank z-scores.
    Rank, then standardise. Robust to outliers."""
    s = series.dropna()
    if len(s) < 3:
        return series
    ranked = s.rank(pct=True)          # [0,1] percentile rank
    zscored = (ranked - ranked.mean()) / ranked.std()
    return series.reindex(zscored.index).combine_first(pd.Series(np.nan, index=series.index)).where(series.notna(), other=np.nan)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def build_factor_panel(formation_dates: pd.DatetimeIndex,
                       pit: PointInTimeDataset) -> pd.DataFrame:
    """
    Build the full factor panel: for each formation date, compute all 6
    factors for all assets and concatenate into a long-format DataFrame.
    """
    records = []
    for date in formation_dates:
        log.info(f"  Computing factors for {date.date()}")
        mom  = compute_momentum(pit, date)
        sz   = compute_size(pit, date)
        val  = compute_value(pit, date)
        prof = compute_profitability(pit, date)
        vol  = compute_volatility(pit, date)
        liq  = compute_liquidity(pit, date)

        tickers = pit.prices.columns
        for ticker in tickers:
            records.append({
                "date":          date,
                "ticker":        ticker,
                "momentum":      mom.get(ticker, np.nan),
                "size":          sz.get(ticker, np.nan),
                "value":         val.get(ticker, np.nan),
                "profitability": prof.get(ticker, np.nan),
                "volatility":    vol.get(ticker, np.nan),
                "liquidity":     liq.get(ticker, np.nan),
            })

    panel = pd.DataFrame(records)
    panel["date"] = pd.to_datetime(panel["date"])

    # Rank-normalise within each date (cross-sectional z-score)
    for f in ["momentum", "size", "value", "profitability", "volatility", "liquidity"]:
        def calc_z(group):
            valid = group.dropna()
            if len(valid) < 3:
                return pd.Series(0.0, index=group.index)
            ranked = valid.rank(pct=True)
            z = (ranked - ranked.mean()) / (ranked.std() + 1e-10)
            return z.reindex(group.index).fillna(0.0)
        panel[f + "_z"] = panel.groupby("date")[f].transform(calc_z).astype(float)

    return panel


def main():
    log.info("=" * 70)
    log.info("Phase 2: Factor Construction (Point-in-Time)")
    log.info("=" * 70)

    # --- Load data ---
    prices_path = DATA_PROC / "prices.csv"
    if not prices_path.exists():
        log.error("prices.csv not found. Run 01_data_pipeline.py first.")
        sys.exit(1)

    prices = pd.read_csv(prices_path, index_col=0, parse_dates=True)
    volumes_path = DATA_PROC / "volumes.csv"
    volumes = pd.read_csv(volumes_path, index_col=0, parse_dates=True) \
              if volumes_path.exists() else pd.DataFrame()

    fundamentals_path = DATA_PROC / "fundamentals.csv"
    fundamentals = pd.read_csv(fundamentals_path, parse_dates=["fiscal_quarter_end", "report_date"]) \
                   if fundamentals_path.exists() else pd.DataFrame()

    if fundamentals.empty:
        log.warning("No fundamental data found -- Value and Profitability factors will be NaN.")

    # --- Formation dates: last trading day of each month ---
    monthly_idx = prices.resample("ME").last().index
    # Drop months with too few history for momentum
    min_start = prices.index.min() + pd.DateOffset(months=MOM_LONG + MOM_SKIP + 2)
    formation_dates = monthly_idx[monthly_idx >= min_start]
    log.info(f"Formation dates: {formation_dates[0].date()} -> {formation_dates[-1].date()} "
             f"({len(formation_dates)} months)")

    # --- Build PIT dataset ---
    pit = PointInTimeDataset(prices, volumes, fundamentals)

    # --- Compute factor panel ---
    panel = build_factor_panel(formation_dates, pit)

    # --- Save ---
    out_path = DATA_PROC / "factors_monthly.csv"
    panel.to_csv(out_path, index=False)
    log.info(f"\n[OK] Factor panel saved: {out_path}")
    log.info(f"  Rows: {len(panel)}, Dates: {panel['date'].nunique()}, "
             f"Tickers: {panel['ticker'].nunique()}")

    # Coverage report
    for f in ["momentum", "value", "profitability", "size", "volatility", "liquidity"]:
        pct = 100 * panel[f].notna().mean()
        log.info(f"  {f:<15}: {pct:.1f}% coverage")


if __name__ == "__main__":
    main()
