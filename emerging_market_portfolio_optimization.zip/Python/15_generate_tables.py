"""
15_generate_tables.py
======================
Generates all 16 publication tables from computed results.
Exports: CSV + LaTeX (booktabs format).

Tables:
  01: Dataset description
  02: Descriptive statistics (returns)
  03: Factor statistics
  04: Regime characteristics
  05: ML model performance (RMSE, MAE, DirAcc)
  06: Covariance summary (LW shrinkage)
  07: Portfolio constraints specification
  08: QUBO formulation summary
  09: QAOA configuration and results
  10: Out-of-sample portfolio performance
  11: Risk metrics comparison
  12: Transaction costs and turnover
  13: Quantum vs classical optimisation comparison
  14: Statistical significance tests
  15: Robustness tests (sensitivity)
  16: Ablation study results

Outputs:
  - Tables/csv/table{N:02d}_*.csv
  - Tables/latex/table{N:02d}_*.tex
  - Logs/15_generate_tables.log
"""

import sys
import logging
from pathlib import Path

import numpy as np
import pandas as pd

ROOT      = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
RESULTS   = ROOT / "Results"
TBL_CSV   = ROOT / "Tables" / "csv"
TBL_TEX   = ROOT / "Tables" / "latex"
LOG_DIR   = ROOT / "Logs"
TBL_CSV.mkdir(parents=True, exist_ok=True)
TBL_TEX.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "15_generate_tables.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)


def to_latex(df: pd.DataFrame, caption: str, label: str,
              float_format: str = "%.4f") -> str:
    """Convert DataFrame to booktabs LaTeX table."""
    lines = [
        r"\begin{table}[ht]",
        r"\centering",
        rf"\caption{{{caption}}}",
        rf"\label{{{label}}}",
        r"\small",
    ]
    lines.append(df.to_latex(
        index=False, float_format=float_format,
        escape=True, column_format="l" + "r" * (len(df.columns) - 1),
    ).replace("\\toprule", "\\toprule\n").replace("\\bottomrule", "\\bottomrule"))
    lines.append(r"\end{table}")
    return "\n".join(lines)


def save_table(df: pd.DataFrame, num: int, name: str, caption: str,
                label: str, float_format: str = "%.4f"):
    fname = f"table{num:02d}_{name}"
    df.to_csv(TBL_CSV / f"{fname}.csv", index=False)
    tex = to_latex(df, caption, label, float_format)
    with open(TBL_TEX / f"{fname}.tex", "w", encoding="utf-8") as f:
        f.write(tex)
    log.info(f"  Table {num:02d}: {fname}.csv / .tex")


def main():
    log.info("=" * 70)
    log.info("Phase 15: Table Generation (16 tables)")
    log.info("=" * 70)

    # -----------------------------------------------------------------------
    # Table 01: Dataset description
    # -----------------------------------------------------------------------
    meta_path = DATA_PROC / "meta.json"
    dq_path   = DATA_PROC / "quality_report" / "dq_report.csv"
    if meta_path.exists():
        import json
        with open(meta_path) as f:
            meta = json.load(f)
        t01 = pd.DataFrame([{
            "Item":  "Source",            "Value": "yfinance (Yahoo Finance)"},
            {"Item": "Universe",          "Value": "BIST-30 liquid equities"},
            {"Item": "Start date",        "Value": meta.get("actual_first_date", "2010-01-01")},
            {"Item": "End date",          "Value": meta.get("actual_last_date", "2026-07-31")},
            {"Item": "N tickers",         "Value": str(meta.get("n_tickers", "N/A"))},
            {"Item": "N trading days",    "Value": str(meta.get("n_trading_days", "N/A"))},
            {"Item": "Reporting lag",     "Value": f"{meta.get('reporting_lag_days', 60)} days"},
            {"Item": "Frequency",         "Value": "Daily (rebalancing: monthly)"},
            {"Item": "Currency",          "Value": "Turkish Lira (TRY)"},
            {"Item": "Survivorship note", "Value": "Potential bias -- see text"},
        ])
    else:
        t01 = pd.DataFrame([{"Item": "Dataset", "Value": "See 01_data_pipeline.py"}])
    save_table(t01, 1, "dataset_description",
               "Dataset Description and Data Sources",
               "tab:dataset")

    # -----------------------------------------------------------------------
    # Table 02: Descriptive statistics
    # -----------------------------------------------------------------------
    ret_path = DATA_PROC / "returns.csv"
    if ret_path.exists():
        returns = pd.read_csv(ret_path, index_col=0, parse_dates=True)
        monthly = np.expm1(returns.resample("ME").sum())
        desc = monthly.describe().T[["mean", "std", "min", "25%", "50%", "75%", "max"]]
        desc.columns = ["Mean", "Std", "Min", "Q25", "Median", "Q75", "Max"]
        desc = desc * 100   # to percentage
        desc = desc.round(4).reset_index().rename(columns={"index": "Ticker"})
        desc["Ticker"] = desc["Ticker"].str.replace(".IS", "", regex=False)
    else:
        desc = pd.DataFrame([{"Ticker": "N/A -- run 01_data_pipeline.py"}])
    save_table(desc, 2, "descriptive_statistics",
               r"Descriptive Statistics of Monthly Portfolio Returns (\%)",
               "tab:desc_stats")

    # -----------------------------------------------------------------------
    # Table 03: Factor statistics
    # -----------------------------------------------------------------------
    fac_path = DATA_PROC / "factors_monthly.csv"
    if fac_path.exists():
        fac = pd.read_csv(fac_path, parse_dates=["date"])
        factor_cols = ["momentum", "size", "value", "profitability", "volatility", "liquidity"]
        fac_desc = fac[factor_cols].describe().T[["mean", "std", "min", "50%", "max"]]
        fac_desc.columns = ["Mean", "Std", "Min", "Median", "Max"]
        coverage = (fac[factor_cols].notna().mean() * 100).rename("Coverage%")
        fac_summary = pd.concat([fac_desc.round(4), coverage.round(1)], axis=1).reset_index()
        fac_summary = fac_summary.rename(columns={"index": "Factor"})
    else:
        fac_summary = pd.DataFrame([{"Factor": "N/A -- run 02_factor_model.py"}])
    save_table(fac_summary, 3, "factor_statistics",
               "Factor Statistics (Point-in-Time, Cross-Sectional)",
               "tab:factors")

    # -----------------------------------------------------------------------
    # Table 04: Regime characteristics
    # -----------------------------------------------------------------------
    reg_path = DATA_PROC / "regime_characteristics.csv"
    if reg_path.exists():
        reg = pd.read_csv(reg_path)
        reg = reg.round(4)
    else:
        reg = pd.DataFrame([{"regime": "N/A -- run 04_regime_detection.py"}])
    save_table(reg, 4, "regime_characteristics",
               "Market Regime Characteristics (Walk-Forward HMM)",
               "tab:regimes")

    # -----------------------------------------------------------------------
    # Table 05: ML model performance
    # -----------------------------------------------------------------------
    ml_path = DATA_PROC / "ml_performance.csv"
    if ml_path.exists():
        ml = pd.read_csv(ml_path)
        ml_sum = ml.groupby("model")[["val_rmse", "val_mae", "val_diracc"]].mean().round(6)
        ml_sum.columns = ["RMSE (val)", "MAE (val)", "DirAcc (val)"]
        ml_sum = ml_sum.reset_index()
    else:
        ml_sum = pd.DataFrame([{"model": "N/A -- run 03_ml_prediction.py"}])
    save_table(ml_sum, 5, "ml_performance",
               "Walk-Forward ML Return Forecast Performance (Validation Set)",
               "tab:ml_perf")

    # -----------------------------------------------------------------------
    # Table 06: Covariance summary
    # -----------------------------------------------------------------------
    cov_path = DATA_PROC / "cov_metadata.csv"
    if cov_path.exists():
        cov_meta = pd.read_csv(cov_path, parse_dates=["date"])
        cov_sum = pd.DataFrame([{
            "Estimator": "Sample",
            "Description": "Maximum likelihood",
            "Avg Assets": round(cov_meta["n_assets"].mean(), 1),
            "Avg Obs": round(cov_meta["n_obs"].mean(), 0),
            "Shrinkage": "N/A",
        }, {
            "Estimator": "Ledoit-Wolf",
            "Description": "Linear shrinkage (Oracle)",
            "Avg Assets": round(cov_meta["n_assets"].mean(), 1),
            "Avg Obs": round(cov_meta["n_obs"].mean(), 0),
            "Shrinkage": f"{cov_meta['lw_shrinkage'].mean():.4f}",
        }, {
            "Estimator": "EWMA",
            "Description": "RiskMetrics (lambda=0.94)",
            "Avg Assets": round(cov_meta["n_assets"].mean(), 1),
            "Avg Obs": round(cov_meta["n_obs"].mean(), 0),
            "Shrinkage": "N/A",
        }])
    else:
        cov_sum = pd.DataFrame([{"Estimator": "N/A -- run 05_covariance.py"}])
    save_table(cov_sum, 6, "covariance_summary",
               "Covariance Estimation Methods Summary",
               "tab:cov_summary")

    # -----------------------------------------------------------------------
    # Table 07: Portfolio constraints
    # -----------------------------------------------------------------------
    t07 = pd.DataFrame([
        {"Constraint":    "Budget",
         "Type":          "Hard",
         "Formulation":   r"$\sum_i w_i = 1$"},
        {"Constraint":    "Position limits",
         "Type":          "Hard",
         "Formulation":   r"$0 \le w_i \le 0.20$"},
        {"Constraint":    "Cardinality",
         "Type":          "Hard (Model E/F/G)",
         "Formulation":   r"$\sum_i z_i \le K = 12$"},
        {"Constraint":    "Non-negativity",
         "Type":          "Hard",
         "Formulation":   r"$w_i \ge 0$ (long-only)"},
        {"Constraint":    "Transaction cost",
         "Type":          "Soft (objective)",
         "Formulation":   r"$\lambda_3 \sum_i c_i |w_{i,t}-w_{i,t-1}|$"},
    ])
    save_table(t07, 7, "portfolio_constraints",
               "Portfolio Optimisation Constraints",
               "tab:constraints", float_format="%s")

    # -----------------------------------------------------------------------
    # Table 08: QUBO formulation summary
    # -----------------------------------------------------------------------
    t08 = pd.DataFrame([
        {"Component": "Binary variables",  "Specification": r"$M = N_q \times n_{\rm bits}$"},
        {"Component": "Bits per asset",    "Specification": "3 (8 weight levels)"},
        {"Component": "Max weight",        "Specification": r"$w_{\max} = 0.25$"},
        {"Component": "Variance term",     "Specification": r"$\lambda_1 \mathbf{A}^\top \Sigma \mathbf{A}$"},
        {"Component": "CVaR term (QUBO)",  "Specification": "Linear diagonal (Path B)"},
        {"Component": "TC term",           "Specification": "Quadratic (squared deviation)"},
        {"Component": "Budget penalty",    "Specification": r"$\lambda_{\rm pen}(1 - \mathbf{v}^\top x)^2$"},
        {"Component": "Cardinality penalty","Specification": r"$\lambda_{\rm pen}(K - \sum_i z_i)^2$"},
        {"Component": "Penalty coefficient","Specification": r"$\lambda_{\rm pen} = 5.0$"},
        {"Component": "Ising mapping",     "Specification": r"$x_i = (1-Z_i)/2$"},
    ])
    save_table(t08, 8, "qubo_formulation",
               "QUBO Formulation Summary",
               "tab:qubo", float_format="%s")

    # -----------------------------------------------------------------------
    # Table 09: QAOA configuration and results
    # -----------------------------------------------------------------------
    qaoa_path = RESULTS / "qaoa_performance.csv"
    if qaoa_path.exists():
        t09 = pd.read_csv(qaoa_path).round(6)
    else:
        t09 = pd.DataFrame([{
            "p": "N/A", "best_energy": "N/A",
            "n_evaluations": "N/A", "approx_ratio": "N/A",
            "bf_optimum": "N/A", "n_qubits": "N/A",
        }])
    save_table(t09, 9, "qaoa_results",
               "QAOA Configuration and Results",
               "tab:qaoa")

    # -----------------------------------------------------------------------
    # Table 10: Out-of-sample portfolio performance
    # -----------------------------------------------------------------------
    perf_path = RESULTS / "portfolio_performance.csv"
    if perf_path.exists():
        t10 = pd.read_csv(perf_path)
        cols_show = ["model", "ann_return", "ann_vol", "sharpe", "sortino",
                     "cvar_95", "max_drawdown", "avg_turnover", "avg_tc"]
        t10 = t10[[c for c in cols_show if c in t10.columns]].round(4)
    else:
        t10 = pd.DataFrame([{"model": "N/A -- run 12_backtest.py"}])
    save_table(t10, 10, "portfolio_performance",
               r"Out-of-Sample Portfolio Performance (Net of Transaction Costs)",
               "tab:performance")

    # -----------------------------------------------------------------------
    # Table 11: Risk metrics
    # -----------------------------------------------------------------------
    if perf_path.exists():
        perf = pd.read_csv(perf_path)
        t11 = perf[["model", "cvar_95", "max_drawdown", "calmar", "sortino",
                     "pct_positive"]].round(4) if perf_path.exists() else \
              pd.DataFrame([{"model": "N/A"}])
    else:
        t11 = pd.DataFrame([{"model": "N/A -- run 12_backtest.py"}])
    save_table(t11, 11, "risk_metrics",
               "Risk Metrics Comparison Across Portfolio Models",
               "tab:risk")

    # -----------------------------------------------------------------------
    # Table 12: Transaction costs and turnover
    # -----------------------------------------------------------------------
    bt_path = RESULTS / "portfolio_returns.csv"
    if bt_path.exists():
        bt = pd.read_csv(bt_path)
        t12 = bt.groupby("model").agg(
            avg_turnover=("turnover", "mean"),
            avg_tc=("tc", "mean"),
            total_tc=("tc", "sum"),
            n_rebalancing=("tc", "count"),
        ).round(6).reset_index()
    else:
        t12 = pd.DataFrame([{"model": "N/A -- run 12_backtest.py"}])
    save_table(t12, 12, "turnover_tc",
               "Portfolio Turnover and Transaction Costs",
               "tab:tc")

    # -----------------------------------------------------------------------
    # Table 13: Quantum vs classical comparison
    # -----------------------------------------------------------------------
    vqe_path   = RESULTS / "vqe_performance.csv"
    t13_rows = []
    if qaoa_path.exists():
        qaoa = pd.read_csv(qaoa_path)
        for _, row in qaoa.iterrows():
            t13_rows.append({
                "Method": f"QAOA (p={int(row['p'])})",
                "Universe": f"{int(row['n_qubits'])} qubits",
                "Objective": round(row["best_energy"], 4),
                "N_eval": int(row["n_evaluations"]),
                "Approx_ratio": round(row.get("approx_ratio", np.nan), 4) if not pd.isna(row.get("approx_ratio")) else "N/A",
            })
    if vqe_path.exists():
        vqe = pd.read_csv(vqe_path)
        for _, row in vqe.iterrows():
            t13_rows.append({
                "Method": f"VQE (reps={int(row['ansatz_reps'])})",
                "Universe": f"{int(row['n_qubits'])} qubits",
                "Objective": round(row["best_energy"], 4),
                "N_eval": int(row["n_evaluations"]),
                "Approx_ratio": round(row.get("approx_ratio", np.nan), 4) if not pd.isna(row.get("approx_ratio")) else "N/A",
            })
    if not t13_rows:
        t13_rows = [{"Method": "N/A -- run 09_qaoa.py and 10_vqe.py"}]
    t13 = pd.DataFrame(t13_rows)
    save_table(t13, 13, "quantum_classical",
               "Quantum vs Classical Optimisation Comparison",
               "tab:quantum", float_format="%s")

    # -----------------------------------------------------------------------
    # Table 14: Statistical significance
    # -----------------------------------------------------------------------
    stat_path = RESULTS / "statistical_tests.csv"
    if stat_path.exists():
        t14 = pd.read_csv(stat_path)[
            ["model", "sharpe", "ci_lower_95", "ci_upper_95",
             "jk_z", "jk_pvalue", "wilcoxon_pvalue"]
        ].round(4) if stat_path.exists() else pd.DataFrame()
    else:
        t14 = pd.DataFrame([{"model": "N/A -- run 13_statistics.py"}])
    save_table(t14, 14, "statistical_tests",
               "Statistical Significance Tests -- Sharpe Ratio Comparisons",
               "tab:stats")

    # -----------------------------------------------------------------------
    # Table 15: Robustness
    # -----------------------------------------------------------------------
    rob_path = RESULTS / "robustness_results.csv"
    if rob_path.exists():
        t15 = pd.read_csv(rob_path)[
            ["dimension", "param", "model", "sharpe"]
        ].round(4)
    else:
        t15 = pd.DataFrame([{"dimension": "N/A -- run 14_robustness.py"}])
    save_table(t15, 15, "robustness",
               "Robustness Analysis -- Sharpe Ratio Across Parameter Variations",
               "tab:robustness")

    # -----------------------------------------------------------------------
    # Table 16: Ablation study
    # -----------------------------------------------------------------------
    if perf_path.exists():
        perf = pd.read_csv(perf_path)
        ablation_models = [
            ("A_HistMean_MV",       "A", "Historical Mean", "Variance", "None"),
            ("B_Factor_MV",         "B", "ML Factor Forecast", "Variance", "None"),
            ("C_FactorRegime_MV",   "C", "ML + Regime", "Variance", "None"),
            ("D_FactorRegime_CVaR", "D", "ML + Regime", "CVaR (exact)", "None"),
            ("E_Full_MIQP",         "E", "ML + Regime", "CVaR + TC", "Cardinality"),
        ]
        rows = []
        for model, mid, exp_ret, risk, extra in ablation_models:
            sub = perf[perf["model"] == model]
            if not sub.empty:
                rows.append({
                    "Model": mid,
                    "Expected Return": exp_ret,
                    "Risk Model": risk,
                    "Extra Constraints": extra,
                    "Sharpe": round(float(sub["sharpe"].iloc[0]), 4)
                               if "sharpe" in sub.columns else np.nan,
                    "CVaR_95": round(float(sub["cvar_95"].iloc[0]), 4)
                               if "cvar_95" in sub.columns else np.nan,
                    "MDD": round(float(sub["max_drawdown"].iloc[0]), 4)
                           if "max_drawdown" in sub.columns else np.nan,
                })
        t16 = pd.DataFrame(rows) if rows else pd.DataFrame([{"Model": "N/A"}])
    else:
        t16 = pd.DataFrame([{"Model": "N/A -- run 12_backtest.py"}])
    save_table(t16, 16, "ablation_study",
               "Ablation Study -- Incremental Contribution of Model Components",
               "tab:ablation", float_format="%s")

    log.info(f"\n[OK] All tables generated.")
    log.info(f"  CSV : {TBL_CSV}")
    log.info(f"  LaTeX: {TBL_TEX}")


if __name__ == "__main__":
    main()
