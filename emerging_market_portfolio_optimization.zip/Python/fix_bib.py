import re

with open("LaTeX/references.bib", "r", encoding="utf-8") as f:
    text = f.read()

# Replace unescaped & with \&
fixed = re.sub(r'(?<!\\)&', r'\&', text)

with open("LaTeX/references.bib", "w", encoding="utf-8") as f:
    f.write(fixed)

print("Successfully cleaned references.bib ampersands.")
