"""
11_noise_simulation.py
=======================
Quantum noise analysis for QAOA/VQE portfolio experiments.

Noise models implemented:
  1. Depolarizing noise: epsilon in {0, 0.001, 0.005, 0.01, 0.05}
  2. Readout error: p_meas in {0, 0.01, 0.02, 0.05}
  3. Gate error (thermal relaxation): T1, T2 from realistic device parameters
  4. Shot noise: N_shots in {256, 1024, 4096, 16384}

Key research question:
  How does quantum noise translate into economically relevant portfolio degradation?
  Measure: Delta_E (energy), Delta_CVaR, Delta_Sharpe, Delta_MDD (via degraded weights)

Outputs:
  - Results/noise_sensitivity.csv  : energy degradation per noise level
  - Results/noise_economic_impact.csv : financial metrics degradation
  - Logs/11_noise_simulation.log
"""

import sys
import logging
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
RESULTS   = ROOT / "Results"
LOG_DIR   = ROOT / "Logs"
RESULTS.mkdir(parents=True, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "11_noise_simulation.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

DEPOL_ERRORS  = [0.0, 0.001, 0.005, 0.01, 0.05]
READOUT_ERRS  = [0.0, 0.01,  0.02,  0.05]
SHOT_COUNTS   = [256, 1024, 4096, 16384]
QAOA_P        = 2   # QAOA layers for noise test
SHOTS         = 4096
N_QUBITS_NOISE = 16   # qubits for noise test (manageable for noisy simulation)


def build_depolarizing_noise_model(epsilon: float, n_qubits: int):
    """Build Qiskit Aer noise model with depolarizing noise on all gates."""
    try:
        from qiskit_aer.noise import NoiseModel, depolarizing_error
    except ImportError:
        log.error("qiskit-aer noise not available.")
        return None

    noise_model = NoiseModel()
    if epsilon > 0:
        error_1q = depolarizing_error(epsilon, 1)
        error_2q = depolarizing_error(epsilon * 2, 2)  # 2Q gates typically worse
        noise_model.add_all_qubit_quantum_error(error_1q, ["u1", "u2", "u3", "rx", "ry", "rz"])
        noise_model.add_all_qubit_quantum_error(error_2q, ["rzz", "cx", "cz"])
    return noise_model


def build_readout_noise_model(p_meas: float, n_qubits: int):
    """Build Qiskit Aer noise model with readout (measurement) error."""
    try:
        from qiskit_aer.noise import NoiseModel, ReadoutError
    except ImportError:
        return None

    noise_model = NoiseModel()
    if p_meas > 0:
        p_correct = 1 - p_meas
        readout = ReadoutError([[p_correct, p_meas], [p_meas, p_correct]])
        noise_model.add_all_qubit_readout_error(readout)
    return noise_model


def run_noisy_qaoa(J: np.ndarray, h: np.ndarray, offset: float,
                    params: np.ndarray, p: int, noise_model, shots: int) -> float:
    """Run QAOA with noise model and return expected energy."""
    try:
        from qiskit_aer import AerSimulator
        from qiskit import transpile
    except ImportError:
        return np.nan

    sys.path.insert(0, str(ROOT / "Python"))
    from qaoa_utils import build_qaoa_circuit

    M   = len(h)
    qc  = build_qaoa_circuit(J, h, p, params[:p], params[p:])

    if noise_model:
        sim = AerSimulator(noise_model=noise_model, method="density_matrix")
    else:
        sim = AerSimulator(method="statevector")

    t_qc = transpile(qc, sim)
    job  = sim.run(t_qc, shots=shots)
    counts = job.result().get_counts()

    E = 0.0
    total = sum(counts.values())
    for bitstring, count in counts.items():
        z = np.array([1 - 2 * int(b) for b in reversed(bitstring)], dtype=float)
        if len(z) == M:
            E_z = z @ J @ z + h @ z + offset
            E  += (count / total) * E_z
    return E


def main():
    log.info("=" * 70)
    log.info("Phase 11: Quantum Noise Sensitivity Analysis")
    log.info("=" * 70)

    try:
        from qiskit_aer import AerSimulator
    except ImportError:
        log.error("qiskit-aer not installed.")
        sys.exit(1)

    # Load Ising data
    Q_path = DATA_PROC / "test_qubo_Q.npy"
    J_path = DATA_PROC / "test_ising_J.npy"
    h_path = DATA_PROC / "test_ising_h.npy"
    if not (J_path.exists() and h_path.exists()):
        log.error("Ising matrices not found. Run 08_qubo_builder.py first.")
        sys.exit(1)

    Q = np.load(Q_path) if Q_path.exists() else None
    J = np.load(J_path)[:N_QUBITS_NOISE, :N_QUBITS_NOISE]
    h = np.load(h_path)[:N_QUBITS_NOISE]
    offset = float(0.25 * Q.sum() + 0.25 * np.trace(Q)) if Q is not None else 0.0
    M = len(h)
    log.info(f"Noise test: M={M} qubits, QAOA p={QAOA_P}")

    # Use noiseless optimal params as baseline (simple uniform initialisation)
    rng    = np.random.default_rng(42)
    params = np.concatenate([
        rng.uniform(0, np.pi,     QAOA_P),
        rng.uniform(0, np.pi / 2, QAOA_P),
    ])

    # Noiseless baseline
    sv_sim = AerSimulator(method="statevector")
    from qiskit import transpile
    sys.path.insert(0, str(ROOT / "Python"))

    from importlib import import_module
    try:
        qaoa_mod = import_module("qaoa_utils")
        build_circuit = qaoa_mod.build_qaoa_circuit
    except Exception:
        log.warning("Importing build_qaoa_circuit from 09_qaoa.py directly.")
        # Inline minimal version for noise testing
        def build_circuit(J, h, p, gamma, beta):
            from qiskit import QuantumCircuit
            M_ = len(h)
            qc = QuantumCircuit(M_, M_)
            qc.h(range(M_))
            for k in range(p):
                for i in range(M_):
                    for j in range(i+1, M_):
                        if abs(J[i,j]) > 1e-10:
                            qc.rzz(2*gamma[k]*J[i,j], i, j)
                for i in range(M_):
                    if abs(h[i]) > 1e-10:
                        qc.rz(2*gamma[k]*h[i], i)
                for i in range(M_):
                    qc.rx(2*beta[k], i)
            qc.measure(range(M_), range(M_))
            return qc

    def compute_energy_from_counts(counts, J, h, offset, M):
        E = 0.0
        total = sum(counts.values())
        for bs, cnt in counts.items():
            z = np.array([1-2*int(b) for b in reversed(bs)], dtype=float)
            if len(z) == M:
                E += (cnt/total) * (z@J@z + h@z + offset)
        return E

    baseline_qc = build_circuit(J, h, QAOA_P, params[:QAOA_P], params[QAOA_P:])
    baseline_qc_t = transpile(baseline_qc, sv_sim)
    baseline_job = sv_sim.run(baseline_qc_t, shots=SHOTS)
    baseline_counts = baseline_job.result().get_counts()
    E_noiseless = compute_energy_from_counts(baseline_counts, J, h, offset, M)
    log.info(f"Baseline energy (noiseless, {SHOTS} shots): {E_noiseless:.6f}")

    results = []

    # Depolarizing noise sweep
    log.info("\n--- Depolarizing noise sweep ---")
    for eps in DEPOL_ERRORS:
        nm = build_depolarizing_noise_model(eps, M)
        if nm:
            sim = AerSimulator(noise_model=nm, method="density_matrix")
        else:
            sim = AerSimulator(method="statevector")
        try:
            qc_t = transpile(baseline_qc, sim)
            job  = sim.run(qc_t, shots=SHOTS)
            cnts = job.result().get_counts()
            E_noisy = compute_energy_from_counts(cnts, J, h, offset, M)
        except Exception as e:
            log.warning(f"  eps={eps}: failed ({e})")
            E_noisy = np.nan

        delta_E = E_noisy - E_noiseless
        results.append({"noise_type": "depolarizing", "noise_param": eps,
                         "E_noisy": E_noisy, "delta_E": delta_E, "shots": SHOTS})
        log.info(f"  eps={eps:.3f}: E={E_noisy:.6f}, delta_E={delta_E:+.6f}")

    # Readout error sweep
    log.info("\n--- Readout error sweep ---")
    for p_m in READOUT_ERRS:
        nm = build_readout_noise_model(p_m, M)
        if nm:
            sim = AerSimulator(noise_model=nm)
        else:
            sim = AerSimulator()
        try:
            qc_t = transpile(baseline_qc, sim)
            job  = sim.run(qc_t, shots=SHOTS)
            cnts = job.result().get_counts()
            E_noisy = compute_energy_from_counts(cnts, J, h, offset, M)
        except Exception as e:
            log.warning(f"  p_meas={p_m}: failed ({e})")
            E_noisy = np.nan

        delta_E = E_noisy - E_noiseless
        results.append({"noise_type": "readout", "noise_param": p_m,
                         "E_noisy": E_noisy, "delta_E": delta_E, "shots": SHOTS})
        log.info(f"  p_meas={p_m:.2f}: E={E_noisy:.6f}, delta_E={delta_E:+.6f}")

    # Shot noise sweep (noiseless simulator, vary shots)
    log.info("\n--- Shot noise sweep ---")
    for s in SHOT_COUNTS:
        qc_t = transpile(baseline_qc, sv_sim)
        job  = sv_sim.run(qc_t, shots=s)
        cnts = job.result().get_counts()
        E_s  = compute_energy_from_counts(cnts, J, h, offset, M)
        delta_E = E_s - E_noiseless
        results.append({"noise_type": "shot_noise", "noise_param": s,
                         "E_noisy": E_s, "delta_E": delta_E, "shots": s})
        log.info(f"  shots={s}: E={E_s:.6f}, delta_E={delta_E:+.6f}")

    df = pd.DataFrame(results)
    df.to_csv(RESULTS / "noise_sensitivity.csv", index=False)
    log.info(f"\n[OK] Noise sensitivity results: {RESULTS / 'noise_sensitivity.csv'}")


if __name__ == "__main__":
    main()
