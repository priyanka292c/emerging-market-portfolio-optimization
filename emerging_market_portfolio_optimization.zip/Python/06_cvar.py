"""
06_cvar.py
==========
CVaR (Conditional Value-at-Risk) computation and portfolio integration.

Implements TWO paths:
  Path A -- Exact CVaR (Rockafellar-Uryasev auxiliary-variable formulation)
            Used in classical MIQP via CVXPY.
  Path B -- QUBO-compatible discrete CVaR approximation
            Used in quantum experiments (enters QUBO as linear diagonal term).

Both paths use strictly historical in-sample return scenarios.

Outputs:
  - Data/processed/cvar_scenarios.csv  : scenario return matrix per rebalancing date
  - Logs/06_cvar.log
"""

import sys
import logging
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
LOG_DIR   = ROOT / "Logs"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "06_cvar.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

ALPHA       = 0.95    # CVaR confidence level (5% tail)
ALPHA_ALT   = 0.99    # Secondary confidence level
SCENARIO_WINDOW = 252 # trading days for historical scenarios


# ---------------------------------------------------------------------------
# Path A: Exact CVaR (for CVXPY integration)
# ---------------------------------------------------------------------------

def cvar_exact_cvxpy(w, returns_matrix, alpha=ALPHA):
    """
    Rockafellar-Uryasev CVaR as a CVXPY expression.
    This is called within the CVXPY problem definition in 07_classical_optimization.py.

    w             : CVXPY variable (N,)
    returns_matrix: np.ndarray (T, N) -- historical scenario returns
    alpha         : confidence level

    Returns CVXPY expression for CVaR_alpha(w).

    Mathematical formulation:
        CVaR_alpha(w) = min_{nu} [ nu + 1/((1-alpha)*T) * sum_t max(-r_t^T w - nu, 0) ]
    This is exact for finite historical scenarios.
    """
    import cvxpy as cp
    T, N = returns_matrix.shape
    nu   = cp.Variable()           # VaR threshold
    u    = cp.Variable(T)          # auxiliary variables

    portfolio_losses = -returns_matrix @ w   # (T,) losses = negative returns
    cvar_expr = nu + (1.0 / ((1 - alpha) * T)) * cp.sum(u)

    constraints = [
        u >= 0,
        u >= portfolio_losses - nu,
    ]
    return cvar_expr, constraints, nu


def compute_realized_cvar(returns_vec: np.ndarray, alpha: float = ALPHA) -> float:
    """
    Compute historical CVaR from a vector of portfolio returns.
    CVaR_alpha = E[loss | loss >= VaR_alpha]
    where loss = -return.
    """
    losses = -np.asarray(returns_vec)
    losses_sorted = np.sort(losses)
    var_idx = int(np.ceil(alpha * len(losses))) - 1
    var_idx = max(0, min(var_idx, len(losses) - 1))
    tail    = losses[losses >= losses_sorted[var_idx]]
    return float(np.mean(tail)) if len(tail) > 0 else float(losses_sorted[var_idx])


def compute_var(returns_vec: np.ndarray, alpha: float = ALPHA) -> float:
    """Historical VaR."""
    losses = -np.asarray(returns_vec)
    return float(np.percentile(losses, alpha * 100))


# ---------------------------------------------------------------------------
# Path B: QUBO-compatible CVaR approximation
# ---------------------------------------------------------------------------

def cvar_qubo_linear_penalty(returns_matrix: np.ndarray, alpha: float = ALPHA) -> np.ndarray:
    """
    Compute the linear QUBO penalty vector for CVaR.

    The CVaR approximation for the QUBO:
        ~CVaR_alpha(w) ~ -(1/|S_alpha|) * sum_{s in S_alpha} r_s^T w
    where S_alpha = set of worst (1-alpha) fraction of scenarios,
    sorted by EQUAL-WEIGHT portfolio return (as pre-screening).

    Since w(x) is linear in binary variables x (through weight discretisation),
    r_s^T w is linear in x, so this term enters the QUBO as a linear
    (diagonal) penalty -- not a quadratic term.

    Returns: penalty_vector of shape (N,) -- the linear coefficient for
    each asset's weight. This is added to the QUBO diagonal.
    """
    T, N = returns_matrix.shape
    n_tail = max(1, int(np.floor((1 - alpha) * T)))

    # Pre-screen using equal-weight portfolio to identify worst scenarios
    eq_weight_ret = returns_matrix.mean(axis=1)   # (T,)
    tail_idx = np.argsort(eq_weight_ret)[:n_tail]  # indices of worst scenarios

    tail_returns = returns_matrix[tail_idx, :]     # (n_tail, N)
    # CVaR penalty = -(mean of tail returns) per asset
    cvar_penalty = -tail_returns.mean(axis=0)      # (N,) -- positive means bad for asset i

    log.debug(f"QUBO CVaR: tail={n_tail}/{T} scenarios, "
              f"penalty range=[{cvar_penalty.min():.4f}, {cvar_penalty.max():.4f}]")
    return cvar_penalty


def build_scenario_matrix(returns_daily: pd.DataFrame,
                           date: pd.Timestamp,
                           tickers: list[str],
                           window: int = SCENARIO_WINDOW) -> np.ndarray:
    """
    Build historical return scenario matrix for CVaR computation.
    Uses daily returns strictly before date, last `window` trading days.
    """
    mask   = returns_daily.index < date
    hist   = returns_daily.loc[mask, tickers].iloc[-window:]
    hist   = hist.dropna(how="any")   # only complete rows
    return hist.values   # (T, N)


# ---------------------------------------------------------------------------
# Reporting utilities
# ---------------------------------------------------------------------------

def portfolio_risk_report(returns_vec: np.ndarray,
                          label: str = "Portfolio",
                          rf_annual: float = 0.0) -> dict:
    """
    Compute full set of risk metrics for a return series.
    returns_vec: array of MONTHLY returns.
    """
    r = np.asarray(returns_vec)
    if len(r) < 2:
        return {}

    ann_ret  = (1 + r.mean()) ** 12 - 1
    ann_vol  = r.std() * np.sqrt(12)
    rf_m     = (1 + rf_annual) ** (1 / 12) - 1
    excess_r = r - rf_m
    sharpe   = excess_r.mean() / excess_r.std() * np.sqrt(12) if excess_r.std() > 0 else np.nan
    neg_r    = r[r < rf_m]
    sortino  = (excess_r.mean() * 12) / (neg_r.std() * np.sqrt(12)) if len(neg_r) > 0 and neg_r.std() > 0 else np.nan

    # CVaR on monthly returns
    cvar_95 = compute_realized_cvar(r, alpha=0.95)
    cvar_99 = compute_realized_cvar(r, alpha=0.99)
    var_95  = compute_var(r, alpha=0.95)

    # Maximum drawdown
    wealth  = np.cumprod(1 + r)
    peak    = np.maximum.accumulate(wealth)
    dd      = (peak - wealth) / peak
    mdd     = float(dd.max())
    calmar  = ann_ret / mdd if mdd > 0 else np.nan

    return {
        "label":        label,
        "n_months":     len(r),
        "ann_return":   round(ann_ret, 6),
        "ann_vol":      round(ann_vol, 6),
        "sharpe":       round(sharpe, 4) if not np.isnan(sharpe) else np.nan,
        "sortino":      round(sortino, 4) if not np.isnan(sortino) else np.nan,
        "calmar":       round(calmar, 4) if not np.isnan(calmar) else np.nan,
        "var_95":       round(var_95,  6),
        "cvar_95":      round(cvar_95, 6),
        "cvar_99":      round(cvar_99, 6),
        "max_drawdown": round(mdd,     6),
        "pct_positive": round((r > 0).mean(), 4),
    }


def main():
    log.info("=" * 70)
    log.info("Phase 6: CVaR Module (Path A: Exact | Path B: QUBO Approximation)")
    log.info("=" * 70)
    log.info("This module provides functions imported by 07_classical_optimization.py")
    log.info("and 08_qubo_builder.py. Running self-test...")

    # Self-test with synthetic data
    np.random.seed(42)
    T, N = 252, 10
    R = np.random.randn(T, N) * 0.01   # synthetic daily returns

    # Path B test
    penalty = cvar_qubo_linear_penalty(R, alpha=0.95)
    log.info(f"Path B penalty vector (N={N}): {np.round(penalty, 5)}")
    assert penalty.shape == (N,), "Shape mismatch"

    # Path A test (requires cvxpy)
    try:
        import cvxpy as cp
        w_test = np.ones(N) / N
        w_var  = cp.Variable(N)
        expr, cons, nu = cvar_exact_cvxpy(w_var, R, alpha=0.95)
        # Quick feasibility check
        prob = cp.Problem(cp.Minimize(expr), cons + [w_var == w_test])
        prob.solve(solver=cp.CLARABEL, verbose=False)
        log.info(f"Path A CVaR (equal-weight, synthetic): {nu.value:.6f}")
    except Exception as e:
        log.warning(f"Path A self-test skipped: {e}")

    log.info("[OK] CVaR module self-test complete.")


if __name__ == "__main__":
    main()
