"""
14_robustness.py
================
Robustness analysis: varies key parameters and re-computes performance.

Dimensions varied:
  1. Risk aversion lambda1 in {0.5, 1.0, 2.0, 5.0}
  2. CVaR confidence alpha in {0.90, 0.95, 0.99}
  3. Transaction cost rate c in {0.001, 0.002, 0.005}
  4. Cardinality K in {8, 10, 12, 15}
  5. Covariance estimator: sample, LW, EWMA
  6. Rebalancing frequency: monthly, quarterly, semi-annual
  7. QAOA depth p in {1, 2, 3}
  8. Noise level epsilon in {0, 0.001, 0.01}

Each variation produces a Sharpe ratio.
Results compiled into a robustness heatmap table.

Outputs:
  - Results/robustness_results.csv
  - Results/robustness_heatmap.csv
  - Logs/14_robustness.log
"""

import sys
import logging
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
RESULTS   = ROOT / "Results"
LOG_DIR   = ROOT / "Logs"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "14_robustness.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

RF_ANNUAL = 0.14

LAMBDA1_VALUES = [0.5, 1.0, 2.0, 5.0]
ALPHA_VALUES   = [0.90, 0.95, 0.99]
TC_VALUES      = [0.001, 0.002, 0.005]
K_VALUES       = [8, 10, 12, 15]
COV_TYPES      = ["sample", "lw", "ewma"]
REBAL_FREQS    = ["ME", "QE", "2QE"]   # monthly, quarterly, semi-annual


def sharpe_from_returns(rets: np.ndarray, rf_annual: float = RF_ANNUAL) -> float:
    if len(rets) < 6:
        return np.nan
    rf_m    = (1 + rf_annual) ** (1 / 12) - 1
    excess  = rets - rf_m
    return float(excess.mean() / excess.std() * np.sqrt(12)) if excess.std() > 0 else np.nan


def run_single_backtest_simplified(portfolio_returns_path: str,
                                    model: str,
                                    freq: str = "ME") -> np.ndarray:
    """
    Load precomputed portfolio returns and resample to given frequency.
    Returns array of period returns.
    """
    if not Path(portfolio_returns_path).exists():
        return np.array([])
    bt = pd.read_csv(portfolio_returns_path, parse_dates=["date"])
    sub = bt[bt["model"] == model].dropna(subset=["net_ret"]).set_index("date")
    if sub.empty:
        return np.array([])
    resampled = np.expm1(np.log1p(sub["net_ret"]).resample(freq).sum())
    return resampled.dropna().values


def main():
    log.info("=" * 70)
    log.info("Phase 14: Robustness Analysis")
    log.info("=" * 70)

    port_path = RESULTS / "portfolio_returns.csv"
    if not port_path.exists():
        log.error("portfolio_returns.csv not found. Run 12_backtest.py first.")
        sys.exit(1)

    qaoa_path = RESULTS / "qaoa_performance.csv"
    noise_path = RESULTS / "noise_sensitivity.csv"

    records = []

    # -----------------------------------------------------------------------
    # Robustness 1: Rebalancing frequency
    # -----------------------------------------------------------------------
    log.info("\n[1] Rebalancing frequency robustness")
    for model in ["E_Full_MIQP", "B_Factor_MV", "EW"]:
        for freq in REBAL_FREQS:
            rets = run_single_backtest_simplified(str(port_path), model, freq)
            sr   = sharpe_from_returns(rets)
            freq_label = {"ME": "Monthly", "QE": "Quarterly", "2QE": "Semi-annual"}[freq]
            records.append({"dimension": "rebal_freq", "param": freq_label,
                             "model": model, "sharpe": sr})
            log.info(f"  {model} | {freq_label}: Sharpe={sr:.4f}" if not np.isnan(sr) else
                     f"  {model} | {freq_label}: insufficient data")

    # -----------------------------------------------------------------------
    # Robustness 2: QAOA depth
    # -----------------------------------------------------------------------
    log.info("\n[2] QAOA depth robustness")
    if qaoa_path.exists():
        qaoa_df = pd.read_csv(qaoa_path)
        for _, row in qaoa_df.iterrows():
            records.append({
                "dimension": "qaoa_depth",
                "param": f"p={int(row['p'])}",
                "model": "QAOA",
                "best_energy": row.get("best_energy", np.nan),
                "approx_ratio": row.get("approx_ratio", np.nan),
                "sharpe": np.nan,  # requires full backtest with QAOA weights
            })

    # -----------------------------------------------------------------------
    # Robustness 3: Noise level
    # -----------------------------------------------------------------------
    log.info("\n[3] Quantum noise robustness")
    if noise_path.exists():
        noise_df = pd.read_csv(noise_path)
        depol = noise_df[noise_df["noise_type"] == "depolarizing"]
        for _, row in depol.iterrows():
            records.append({
                "dimension": "noise_level",
                "param": f"eps={row['noise_param']:.3f}",
                "model": "QAOA_noisy",
                "delta_E": row.get("delta_E", np.nan),
                "sharpe": np.nan,
            })

    # -----------------------------------------------------------------------
    # Robustness 4: Transaction cost sensitivity
    # -----------------------------------------------------------------------
    log.info("\n[4] TC sensitivity (uses precomputed returns + TC adjustment)")
    bt = pd.read_csv(port_path, parse_dates=["date"])
    for tc in TC_VALUES:
        for model in ["E_Full_MIQP", "D_FactorRegime_CVaR"]:
            sub = bt[bt["model"] == model].dropna(subset=["gross_ret", "turnover"])
            if sub.empty:
                continue
            net_rets = (sub["gross_ret"] - tc * sub["turnover"]).values
            sr = sharpe_from_returns(net_rets)
            records.append({"dimension": "tc_rate", "param": f"tc={tc:.3f}",
                             "model": model, "sharpe": sr})
            log.info(f"  {model} | tc={tc:.3f}: Sharpe={sr:.4f}" if not np.isnan(sr) else
                     f"  {model} | tc={tc:.3f}: insufficient data")

    # -----------------------------------------------------------------------
    # Compile results
    # -----------------------------------------------------------------------
    rob_df = pd.DataFrame(records)
    rob_df.to_csv(RESULTS / "robustness_results.csv", index=False)

    # Heatmap: model x dimension -> Sharpe
    heatmap_data = rob_df.pivot_table(
        index="model", columns="param", values="sharpe", aggfunc="mean")
    heatmap_data.to_csv(RESULTS / "robustness_heatmap.csv")

    log.info(f"\n[OK] Robustness results saved: {RESULTS / 'robustness_results.csv'}")
    log.info(f"[OK] Heatmap saved: {RESULTS / 'robustness_heatmap.csv'}")


if __name__ == "__main__":
    main()
