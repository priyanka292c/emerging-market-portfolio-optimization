﻿with open(r"D:\Quantum finance\22_09_2026\Python\generate_all_docx.py", "r", encoding="utf-8") as f:
    txt = f.read()

txt = txt.replace('pd.read_csv("Tables/csv/', 'pd.read_csv(r"D:/Quantum finance/22_09_2026/Tables/csv/')
txt = txt.replace("pd.read_csv('Tables/csv/", "pd.read_csv(r'D:/Quantum finance/22_09_2026/Tables/csv/")
txt = txt.replace('"Submission_Package', 'r"D:/Quantum finance/22_09_2026/Submission_Package')
txt = txt.replace("'Submission_Package", "r'D:/Quantum finance/22_09_2026/Submission_Package")
txt = txt.replace('"Figures/', 'r"D:/Quantum finance/22_09_2026/Figures/')
txt = txt.replace("'Figures/", "r'D:/Quantum finance/22_09_2026/Figures/")
txt = txt.replace('"Tables/', 'r"D:/Quantum finance/22_09_2026/Tables/')
txt = txt.replace("'Tables/", "r'D:/Quantum finance/22_09_2026/Tables/")
txt = txt.replace('"Data/', 'r"D:/Quantum finance/22_09_2026/Data/')
txt = txt.replace("'Data/", "r'D:/Quantum finance/22_09_2026/Data/")

with open(r"D:\Quantum finance\22_09_2026\Python\generate_all_docx.py", "w", encoding="utf-8") as f:
    f.write(txt)
print("Updated generate_all_docx.py with absolute paths.")
