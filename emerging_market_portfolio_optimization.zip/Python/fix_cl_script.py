﻿import os

path = r"D:\Quantum finance\22_09_2026\Python\update_cover_letter.py"
with open(path, "r", encoding="utf-8") as f:
    text = f.read()

# Update header sender in update_cover_letter.py
text = text.replace(
    r"""\textbf{Shahrukh Saleem}, Ph.D. (Corresponding Author)\\
Assistant Professor, VIT Business School\\
Vellore Institute of Technology (Deemed to be University)\\
Vellore 632014, Tamil Nadu, India\\
Email: \texttt{shahrukh.saleem@vit.ac.in} \quad $\cdot$ \quad ORCID: \url{https://orcid.org/0000-0003-2949-6188}\\[0.4em]
\textit{On behalf of co-authors: Araby Madbouly, Uvesh Husain, Ram Soorat, Priyanka, and Afzalur Rahman}""",
    r"""\textbf{Ram Soorat} (Corresponding Author)\\
Assistant Professor, School of Technology\\
Woxsen University\\
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\\
Email: \texttt{ram.soorat@woxsen.edu.in} \quad $\cdot$ \quad Telephone: +91 8455 305555 \quad $\cdot$ \quad ORCID: \url{https://orcid.org/0000-0001-7875-9197}\\[0.4em]
\textit{On behalf of co-authors: Shahrukh Saleem, Araby Madbouly, Uvesh Husain, Priyanka, and Afzalur Rahman}"""
)

# Update signoff
text = text.replace(
    r"""\textbf{Shahrukh Saleem}, Ph.D. (Corresponding Author)\\
Assistant Professor, VIT Business School, Vellore Institute of Technology, India\\
Email: \texttt{shahrukh.saleem@vit.ac.in}""",
    r"""\textbf{Ram Soorat} (Corresponding Author)\\
Assistant Professor, School of Technology\\
Woxsen University, Hyderabad, India\\
Email: \texttt{ram.soorat@woxsen.edu.in}"""
)

# Update coauthor table
text = text.replace(
    r"""\textbf{Shahrukh Saleem} & Assistant Professor & VIT Business School, Vellore Institute of Technology, India & \href{mailto:shahrukh.saleem@vit.ac.in}{\nolinkurl{shahrukh.saleem@vit.ac.in}}\\
\textit{(Corresponding)} & & & ORCID: \href{https://orcid.org/0000-0003-2949-6188}{0000-0003-2949-6188} \\
\addlinespace
\textbf{Araby Madbouly} & Associate Professor & Business \& Accounting Dept., Muscat College, Oman & \href{mailto:araby@muscatcollege.edu.om}{\nolinkurl{araby@muscatcollege.edu.om}}\\
& & & ORCID: \href{https://orcid.org/0000-0002-7981-4191}{0000-0002-7981-4191} \\
\addlinespace
\textbf{Uvesh Husain} & Associate Professor & Economics \& Business Studies Dept., Mazoon College, Oman & \href{mailto:owais.husain@mazcol.edu.om}{\nolinkurl{owais.husain@mazcol.edu.om}}\\
& & & ORCID: \href{https://orcid.org/0000-0002-8502-8488}{0000-0002-8502-8488} \\
\addlinespace
\textbf{Ram Soorat} & Assistant Professor & School of Technology, Woxsen University, Hyderabad, India & \href{mailto:ram.soorat@woxsen.edu.in}{\nolinkurl{ram.soorat@woxsen.edu.in}}\\
& & & ORCID: \href{https://orcid.org/0000-0001-7875-9197}{0000-0001-7875-9197} \\""",
    r"""\textbf{Shahrukh Saleem} & Assistant Professor & VIT Business School, Vellore Institute of Technology, India & \href{mailto:shahrukh.saleem@vit.ac.in}{\nolinkurl{shahrukh.saleem@vit.ac.in}}\\
& & & ORCID: \href{https://orcid.org/0000-0003-2949-6188}{0000-0003-2949-6188} \\
\addlinespace
\textbf{Araby Madbouly} & Associate Professor & Business \& Accounting Dept., Muscat College, Oman & \href{mailto:araby@muscatcollege.edu.om}{\nolinkurl{araby@muscatcollege.edu.om}}\\
& & & ORCID: \href{https://orcid.org/0000-0002-7981-4191}{0000-0002-7981-4191} \\
\addlinespace
\textbf{Uvesh Husain} & Associate Professor & Economics \& Business Studies Dept., Mazoon College, Oman & \href{mailto:owais.husain@mazcol.edu.om}{\nolinkurl{owais.husain@mazcol.edu.om}}\\
& & & ORCID: \href{https://orcid.org/0000-0002-8502-8488}{0000-0002-8502-8488} \\
\addlinespace
\textbf{Ram Soorat} & Assistant Professor & School of Technology, Woxsen University, Hyderabad, India & \href{mailto:ram.soorat@woxsen.edu.in}{\nolinkurl{ram.soorat@woxsen.edu.in}}\\
\textit{(Corresponding)} & & & ORCID: \href{https://orcid.org/0000-0001-7875-9197}{0000-0001-7875-9197} \\"""
)

with open(path, "w", encoding="utf-8") as f:
    f.write(text)

print("update_cover_letter.py updated successfully.")
