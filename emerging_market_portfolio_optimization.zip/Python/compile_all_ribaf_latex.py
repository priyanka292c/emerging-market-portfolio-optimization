import os
import subprocess
import shutil

LATEX_DIR = r"D:\Quantum finance\22_09_2026\RIBAF_Submission\LaTeX"
PDFLATEX = r"C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\pdflatex.exe"
BIBTEX = r"C:\Users\I7\AppData\Local\Programs\MiKTeX\miktex\bin\x64\bibtex.exe"

def compile_doc(doc_name, run_bib=False):
    print(f"\n================ Compiling {doc_name} ================")
    cmd1 = [PDFLATEX, "-interaction=nonstopmode", f"{doc_name}.tex"]
    subprocess.run(cmd1, cwd=LATEX_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if run_bib:
        cmd_bib = [BIBTEX, doc_name]
        subprocess.run(cmd_bib, cwd=LATEX_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(cmd1, cwd=LATEX_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # final pass
    subprocess.run(cmd1, cwd=LATEX_DIR, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    
    pdf_p = os.path.join(LATEX_DIR, f"{doc_name}.pdf")
    if os.path.exists(pdf_p):
        size = os.path.getsize(pdf_p)
        print(f"[SUCCESS] {doc_name}.pdf generated ({size:,} bytes)")
        return True
    else:
        print(f"[ERROR] Failed to generate {doc_name}.pdf")
        return False

# 1. Compile main.tex
compile_doc("main", run_bib=True)

# 2. Compile supplementary.tex
compile_doc("supplementary", run_bib=False)

# 3. Compile title_page.tex
compile_doc("title_page", run_bib=False)

# 4. Compile cover_letter.tex
compile_doc("cover_letter", run_bib=False)

# 5. Compile graphical_abstract.tex
compile_doc("graphical_abstract", run_bib=False)

# Copy PDFs to submission package folders
SUB_PKG = r"D:\Quantum finance\22_09_2026\Submission_Package"
SUB_PDFS = r"D:\Quantum finance\22_09_2026\RIBAF_Submission\Submission_PDFs"

# Manuscript
shutil.copy2(os.path.join(LATEX_DIR, "main.pdf"), os.path.join(SUB_PKG, "Manuscript", "manuscript.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "main.pdf"), os.path.join(SUB_PKG, "Manuscript", "Manuscript_Without_Author_Details.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "main.pdf"), os.path.join(SUB_PDFS, "main.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "main.pdf"), os.path.join(SUB_PDFS, "Manuscript", "manuscript.pdf"))

# Supplementary
shutil.copy2(os.path.join(LATEX_DIR, "supplementary.pdf"), os.path.join(SUB_PKG, "Supplementary", "supplementary_material.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "supplementary.pdf"), os.path.join(SUB_PKG, "Supplementary", "supplementary.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "supplementary.pdf"), os.path.join(SUB_PDFS, "supplementary.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "supplementary.pdf"), os.path.join(SUB_PDFS, "Supplementary", "supplementary_material.pdf"))

# Title page
shutil.copy2(os.path.join(LATEX_DIR, "title_page.pdf"), os.path.join(SUB_PKG, "Title_Page", "title_page.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "title_page.pdf"), os.path.join(SUB_PKG, "Title_Page", "Title_Page_with_Author_Details.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "title_page.pdf"), os.path.join(SUB_PDFS, "title_page.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "title_page.pdf"), os.path.join(SUB_PDFS, "Title_Page", "title_page.pdf"))

# Cover letter
shutil.copy2(os.path.join(LATEX_DIR, "cover_letter.pdf"), os.path.join(SUB_PKG, "Cover_Letter", "cover_letter.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "cover_letter.pdf"), os.path.join(SUB_PKG, "Cover_Letter.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "cover_letter.pdf"), os.path.join(SUB_PDFS, "cover_letter.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "cover_letter.pdf"), os.path.join(SUB_PDFS, "Cover_Letter", "cover_letter.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "cover_letter.pdf"), r"D:\Quantum finance\22_09_2026\LaTeX\cover_letter.pdf")

# Graphical abstract
shutil.copy2(os.path.join(LATEX_DIR, "graphical_abstract.pdf"), os.path.join(SUB_PKG, "Graphical_Abstract", "graphical_abstract.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "graphical_abstract.pdf"), os.path.join(SUB_PDFS, "graphical_abstract.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "graphical_abstract.pdf"), os.path.join(SUB_PDFS, "Graphical_Abstract", "graphical_abstract.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "graphical_abstract.pdf"), r"D:\Quantum finance\22_09_2026\LaTeX\graphical_abstract.pdf")

# Also sync other PDFs to root Submission_Package and LaTeX/
shutil.copy2(os.path.join(LATEX_DIR, "title_page.pdf"), os.path.join(SUB_PKG, "Title_Page.pdf"))
shutil.copy2(os.path.join(LATEX_DIR, "title_page.pdf"), r"D:\Quantum finance\22_09_2026\LaTeX\title_page.pdf")
shutil.copy2(os.path.join(LATEX_DIR, "main.pdf"), r"D:\Quantum finance\22_09_2026\LaTeX\main.pdf")
shutil.copy2(os.path.join(LATEX_DIR, "supplementary.pdf"), r"D:\Quantum finance\22_09_2026\LaTeX\supplementary.pdf")

print("\nAll PDFs successfully compiled and synchronized to Submission Package directories!")
