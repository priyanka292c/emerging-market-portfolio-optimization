﻿print("Testing powershell script writing")
