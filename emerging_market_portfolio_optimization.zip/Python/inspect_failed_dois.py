from pathlib import Path
import json

data = json.loads(Path('Python/reference_verification_results.json').read_text(encoding='utf-8'))
for item in data:
    if not item['verified'] or 'FAILED' in item['doi_status']:
        print(f"Key: {item['key']}")
        print(f"  Title: {item['bib_title']}")
        print(f"  DOI: {item['bib_doi']}")
        print(f"  Status: {item['doi_status']}")
        print(f"  Notes: {item['notes']}")
