"""
03_ml_prediction.py
====================
Walk-forward ML return forecasting using factor signals.

Models:
  - ElasticNet (sklearn)
  - RandomForest (sklearn)
  - XGBoost

Strict walk-forward: at each rebalancing date t,
  Training set  : all (factor, return) pairs for dates < t - val_window
  Validation set: val_window months before t (for hyperparameter tuning)
  Test step     : predict return for month t

No test-period information enters training or hyperparameter selection.

Inputs:
  - Data/processed/factors_monthly.csv
  - Data/processed/returns.csv

Outputs:
  - Data/processed/ml_forecasts.csv   : mû_{i,t} for all tickers and dates
  - Data/processed/ml_performance.csv : RMSE, MAE, DirAcc per model
  - Logs/03_ml_prediction.log
"""

import sys
import logging
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.linear_model import ElasticNetCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error

warnings.filterwarnings("ignore")

# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
LOG_DIR   = ROOT / "Logs"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "03_ml_prediction.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
FACTOR_COLS = ["momentum_z", "size_z", "value_z", "profitability_z",
               "volatility_z", "liquidity_z"]
VAL_MONTHS   = 12    # months held out for validation within training
MIN_TRAIN_OBS = 200  # minimum (ticker, month) observations for model fit
N_JOBS       = -1    # parallelism
RANDOM_STATE = 42

# ---------------------------------------------------------------------------

def load_data():
    factors = pd.read_csv(DATA_PROC / "factors_monthly.csv", parse_dates=["date"])
    returns_daily = pd.read_csv(DATA_PROC / "returns.csv", index_col=0, parse_dates=True)

    # Compute monthly returns aligned to month-end dates
    monthly_ret = np.expm1(
        returns_daily.resample("ME").sum()          # sum of log-returns = log cumulative
    )
    monthly_ret.index = pd.to_datetime(monthly_ret.index)
    monthly_ret_long = monthly_ret.stack().reset_index()
    monthly_ret_long.columns = ["date", "ticker", "fwd_return"]
    # Forward-shift: the return *realised* in month t is the target for the
    # signal computed at end of month t-1.
    monthly_ret_long = monthly_ret_long.sort_values(["ticker", "date"])
    monthly_ret_long["target"] = monthly_ret_long.groupby("ticker")["fwd_return"].shift(-1)

    # Merge factors and targets
    data = factors.merge(monthly_ret_long[["date", "ticker", "target"]],
                         on=["date", "ticker"], how="left")
    data = data.dropna(subset=FACTOR_COLS + ["target"]).reset_index(drop=True)
    log.info(f"Merged dataset: {len(data)} obs, {data['date'].nunique()} months, "
             f"{data['ticker'].nunique()} tickers")
    return data


def direction_accuracy(y_true, y_pred):
    """Fraction of predictions where sign matches actual."""
    return np.mean(np.sign(y_true) == np.sign(y_pred))


def walk_forward_predict(data: pd.DataFrame, model_name: str) -> tuple[pd.DataFrame, dict]:
    """
    Walk-forward prediction loop.
    Returns:
        predictions: DataFrame with [date, ticker, predicted_return, model]
        metrics: dict of {date -> {rmse, mae, diracc}}
    """
    dates = sorted(data["date"].unique())
    # Require at least MIN_TRAIN_OBS / (approx 30 tickers) months for training
    min_train_months = max(24, MIN_TRAIN_OBS // 30)
    test_dates = dates[min_train_months + VAL_MONTHS:]

    all_preds = []
    perf_records = []
    scaler = StandardScaler()

    for i, test_date in enumerate(test_dates):
        train_val_dates = [d for d in dates if d < test_date]
        train_dates = train_val_dates[:-VAL_MONTHS] if len(train_val_dates) > VAL_MONTHS else train_val_dates
        val_dates   = train_val_dates[-VAL_MONTHS:]

        train_data = data[data["date"].isin(train_dates)]
        val_data   = data[data["date"].isin(val_dates)]
        test_data  = data[data["date"] == test_date]

        if len(train_data) < MIN_TRAIN_OBS or test_data.empty:
            continue

        X_train = train_data[FACTOR_COLS].values
        y_train = train_data["target"].values
        X_val   = val_data[FACTOR_COLS].values   if not val_data.empty else None
        y_val   = val_data["target"].values      if not val_data.empty else None
        X_test  = test_data[FACTOR_COLS].values

        # Scale
        scaler.fit(X_train)
        X_train_s = scaler.transform(X_train)
        X_test_s  = scaler.transform(X_test)

        # Fit model
        if model_name == "ElasticNet":
            model = ElasticNetCV(l1_ratio=[0.1, 0.5, 0.9], cv=3,
                                  max_iter=2000, random_state=RANDOM_STATE)
            model.fit(X_train_s, y_train)
            y_pred = model.predict(X_test_s)

        elif model_name == "RandomForest":
            model = RandomForestRegressor(
                n_estimators=100, max_depth=6, max_features="sqrt", min_samples_leaf=5,
                n_jobs=N_JOBS, random_state=RANDOM_STATE
            )
            model.fit(X_train_s, y_train)
            y_pred = model.predict(X_test_s)

        elif model_name == "XGBoost":
            try:
                import xgboost as xgb
            except ImportError:
                log.error("xgboost not installed.")
                continue
            model = xgb.XGBRegressor(
                n_estimators=100, learning_rate=0.05, max_depth=4,
                subsample=0.8, colsample_bytree=0.8,
                random_state=RANDOM_STATE, n_jobs=N_JOBS,
                verbosity=0
            )
            model.fit(X_train_s, y_train,
                      eval_set=[(scaler.transform(X_val), y_val)] if X_val is not None else None,
                      verbose=False)
            y_pred = model.predict(X_test_s)
        else:
            raise ValueError(f"Unknown model: {model_name}")

        # Performance on validation set
        if X_val is not None and len(val_data) > 0:
            y_val_pred = model.predict(scaler.transform(X_val))
            rmse = np.sqrt(mean_squared_error(y_val, y_val_pred))
            mae  = mean_absolute_error(y_val, y_val_pred)
            dacc = direction_accuracy(y_val, y_val_pred)
        else:
            rmse, mae, dacc = np.nan, np.nan, np.nan

        perf_records.append({"date": test_date, "model": model_name,
                              "val_rmse": rmse, "val_mae": mae, "val_diracc": dacc})

        for j, row in test_data.reset_index(drop=True).iterrows():
            all_preds.append({
                "date":             test_date,
                "ticker":           row["ticker"],
                "predicted_return": y_pred[j],
                "model":            model_name,
            })

        if i % 12 == 0:
            log.info(f"  [{model_name}] {test_date.date()} -- "
                     f"N_test={len(test_data)}, val_RMSE={rmse:.5f}, DirAcc={dacc:.3f}")

    preds_df = pd.DataFrame(all_preds)
    perf_df  = pd.DataFrame(perf_records)
    return preds_df, perf_df


def main():
    log.info("=" * 70)
    log.info("Phase 3: Walk-Forward ML Return Forecasting")
    log.info("=" * 70)

    if not (DATA_PROC / "factors_monthly.csv").exists():
        log.error("factors_monthly.csv not found. Run 02_factor_model.py first.")
        sys.exit(1)

    data = load_data()

    all_preds = []
    all_perf  = []

    for model_name in ["ElasticNet", "RandomForest", "XGBoost"]:
        log.info(f"\n--- Model: {model_name} ---")
        preds, perf = walk_forward_predict(data, model_name)
        all_preds.append(preds)
        all_perf.append(perf)

    preds_all = pd.concat(all_preds, ignore_index=True)
    perf_all  = pd.concat(all_perf,  ignore_index=True)

    # Ensemble forecast: simple average across models
    ensemble = (preds_all.groupby(["date", "ticker"])["predicted_return"]
                .mean().reset_index()
                .rename(columns={"predicted_return": "predicted_return"}))
    ensemble["model"] = "Ensemble"
    preds_all = pd.concat([preds_all, ensemble], ignore_index=True)

    # Save
    preds_all.to_csv(DATA_PROC / "ml_forecasts.csv", index=False)
    perf_all.to_csv(DATA_PROC / "ml_performance.csv", index=False)

    log.info("\nModel performance summary (validation set, averaged over time):")
    summary = perf_all.groupby("model")[["val_rmse", "val_mae", "val_diracc"]].mean()
    log.info("\n" + summary.to_string())

    log.info(f"\n[OK] Forecasts saved: {DATA_PROC / 'ml_forecasts.csv'}")
    log.info(f"[OK] Performance  : {DATA_PROC / 'ml_performance.csv'}")


if __name__ == "__main__":
    main()
