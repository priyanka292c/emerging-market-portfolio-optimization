"""
04_regime_detection.py
=======================
Hidden Markov Model (HMM) market-regime detection.

Design:
  - Fit HMM on TRAINING period only. Apply to full period (in-sample train;
    smoothed probabilities on test period computed using forward algorithm only --
    no future information enters regime estimation via Viterbi on test data).
  - Number of states: determined by BIC over training period (k=2,3,4).
  - Features: BIST-100 monthly returns, monthly realised volatility,
               VIX monthly average, USD/TRY monthly return.
  - At each rebalancing date, the estimated regime state (or probability vector)
    is recorded for use in portfolio construction.

Walk-forward discipline:
  - At each rebalancing date t, refit the HMM on all data before t.
  - Record smoothed state probabilities for date t.
  - This avoids look-ahead in regime identification.

Outputs:
  - Data/processed/regime_states.csv      : state at each month-end date
  - Data/processed/regime_probs.csv       : smoothed probabilities per state
  - Data/processed/regime_characteristics.csv: mean/vol per regime
  - Logs/04_regime_detection.log
"""

import sys
import logging
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

warnings.filterwarnings("ignore")

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
LOG_DIR   = ROOT / "Logs"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "04_regime_detection.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

MIN_TRAIN_MONTHS = 36   # minimum months before first regime estimate
MAX_STATES       = 4
RANDOM_RESTARTS  = 3
RANDOM_STATE     = 42


def build_hmm_features(macro: pd.DataFrame,
                       returns_daily: pd.DataFrame) -> pd.DataFrame:
    """
    Construct monthly HMM input features.
    Returns a DataFrame indexed by month-end dates.
    """
    # BIST-100 monthly return
    if "BIST100" in macro.columns:
        bist100_ret = macro["BIST100"].resample("ME").last().pct_change().rename("bist100_ret")
    else:
        log.warning("BIST100 not in macro -- computing from universe average.")
        bist100_ret = returns_daily.mean(axis=1).resample("ME").sum().rename("bist100_ret")

    # Monthly realised volatility of BIST-100 (std of daily returns in month)
    if "BIST100" in macro.columns:
        bist100_daily_ret = macro["BIST100"].pct_change()
        realised_vol = bist100_daily_ret.resample("ME").std().rename("realised_vol") * np.sqrt(21)
    else:
        realised_vol = returns_daily.mean(axis=1).resample("ME").std().rename("realised_vol") * np.sqrt(21)

    # VIX monthly average
    if "VIX" in macro.columns:
        vix_monthly = macro["VIX"].resample("ME").mean().rename("vix")
    else:
        log.warning("VIX not in macro -- omitting from HMM features.")
        vix_monthly = None

    # USD/TRY monthly return
    if "USDTRY" in macro.columns:
        usdtry_ret = macro["USDTRY"].resample("ME").last().pct_change().rename("usdtry_ret")
    else:
        log.warning("USDTRY not in macro -- omitting from HMM features.")
        usdtry_ret = None

    frames = [bist100_ret, realised_vol]
    if vix_monthly is not None:
        frames.append(vix_monthly)
    if usdtry_ret is not None:
        frames.append(usdtry_ret)

    features = pd.concat(frames, axis=1).dropna()
    features.index = pd.to_datetime(features.index)
    log.info(f"HMM feature matrix: {features.shape}, columns: {list(features.columns)}")
    return features


def select_n_states(X: np.ndarray, max_k: int = MAX_STATES) -> int:
    """Select number of HMM states by BIC on training data."""
    try:
        from hmmlearn import hmm
    except ImportError:
        log.error("hmmlearn not installed. Run: pip install hmmlearn")
        sys.exit(1)

    best_bic = np.inf
    best_k   = 2
    n, d     = X.shape

    for k in range(2, max_k + 1):
        try:
            model = hmm.GaussianHMM(n_components=k, covariance_type="full",
                                     n_iter=200, random_state=RANDOM_STATE)
            model.fit(X)
            # BIC = -2 * log-likelihood + n_params * log(n_samples)
            n_params = k * k + k * d + k * d * (d + 1) // 2  # transitions + means + covs
            bic = -2 * model.score(X) * n + n_params * np.log(n)
            log.info(f"  k={k}: BIC={bic:.2f}")
            if bic < best_bic:
                best_bic = bic
                best_k   = k
        except Exception as e:
            log.warning(f"  k={k}: fitting failed ({e})")

    log.info(f"Selected k={best_k} states (lowest BIC={best_bic:.2f})")
    return best_k


def label_regimes(model, n_states: int) -> dict:
    """
    Label regimes by mean return (sorted ascending):
    0 = lowest return (Bear/Crisis), ..., n-1 = highest return (Bull).
    Returns {state_id -> label_string}.
    """
    means = model.means_[:, 0]   # first feature = market return
    order = np.argsort(means)
    labels_base = ["Bear", "Normal", "Bull", "Strong Bull"]
    if n_states == 2:
        labels_base = ["Bear/Normal", "Bull"]
    elif n_states == 3:
        labels_base = ["Bear", "Normal", "Bull"]
    label_map = {}
    for rank, state in enumerate(order):
        label_map[state] = labels_base[rank]
    return label_map


def walk_forward_regimes(features: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    For each month t after MIN_TRAIN_MONTHS:
      1. Fit HMM on data[0:t] (training only).
      2. Compute forward-only smoothed probability for date t.
      3. Record most-likely state.
    Returns:
        states_df : [date, state, label]
        probs_df  : [date, state_0, state_1, ...]
    """
    try:
        from hmmlearn import hmm
    except ImportError:
        log.error("hmmlearn not installed.")
        sys.exit(1)

    dates  = features.index
    scaler = StandardScaler()

    state_records = []
    prob_records  = []

    for i in range(MIN_TRAIN_MONTHS, len(dates)):
        date         = dates[i]
        train_sub    = features.iloc[:i]
        current_obs  = features.iloc[[i]]

        X_train = scaler.fit_transform(train_sub.values)
        X_curr  = scaler.transform(current_obs.values)

        # Select n_states on first iteration or every 24 months
        if i == MIN_TRAIN_MONTHS or (i - MIN_TRAIN_MONTHS) % 24 == 0:
            n_states = select_n_states(X_train, MAX_STATES)

        best_ll   = -np.inf
        best_model = None
        for _ in range(RANDOM_RESTARTS):
            try:
                m = hmm.GaussianHMM(n_components=n_states, covariance_type="full",
                                     n_iter=200, random_state=np.random.randint(0, 9999))
                m.fit(X_train)
                ll = m.score(X_train)
                if ll > best_ll:
                    best_ll    = ll
                    best_model = m
            except Exception:
                continue

        if best_model is None:
            log.warning(f"HMM fitting failed for date {date.date()} -- state set to NaN")
            state_records.append({"date": date, "state": np.nan, "label": "Unknown"})
            continue

        # Forward-only smoothed probabilities for current observation
        # Append current obs to training sequence and compute smoothed probs
        X_full = np.vstack([X_train, X_curr])
        try:
            _, posteriors = best_model.score_samples(X_full)
            curr_probs    = posteriors[-1]          # probabilities at current date
        except Exception:
            curr_probs = np.full(n_states, 1.0 / n_states)

        most_likely = int(np.argmax(curr_probs))
        label_map   = label_regimes(best_model, n_states)

        state_records.append({
            "date":  date,
            "state": most_likely,
            "label": label_map.get(most_likely, str(most_likely)),
        })
        prob_rec = {"date": date}
        for s in range(n_states):
            prob_rec[f"prob_state_{s}"] = float(curr_probs[s])
        prob_records.append(prob_rec)

        if (i - MIN_TRAIN_MONTHS) % 12 == 0:
            log.info(f"  {date.date()} -> State {most_likely} "
                     f"({label_map.get(most_likely, '?')}), "
                     f"probs={np.round(curr_probs, 3)}")

    states_df = pd.DataFrame(state_records)
    probs_df  = pd.DataFrame(prob_records)
    return states_df, probs_df


def compute_regime_characteristics(returns_daily: pd.DataFrame,
                                    states_df: pd.DataFrame) -> pd.DataFrame:
    """Compute mean return, vol, Sharpe per regime."""
    monthly_ret = np.expm1(returns_daily.resample("ME").sum())
    monthly_ret.index = pd.to_datetime(monthly_ret.index)
    avg_ret = monthly_ret.mean(axis=1).rename("market_return")

    avg_ret_df = avg_ret.reset_index()
    avg_ret_df.columns = ["date", "market_return"]
    avg_ret_df["date"] = pd.to_datetime(avg_ret_df["date"])
    states_df_copy = states_df.copy()
    states_df_copy["date"] = pd.to_datetime(states_df_copy["date"])
    merged = states_df_copy.merge(avg_ret_df, on="date", how="left").dropna()

    chars = []
    for lbl, grp in merged.groupby("label"):
        ret = grp["market_return"]
        chars.append({
            "regime":       lbl,
            "n_months":     len(ret),
            "mean_monthly": ret.mean(),
            "std_monthly":  ret.std(),
            "ann_return":   (1 + ret.mean()) ** 12 - 1,
            "ann_vol":      ret.std() * np.sqrt(12),
            "sharpe_monthly": ret.mean() / ret.std() if ret.std() > 0 else np.nan,
            "pct_positive": (ret > 0).mean(),
        })

    return pd.DataFrame(chars)


def main():
    log.info("=" * 70)
    log.info("Phase 4: Walk-Forward HMM Regime Detection")
    log.info("=" * 70)

    macro_path = DATA_PROC / "macro.csv"
    ret_path   = DATA_PROC / "returns.csv"
    if not macro_path.exists() or not ret_path.exists():
        log.error("macro.csv or returns.csv not found. Run 01_data_pipeline.py first.")
        sys.exit(1)

    macro   = pd.read_csv(macro_path, index_col=0, parse_dates=True)
    returns = pd.read_csv(ret_path,   index_col=0, parse_dates=True)

    features = build_hmm_features(macro, returns)
    if len(features) < MIN_TRAIN_MONTHS + 6:
        log.error(f"Insufficient data: {len(features)} months (need >= {MIN_TRAIN_MONTHS + 6})")
        sys.exit(1)

    log.info(f"\nRunning walk-forward HMM ({MIN_TRAIN_MONTHS}-month training burn-in)...")
    states_df, probs_df = walk_forward_regimes(features)

    chars = compute_regime_characteristics(returns, states_df)

    states_df.to_csv(DATA_PROC / "regime_states.csv",         index=False)
    probs_df.to_csv(DATA_PROC  / "regime_probs.csv",          index=False)
    chars.to_csv(DATA_PROC     / "regime_characteristics.csv", index=False)

    log.info(f"\n[OK] Regime states : {DATA_PROC / 'regime_states.csv'}")
    log.info(f"[OK] Regime probs  : {DATA_PROC / 'regime_probs.csv'}")
    log.info(f"[OK] Regime chars  : {DATA_PROC / 'regime_characteristics.csv'}")
    log.info("\nRegime distribution:")
    log.info(states_df["label"].value_counts().to_string())


if __name__ == "__main__":
    main()
