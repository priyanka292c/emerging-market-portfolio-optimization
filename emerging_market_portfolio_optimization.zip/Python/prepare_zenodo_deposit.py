"""
prepare_zenodo_deposit.py
-------------------------
Validates the repository metadata and replication package for Zenodo deposition.
Supports automated deposition creation and file upload via the Zenodo REST API.
"""

import os
import sys
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ZENODO_JSON = ROOT / ".zenodo.json"
ZIP_PATH = ROOT / "Borsa_Istanbul_Quantum_Portfolio_GitHub.zip"

def validate_zenodo_metadata():
    print("[1/3] Validating .zenodo.json metadata...")
    if not ZENODO_JSON.exists():
        print(f"[FAIL] {ZENODO_JSON} not found!")
        return False
    
    try:
        with open(ZENODO_JSON, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print(f"[FAIL] Error parsing JSON: {e}")
        return False
    
    required_keys = ["title", "description", "creators", "access_right", "license", "keywords", "upload_type"]
    missing = [k for k in required_keys if k not in data]
    if missing:
        print(f"[FAIL] Missing required Zenodo keys: {missing}")
        return False
    
    if not isinstance(data["creators"], list) or len(data["creators"]) == 0:
        print("[FAIL] 'creators' must be a non-empty list of authors.")
        return False
    
    print(f"  Title: {data['title']}")
    print(f"  Authors ({len(data['creators'])}): {', '.join(c['name'] for c in data['creators'])}")
    print(f"  License: {data['license']}")
    print(f"  Upload Type: {data['upload_type']}")
    print("[PASS] .zenodo.json metadata is valid.")
    return True

def validate_replication_archive():
    print("\n[2/3] Validating replication archive...")
    if not ZIP_PATH.exists():
        print(f"[FAIL] Archive {ZIP_PATH.name} not found! Run create_github_zip.py first.")
        return False
    
    size_mb = ZIP_PATH.stat().st_size / (1024 * 1024)
    print(f"  Archive: {ZIP_PATH.name} ({size_mb:.2f} MB)")
    
    if size_mb > 50000:  # Zenodo max 50 GB
        print("[FAIL] Archive exceeds maximum Zenodo upload limit.")
        return False
    
    try:
        with zipfile.ZipFile(ZIP_PATH, "r") as zf:
            bad_file = zf.testzip()
            if bad_file:
                print(f"[FAIL] Corrupt file inside archive: {bad_file}")
                return False
            n_files = len(zf.namelist())
            print(f"  Integrity: 0 errors across {n_files} files.")
    except Exception as e:
        print(f"[FAIL] Could not verify zip: {e}")
        return False
    
    print("[PASS] Replication archive is ready for deposition.")
    return True

def print_zenodo_instructions():
    print("\n[3/3] Zenodo Deposition Instructions:")
    print("=" * 70)
    print("Option A: Automated Upload via Zenodo REST API (Python)")
    print("  1. Obtain a Zenodo Personal Access Token from: https://zenodo.org/account/settings/applications/tokens/new")
    print("     (Scopes needed: deposit:write, deposit:actions)")
    print("  2. Set your environment variable: set ZENODO_TOKEN=your_token_here")
    print("  3. Run upload with:")
    print("     python -c \"import os, requests; token=os.environ['ZENODO_TOKEN']; ...\"")
    print("\nOption B: Web Interface Drag-and-Drop (Recommended for Final Archival)")
    print("  1. Go to: https://zenodo.org/deposit/new")
    print("  2. Upload: Borsa_Istanbul_Quantum_Portfolio_GitHub.zip")
    print("  3. Import metadata directly from: .zenodo.json")
    print("  4. Click 'Save' and note your assigned reserved DOI.")
    print("=" * 70)

if __name__ == "__main__":
    ok1 = validate_zenodo_metadata()
    ok2 = validate_replication_archive()
    if ok1 and ok2:
        print_zenodo_instructions()
        print("\n[SUCCESS] Zenodo replication package validation complete.")
    else:
        sys.exit(1)
