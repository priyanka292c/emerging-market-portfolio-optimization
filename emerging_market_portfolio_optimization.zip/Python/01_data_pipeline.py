"""
01_data_pipeline.py
====================
Downloads and validates BIST equity data from yfinance.
Applies point-in-time discipline: no future information used.
Produces:
  - Data/processed/prices.csv        : adjusted close prices
  - Data/processed/volumes.csv       : daily volumes
  - Data/processed/returns.csv       : daily log returns
  - Data/processed/market_caps.csv   : market capitalisation (price x shares)
  - Data/processed/fundamentals.csv  : balance-sheet / income items with report_date
  - Data/processed/macro.csv         : macro variables (VIX, USD/TRY, BIST-100)
  - Data/quality_report/dq_report.csv: data-quality report
  - Logs/01_data_pipeline.log

Usage:
    python Python/01_data_pipeline.py

Environment:
    Python 3.12  |  pandas 3.x  |  numpy 2.x  |  yfinance (latest)
"""

import os
import sys
import logging
import json
import warnings
from pathlib import Path
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT = Path(__file__).resolve().parents[1]
DATA_RAW = ROOT / "Data" / "raw"
DATA_PROC = ROOT / "Data" / "processed"
DATA_QR = ROOT / "Data" / "quality_report"
LOG_DIR = ROOT / "Logs"
for d in [DATA_RAW, DATA_PROC, DATA_QR, LOG_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "01_data_pipeline.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
START_DATE = "2010-01-01"
END_DATE   = "2026-07-31"   # Latest available; actual cutoff determined by yfinance
REPORTING_LAG_DAYS = 60     # Days after fiscal quarter end before disclosure assumed known

# BIST-30 core liquid tickers as of 2024 (survivorship note: tickers that existed
# continuously may not represent the full historical index--documented limitation).
# We use a manually curated list of tickers with consistent yfinance coverage.
BIST_TICKERS = [
    "AKBNK.IS", "ARCLK.IS", "ASELS.IS", "BIMAS.IS", "EKGYO.IS",
    "ENKAI.IS", "EREGL.IS", "FROTO.IS", "GARAN.IS", "HALKB.IS",
    "ISCTR.IS", "KCHOL.IS", "KOZAA.IS", "KOZAL.IS", "KRDMD.IS",
    "LOGO.IS",  "MGROS.IS", "ODAS.IS",  "PETKM.IS", "PGSUS.IS",
    "SAHOL.IS", "SASA.IS",  "SISE.IS",  "TAVHL.IS", "TCELL.IS",
    "THYAO.IS", "TKFEN.IS", "TOASO.IS", "TTKOM.IS", "TUPRS.IS",
    "VAKBN.IS", "VESTL.IS", "YKBNK.IS",
]

# Macro tickers (yfinance symbols)
MACRO_TICKERS = {
    "USDTRY": "USDTRY=X",     # USD/TRY exchange rate
    "VIX":    "^VIX",         # CBOE VIX
    "BIST100":"XU100.IS",      # BIST-100 index
    "GOLD":   "GC=F",          # Gold futures
    "BRENT":  "BZ=F",          # Brent crude
}

# Extreme-return threshold (flag|return| > threshold for manual review)
EXTREME_RETURN_THRESHOLD = 0.50   # 50% single-day return flagged

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def download_prices(tickers: list[str], start: str, end: str) -> pd.DataFrame:
    """Download adjusted-close prices using yfinance. Returns a DataFrame
    with dates as index and tickers as columns. Missing tickers are logged."""
    try:
        import yfinance as yf
    except ImportError:
        log.error("yfinance not installed. Run: pip install yfinance")
        sys.exit(1)

    log.info(f"Downloading price data for {len(tickers)} tickers: {start} -> {end}")
    raw = yf.download(
        tickers,
        start=start,
        end=end,
        auto_adjust=True,
        progress=False,
        threads=True,
    )
    if raw.empty:
        log.error("yfinance returned empty DataFrame. Check network and ticker symbols.")
        sys.exit(1)

    # yfinance returns MultiIndex columns when >1 ticker
    if isinstance(raw.columns, pd.MultiIndex):
        close  = raw["Close"]
        volume = raw["Volume"]
    else:
        close  = raw[["Close"]]
        volume = raw[["Volume"]]
        close.columns  = tickers[:1]
        volume.columns = tickers[:1]

    # Drop tickers that are entirely NaN
    empty_tickers = close.columns[close.isna().all()].tolist()
    if empty_tickers:
        log.warning(f"Tickers with NO data (dropped): {empty_tickers}")
        close  = close.drop(columns=empty_tickers)
        volume = volume.drop(columns=empty_tickers)

    log.info(f"Downloaded {len(close.columns)} tickers, {len(close)} trading days.")
    return close, volume


def download_macro(macro_dict: dict, start: str, end: str) -> pd.DataFrame:
    """Download macro variables."""
    try:
        import yfinance as yf
    except ImportError:
        log.error("yfinance not installed.")
        sys.exit(1)

    frames = {}
    for name, sym in macro_dict.items():
        log.info(f"  Downloading macro: {name} ({sym})")
        try:
            df = yf.download(sym, start=start, end=end, auto_adjust=True, progress=False)
            if df.empty:
                log.warning(f"  {name}: empty -- skipping")
                continue
            col = "Close" if "Close" in df.columns else df.columns[0]
            frames[name] = df[col]
        except Exception as e:
            log.warning(f"  {name}: download failed ({e})")

    if not frames:
        log.error("All macro downloads failed.")
        return pd.DataFrame()

    macro = pd.concat(frames, axis=1, sort=False)
    macro.columns = list(frames.keys())
    macro.index = pd.to_datetime(macro.index)
    macro.index.name = "Date"
    log.info(f"Macro data shape: {macro.shape}")
    return macro


def download_fundamentals(tickers: list[str]) -> pd.DataFrame:
    """
    Download point-in-time fundamentals using yfinance quarterly financials.
    Returns a DataFrame with columns:
        ticker, report_date, fiscal_quarter_end, book_equity, net_income, shares_outstanding
    'report_date' = fiscal_quarter_end + REPORTING_LAG_DAYS
    This enforces point-in-time discipline: the data is assumed known
    only after the reporting lag.
    """
    try:
        import yfinance as yf
    except ImportError:
        log.error("yfinance not installed.")
        sys.exit(1)

    records = []
    for ticker in tickers:
        log.info(f"  Fetching fundamentals: {ticker}")
        try:
            tk = yf.Ticker(ticker)

            # Balance sheet: quarterly
            bs = tk.quarterly_balance_sheet
            if bs is None or bs.empty:
                log.warning(f"  {ticker}: no balance sheet data")
                continue

            # Income statement: quarterly
            inc = tk.quarterly_income_stmt
            if inc is None or inc.empty:
                log.warning(f"  {ticker}: no income statement data")
                inc = pd.DataFrame()

            for col in bs.columns:
                fq_end = pd.to_datetime(col)
                report_date = fq_end + timedelta(days=REPORTING_LAG_DAYS)

                # Book equity = Total Stockholders Equity
                book_equity = None
                for key in ["Stockholders Equity", "Total Stockholder Equity",
                             "Common Stock Equity", "Total Equity"]:
                    if key in bs.index:
                        v = bs.loc[key, col]
                        if pd.notna(v):
                            book_equity = float(v)
                            break

                # Net income
                net_income = None
                if not inc.empty and col in inc.columns:
                    for key in ["Net Income", "Net Income Common Stockholders"]:
                        if key in inc.index:
                            v = inc.loc[key, col]
                            if pd.notna(v):
                                net_income = float(v)
                                break

                # Shares outstanding (basic; not time-varying in yfinance -- use as proxy)
                shares = None
                try:
                    shares = float(tk.info.get("sharesOutstanding", np.nan))
                except Exception:
                    pass

                records.append({
                    "ticker":              ticker,
                    "fiscal_quarter_end":  fq_end,
                    "report_date":         report_date,
                    "book_equity":         book_equity,
                    "net_income":          net_income,
                    "shares_outstanding":  shares,
                })
        except Exception as e:
            log.warning(f"  {ticker}: fundamentals error ({e})")

    if not records:
        log.warning("No fundamental data collected.")
        return pd.DataFrame()

    df = pd.DataFrame(records)
    df["fiscal_quarter_end"] = pd.to_datetime(df["fiscal_quarter_end"])
    df["report_date"]        = pd.to_datetime(df["report_date"])
    df = df.sort_values(["ticker", "report_date"]).reset_index(drop=True)
    log.info(f"Fundamentals collected: {len(df)} quarterly records for {df['ticker'].nunique()} tickers.")
    return df


def compute_returns(prices: pd.DataFrame) -> pd.DataFrame:
    """Compute daily log returns. First row is NaN (dropped)."""
    returns = np.log(prices / prices.shift(1)).dropna(how="all")
    return returns


def quality_report(prices: pd.DataFrame, returns: pd.DataFrame,
                   volumes: pd.DataFrame) -> pd.DataFrame:
    """Generate data-quality statistics per ticker."""
    records = []
    for ticker in prices.columns:
        p = prices[ticker].dropna()
        r = returns[ticker].dropna() if ticker in returns.columns else pd.Series(dtype=float)
        v = volumes[ticker].dropna() if ticker in volumes.columns else pd.Series(dtype=float)

        n_obs        = len(p)
        n_missing    = prices[ticker].isna().sum()
        pct_missing  = 100.0 * n_missing / max(len(prices), 1)
        n_extreme    = (r.abs() > EXTREME_RETURN_THRESHOLD).sum() if len(r) else 0
        n_zero_vol   = (v == 0).sum() if len(v) else 0
        first_date   = p.index.min() if n_obs else pd.NaT
        last_date    = p.index.max() if n_obs else pd.NaT
        ann_return   = np.exp(r.mean() * 252) - 1 if len(r) > 10 else np.nan
        ann_vol      = r.std() * np.sqrt(252)    if len(r) > 10 else np.nan

        records.append({
            "ticker":       ticker,
            "n_obs":        n_obs,
            "n_missing":    n_missing,
            "pct_missing":  round(pct_missing, 2),
            "first_date":   first_date,
            "last_date":    last_date,
            "n_extreme_returns": n_extreme,
            "n_zero_volume":     n_zero_vol,
            "ann_return_approx": round(ann_return, 4) if not np.isnan(ann_return) else np.nan,
            "ann_vol_approx":    round(ann_vol, 4)    if not np.isnan(ann_vol)    else np.nan,
        })

    dq = pd.DataFrame(records)
    return dq


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    log.info("=" * 70)
    log.info("Phase 1: Data Pipeline")
    log.info(f"  Period  : {START_DATE} -> {END_DATE}")
    log.info(f"  Tickers : {len(BIST_TICKERS)}")
    log.info(f"  Lag     : {REPORTING_LAG_DAYS} days")
    log.info("=" * 70)

    warnings.filterwarnings("ignore", category=FutureWarning)

    # --- Price data ---
    prices, volumes = download_prices(BIST_TICKERS, START_DATE, END_DATE)
    prices.index  = pd.to_datetime(prices.index)
    volumes.index = pd.to_datetime(volumes.index)

    # Forward-fill at most 3 consecutive missing days (stale-price handling)
    prices_filled = prices.ffill(limit=3)
    n_ffill = prices.isna().sum().sum() - prices_filled.isna().sum().sum()
    log.info(f"Forward-filled {n_ffill} missing price observations (limit=3).")

    # --- Returns ---
    returns = compute_returns(prices_filled)

    # --- Market cap (price x shares: shares approximated as constant from info) ---
    # Note: yfinance does not provide historical shares outstanding reliably.
    # Market cap is therefore an approximation. Documented limitation.
    log.warning("Market cap uses current shares outstanding as approximation -- see documentation.")

    # --- Macro data ---
    macro = download_macro(MACRO_TICKERS, START_DATE, END_DATE)
    macro.index = pd.to_datetime(macro.index)

    # --- Fundamentals ---
    log.info("Downloading fundamental data (this may take several minutes)...")
    fundamentals = download_fundamentals(list(prices.columns))

    # --- Quality report ---
    dq = quality_report(prices, returns, volumes)
    log.info("\nData Quality Summary:")
    log.info(f"  Tickers with >10% missing: "
             f"{(dq['pct_missing'] > 10).sum()}")
    log.info(f"  Tickers with extreme returns: "
             f"{(dq['n_extreme_returns'] > 0).sum()}")
    log.info(f"  Tickers with zero-volume days: "
             f"{(dq['n_zero_volume'] > 5).sum()}")

    # --- Save ---
    prices_filled.to_csv(DATA_PROC / "prices.csv")
    volumes.to_csv(DATA_PROC / "volumes.csv")
    returns.to_csv(DATA_PROC / "returns.csv")
    macro.to_csv(DATA_PROC / "macro.csv")
    if not fundamentals.empty:
        fundamentals.to_csv(DATA_PROC / "fundamentals.csv", index=False)
    dq.to_csv(DATA_QR / "dq_report.csv", index=False)

    # Meta
    meta = {
        "start_date":       START_DATE,
        "end_date":         END_DATE,
        "actual_first_date": str(prices_filled.index.min().date()),
        "actual_last_date":  str(prices_filled.index.max().date()),
        "n_tickers":         int(len(prices_filled.columns)),
        "n_trading_days":    int(len(prices_filled)),
        "tickers":           list(prices_filled.columns),
        "reporting_lag_days": REPORTING_LAG_DAYS,
        "generated_at":      datetime.now().isoformat(),
        "survivorship_note": (
            "This ticker list represents liquid BIST stocks with yfinance coverage "
            "as of 2024. Stocks that were delisted or merged during 2010-2026 may "
            "be missing, introducing potential survivorship bias. This is a documented "
            "limitation of the study."
        ),
        "market_cap_note": (
            "Market capitalisation is approximated using current shares outstanding "
            "x historical price. Historical shares data is unavailable via yfinance."
        ),
    }
    with open(DATA_PROC / "meta.json", "w") as f:
        json.dump(meta, f, indent=2, default=str)

    log.info("\n[OK] Data pipeline complete.")
    log.info(f"  Prices     : {DATA_PROC / 'prices.csv'}")
    log.info(f"  Returns    : {DATA_PROC / 'returns.csv'}")
    log.info(f"  Macro      : {DATA_PROC / 'macro.csv'}")
    log.info(f"  Fundamentals: {DATA_PROC / 'fundamentals.csv'}")
    log.info(f"  DQ Report  : {DATA_QR / 'dq_report.csv'}")
    log.info(f"  Meta       : {DATA_PROC / 'meta.json'}")


if __name__ == "__main__":
    main()
