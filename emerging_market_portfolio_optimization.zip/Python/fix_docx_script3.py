﻿import os

path = r"D:\Quantum finance\22_09_2026\Python\generate_all_docx.py"
with open(path, "r", encoding="utf-8") as f:
    text = f.read()

# 1. Sender Info in cover letter
text = text.replace(
    'r = p_from.add_run("Shahrukh Saleem, Ph.D. (Corresponding Author)\\nAssistant Professor, VIT Business School, Vellore Institute of Technology (Deemed to be University)\\nVellore 632014, Tamil Nadu, India\\nEmail: shahrukh.saleem@vit.ac.in | ORCID: https://orcid.org/0000-0003-2949-6188\\nSeptember 29, 2026")',
    'r = p_from.add_run("Ram Soorat (Corresponding Author)\\nAssistant Professor, School of Technology, Woxsen University\\nKamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\\nEmail: ram.soorat@woxsen.edu.in | Telephone: +91 8455 305555 | ORCID: https://orcid.org/0000-0001-7875-9197\\nSeptember 29, 2026")'
)

# 2. Signoff in cover letter
text = text.replace(
    '"Sincerely,\\nShahrukh Saleem, Ph.D. (Corresponding Author)\\nAssistant Professor, VIT Business School, Vellore Institute of Technology, India\\nEmail: shahrukh.saleem@vit.ac.in\\n\\nOn behalf of all co-authors:\\nShahrukh Saleem, Araby Madbouly, Uvesh Husain, Ram Soorat, Priyanka, and Afzalur Rahman"',
    '"Sincerely,\\nRam Soorat (Corresponding Author)\\nAssistant Professor, School of Technology, Woxsen University, Hyderabad, India\\nEmail: ram.soorat@woxsen.edu.in\\n\\nOn behalf of all co-authors:\\nShahrukh Saleem, Araby Madbouly, Uvesh Husain, Ram Soorat, Priyanka, and Afzalur Rahman"'
)

# 3. Table in cover letter
text = text.replace(
    '["Shahrukh Saleem\\n(Corresponding)", "Assistant Professor", "VIT Business School, Vellore Institute of Technology, India", "Email: shahrukh.saleem@vit.ac.in\\nORCID: 0000-0003-2949-6188"],',
    '["Shahrukh Saleem", "Assistant Professor", "VIT Business School, Vellore Institute of Technology, India", "Email: shahrukh.saleem@vit.ac.in\\nORCID: 0000-0003-2949-6188"],'
)
text = text.replace(
    '["Ram Soorat", "Assistant Professor", "School of Technology, Woxsen University, Hyderabad, India", "Email: ram.soorat@woxsen.edu.in\\nORCID: 0000-0001-7875-9197"],',
    '["Ram Soorat\\n(Corresponding)", "Assistant Professor", "School of Technology, Woxsen University, Hyderabad, India", "Email: ram.soorat@woxsen.edu.in\\nORCID: 0000-0001-7875-9197"],'
)

# 4. Supplementary author block
text = text.replace(
    'r_a = p_auth.add_run("Shahrukh Saleem1,*, Araby Madbouly2, Uvesh Husain3, Ram Soorat4, Priyanka5, Afzalur Rahman6\\n"',
    'r_a = p_auth.add_run("Shahrukh Saleem1, Araby Madbouly2, Uvesh Husain3, Ram Soorat4,*, Priyanka5, Afzalur Rahman6\\n"'
)
text = text.replace(
    '"*Corresponding Author: Assistant Professor, VIT Business School. Email: shahrukh.saleem@vit.ac.in | ORCID: 0000-0003-2949-6188\\n"\n'
    '                         "Co-Author Emails: araby@muscatcollege.edu.om, owais.husain@mazcol.edu.om, ram.soorat@woxsen.edu.in, priyanka1@physics.du.ac.in, afzalur.rahman@woxsen.edu.in\\n"\n'
    '                         "Co-Author ORCIDs: A. Madbouly (0000-0002-7981-4191), U. Husain (0000-0002-8502-8488), R. Soorat (0000-0001-7875-9197), Priyanka (0009-0008-1520-0706), A. Rahman (0000-0002-1561-561X)")',
    '"*Corresponding Author: Assistant Professor, School of Technology, Woxsen University. Email: ram.soorat@woxsen.edu.in | ORCID: 0000-0001-7875-9197\\n"\n'
    '                         "Co-Author Emails: shahrukh.saleem@vit.ac.in, araby@muscatcollege.edu.om, owais.husain@mazcol.edu.om, priyanka1@physics.du.ac.in, afzalur.rahman@woxsen.edu.in\\n"\n'
    '                         "Co-Author ORCIDs: S. Saleem (0000-0003-2949-6188), A. Madbouly (0000-0002-7981-4191), U. Husain (0000-0002-8502-8488), Priyanka (0009-0008-1520-0706), A. Rahman (0000-0002-1561-561X)")'
)

# 5. Title Page Corresponding Author Details
text = text.replace(
    '        "Shahrukh Saleem, Ph.D.\\n"\n'
    '        "Assistant Professor, VIT Business School\\n"\n'
    '        "Vellore Institute of Technology (Deemed to be University)\\n"\n'
    '        "Vellore 632014, Tamil Nadu, India\\n"\n'
    '        "E-mail address: shahrukh.saleem@vit.ac.in\\n"\n'
    '        "ORCID: https://orcid.org/0000-0003-2949-6188"',
    '        "Ram Soorat\\n"\n'
    '        "Assistant Professor, School of Technology\\n"\n'
    '        "Woxsen University\\n"\n'
    '        "Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\\n"\n'
    '        "E-mail address: ram.soorat@woxsen.edu.in\\n"\n'
    '        "Telephone: +91 8455 305555\\n"\n'
    '        "ORCID: https://orcid.org/0000-0001-7875-9197"'
)

# 6. Title page coauthor table
text = text.replace(
    '        ["Shahrukh Saleem\\n(Corresponding)", "Assistant Professor", "VIT Business School, Vellore Institute of Technology, India", "shahrukh.saleem@vit.ac.in\\nORCID: 0000-0003-2949-6188"],\n'
    '        ["Araby Madbouly", "Associate Professor", "Business & Accounting Dept., Muscat College, Oman", "araby@muscatcollege.edu.om\\nORCID: 0000-0002-7981-4191"],\n'
    '        ["Uvesh Husain", "Associate Professor", "Economics & Business Studies Dept., Mazoon College, Oman", "owais.husain@mazcol.edu.om\\nORCID: 0000-0002-8502-8488"],\n'
    '        ["Ram Soorat", "Assistant Professor", "School of Technology, Woxsen University, Hyderabad, India", "ram.soorat@woxsen.edu.in\\nORCID: 0000-0001-7875-9197"],',
    '        ["Shahrukh Saleem", "Assistant Professor", "VIT Business School, Vellore Institute of Technology, India", "shahrukh.saleem@vit.ac.in\\nORCID: 0000-0003-2949-6188"],\n'
    '        ["Araby Madbouly", "Associate Professor", "Business & Accounting Dept., Muscat College, Oman", "araby@muscatcollege.edu.om\\nORCID: 0000-0002-7981-4191"],\n'
    '        ["Uvesh Husain", "Associate Professor", "Economics & Business Studies Dept., Mazoon College, Oman", "owais.husain@mazcol.edu.om\\nORCID: 0000-0002-8502-8488"],\n'
    '        ["Ram Soorat\\n(Corresponding)", "Assistant Professor", "School of Technology, Woxsen University, Hyderabad, India", "ram.soorat@woxsen.edu.in\\nORCID: 0000-0001-7875-9197"],'
)

# 7. Manuscript footnote block
text = text.replace(
    'r_fn_corr = p_fn.add_run("Corresponding author: Shahrukh Saleem (Assistant Professor, VIT Business School). E-mail address: shahrukh.saleem@vit.ac.in. ORCID: 0000-0003-2949-6188.\\n")',
    'r_fn_corr = p_fn.add_run("Corresponding author: Ram Soorat (Assistant Professor, School of Technology, Woxsen University). E-mail address: ram.soorat@woxsen.edu.in. ORCID: 0000-0001-7875-9197.\\n")'
)
text = text.replace(
    '"Co-author contacts: A. Madbouly (Associate Professor, araby@muscatcollege.edu.om, ORCID: 0000-0002-7981-4191); "\n'
    '        "U. Husain (Associate Professor, owais.husain@mazcol.edu.om, ORCID: 0000-0002-8502-8488); "\n'
    '        "R. Soorat (Assistant Professor, ram.soorat@woxsen.edu.in, ORCID: 0000-0001-7875-9197); "\n'
    '        "Priyanka (Researcher, priyanka1@physics.du.ac.in, ORCID: 0009-0008-1520-0706); "\n'
    '        "A. Rahman (Faculty, afzalur.rahman@woxsen.edu.in, ORCID: 0000-0002-1561-561X)."',
    '"Co-author contacts: S. Saleem (Assistant Professor, shahrukh.saleem@vit.ac.in, ORCID: 0000-0003-2949-6188); "\n'
    '        "A. Madbouly (Associate Professor, araby@muscatcollege.edu.om, ORCID: 0000-0002-7981-4191); "\n'
    '        "U. Husain (Associate Professor, owais.husain@mazcol.edu.om, ORCID: 0000-0002-8502-8488); "\n'
    '        "Priyanka (Researcher, priyanka1@physics.du.ac.in, ORCID: 0009-0008-1520-0706); "\n'
    '        "A. Rahman (Faculty, afzalur.rahman@woxsen.edu.in, ORCID: 0000-0002-1561-561X)."',
)

with open(path, "w", encoding="utf-8") as f:
    f.write(text)

print("generate_all_docx.py updated successfully.")
