import os

CL_DIRS = [
    r"D:\Quantum finance\22_09_2026\RIBAF_Submission\LaTeX",
    r"D:\Quantum finance\22_09_2026\LaTeX"
]

cl_content = r"""\documentclass[11pt,a4paper]{article}
\usepackage{amsmath,amssymb}
\usepackage[utf8]{inputenc}
\usepackage[margin=1.0in]{geometry}
\usepackage{setspace}
\setstretch{1.15}
\usepackage{xcolor}
\definecolor{darkblue}{rgb}{0.0, 0.15, 0.45}
\usepackage{xurl}
\usepackage[colorlinks=true,
            linkcolor=darkblue,
            citecolor=darkblue,
            urlcolor=darkblue,
            pdftitle={Cover Letter: Research in International Business and Finance},
            pdfauthor={Ram Soorat}]{hyperref}
\usepackage{charter}
\usepackage{booktabs}
\usepackage{tabularx}
\usepackage{array}
\usepackage{enumitem}

\newcolumntype{L}[1]{>{\raggedright\arraybackslash}p{#1}}
\newcolumntype{Y}{>{\raggedright\arraybackslash}X}

\begin{document}

\noindent
\textbf{Ram Soorat} (Corresponding Author)\\
Assistant Professor, School of Technology\\
Woxsen University\\
Kamkole, Sadasivpet, Sangareddy, Hyderabad, Telangana 502345, India\\
Email: \texttt{ram.soorat@woxsen.edu.in} \quad $\cdot$ \quad Telephone: +91 8455 305555 \quad $\cdot$ \quad ORCID: \url{https://orcid.org/0000-0001-7875-9197}\\[0.4em]
\textit{On behalf of co-authors: Shahrukh Saleem, Araby Madbouly, Uvesh Husain, Priyanka, and Afzalur Rahman}\\[1.0em]

\noindent
September 29, 2026\\[1.0em]

\noindent
To the Editor-in-Chief\\
\textit{Research in International Business and Finance}\\
Elsevier\\[1.0em]

\noindent
\textbf{Subject: Submission of Original Research Article titled ``Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market''}\\[0.8em]

\noindent
Dear Editor-in-Chief,

\vspace{0.4em}
\noindent
We submit our original research manuscript entitled \textbf{``Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market''} for publication consideration in \textit{Research in International Business and Finance} (RIBAF).

\vspace{0.5em}
\noindent
\textbf{Research Problem and Journal Scope Alignment:}\\
Portfolio allocation in emerging markets is challenged by sudden macroeconomic regime shifts, non-Gaussian tail risk, noisy factor signals, and substantial execution costs. While prior literature typically treats factor selection, regime switching, Conditional Value-at-Risk (CVaR), and transaction costs as isolated topics, their joint operational implementation under real-world cardinality constraints remains less explored. RIBAF specifically prioritizes rigorous empirical methodologies that address critical investment challenges in international and emerging capital markets. Our paper speaks directly to this mission by developing and evaluating an integrated allocation architecture in a dynamic emerging market setting.

\vspace{0.5em}
\noindent
\textbf{Core Contributions and Implementation Framework:}\\
Using Borsa Istanbul (2010--July 2026, 147 monthly walk-forward folds) as an empirical laboratory, we examine the practical trade-offs created by institutional portfolio constraints:
\begin{enumerate}[itemsep=3pt,topsep=2pt]
    \item \textbf{Integrated Architecture:} We combine point-in-time multi-factor modeling (incorporating a conservative 60-calendar-day information-availability lag aligned with CMB/SPK reporting; Directional Accuracy: 55.10\%--56.86\%; the primary Pesaran--Timmermann test provides strong evidence of directional predictability with $p < 10^{-17}$ for the reported primary specification), latent Markov regime conditioning, Ledoit--Wolf covariance shrinkage, and empirical Rockafellar--Uryasev CVaR.
    \item \textbf{Two-Stage Decomposition Heuristic:} To circumvent the computational intractability of monolithic mixed-integer quadratic programming (MIQP), we design a two-stage decomposition (HiGHS MILP asset selection + Clarabel continuous conic optimization) that executes in $<0.30$ seconds per fold with verified primal feasibility across all 147 rebalancing periods.
    \item \textbf{Trade-Off Framing and Passive Comparison:} Model E ($K \le 10$) achieves a nominal CAGR of 41.14\% in Turkish Lira (14\%-hurdle-adjusted Sharpe ratio of 0.8389; in-sample optimized CVaR of 13.90\%; realized out-of-sample CVaR of 14.12\%). Rather than asserting universal outperformance, we explicitly document the trade-offs: Model E trades return and realized drawdown relative to unconstrained models and simple passive benchmarks (Equal Weight and Risk Parity achieve lower realized CVaR of 10.68\% and 10.25\%) in exchange for cardinality restriction and formation tail-risk control.
    \item \textbf{Currency and Inflation Robustness:} In USD terms, Model E delivers a 9.70\% CAGR (USD Sharpe of 0.4000), closely mirroring its domestic inflation-adjusted real return of 9.84\% p.a., showing that the high nominal TRY return is substantially reduced when expressed in USD terms or after domestic CPI adjustment, consistent with the effects of currency depreciation and inflation.
    \item \textbf{Controlled Quantum Surrogate Benchmark:} On a reduced 12-qubit surrogate ($N_q = 4$ assets, $w_{\max} = 0.25$, linear tail-risk surrogate), classical exact search solves the combinatorial problem in milliseconds. Tested variational quantum algorithms (QAOA, VQE) achieve approximation ratios between 90.7\% and 99.5\%, with no quantum computational advantage observed for the investigated 12-qubit instances under the tested simulation conditions.
\end{enumerate}

\vspace{0.5em}
\noindent
\textbf{Declarations:} The manuscript is original, has not been published elsewhere, and is not under consideration by any other journal. All authors have approved the submission and declare no conflicts of interest. Replication code and derived datasets will be made openly available upon acceptance and permanently archived on Zenodo.

\vspace{1.0em}
\noindent
Sincerely,\\[0.8em]
\textbf{Ram Soorat} (Corresponding Author)\\
Assistant Professor, School of Technology\\
Woxsen University, Hyderabad, India\\
Email: \texttt{ram.soorat@woxsen.edu.in}

\newpage
\noindent
{\large\textbf{Suggested Reviewers and Co-Author Directory}}\\[0.8em]

\noindent
\textbf{Suggested Expert Reviewers:}
\begin{enumerate}[itemsep=2pt,topsep=2pt]
    \item \textbf{Prof. Riza Demirer} (Southern Illinois University Edwardsville, USA; \texttt{rdemire@siue.edu}) -- Emerging market finance, regime-switching, and Borsa Istanbul asset pricing.
    \item \textbf{Prof. Walid Mensi} (Sultan Qaboos University, Oman; \texttt{walid.mensi@squ.edu.om}) -- International financial integration, asymmetric risk spillovers, and emerging-market portfolios.
    \item \textbf{Prof. Daniel Palomar} (Hong Kong University of Science and Technology; \texttt{palomar@ust.hk}) -- Convex portfolio optimization, risk budgeting, and transaction cost modeling.
    \item \textbf{Prof. Rom\'an Or\'us} (Donostia International Physics Center / Multiverse Computing, Spain; \texttt{roman.orus@dipc.org}) -- Quantum computing and tensor networks for financial optimization.
    \item \textbf{Prof. Stefan Woerner} (IBM Quantum, Switzerland; \texttt{wor@zurich.ibm.com}) -- Variational quantum algorithms (QAOA, VQE) and financial applications.
\end{enumerate}

\vspace{1.0em}
\noindent
\textbf{Co-Author Directory:}\\[0.5em]
\noindent
\small
\urlstyle{same}
\begin{tabularx}{\textwidth}{@{} L{2.9cm} L{2.1cm} L{4.4cm} Y @{}}
\toprule
\textbf{Author} & \textbf{Rank} & \textbf{Institution} & \textbf{Contact \& ORCID} \\
\midrule
\textbf{Shahrukh Saleem} & Assistant Professor & VIT Business School, Vellore Institute of Technology, India & \href{mailto:shahrukh.saleem@vit.ac.in}{shahrukh.saleem@vit.ac.in}\\
& & & ORCID: \href{https://orcid.org/0000-0003-2949-6188}{0000-0003-2949-6188} \\
\addlinespace
\textbf{Araby Madbouly} & Associate Professor & Business \& Accounting Dept., Muscat College, Oman & \href{mailto:araby@muscatcollege.edu.om}{araby@muscatcollege.edu.om}\\
& & & ORCID: \href{https://orcid.org/0000-0002-7981-4191}{0000-0002-7981-4191} \\
\addlinespace
\textbf{Uvesh Husain} & Associate Professor & Economics \& Business Studies Dept., Mazoon College, Oman & \href{mailto:owais.husain@mazcol.edu.om}{owais.husain@mazcol.edu.om}\\
& & & ORCID: \href{https://orcid.org/0000-0002-8502-8488}{0000-0002-8502-8488} \\
\addlinespace
\textbf{Ram Soorat}\newline\textit{(Corresponding)} & Assistant Professor & School of Technology, Woxsen University, Hyderabad, India & \href{mailto:ram.soorat@woxsen.edu.in}{ram.soorat@woxsen.edu.in}\\
& & & ORCID: \href{https://orcid.org/0000-0001-7875-9197}{0000-0001-7875-9197} \\
\addlinespace
\textbf{Priyanka} & Researcher & Dept. of Physics \& Astrophysics, University of Delhi, India & \href{mailto:priyanka1@physics.du.ac.in}{priyanka1@physics.du.ac.in}\\
& & & ORCID: \href{https://orcid.org/0009-0008-1520-0706}{0009-0008-1520-0706} \\
\addlinespace
\textbf{Afzalur Rahman} & Faculty & School of Business, Woxsen University, Hyderabad, India & \href{mailto:afzalur.rahman@woxsen.edu.in}{afzalur.rahman@woxsen.edu.in}\\
& & & ORCID: \href{https://orcid.org/0000-0002-1561-561X}{0000-0002-1561-561X} \\
\bottomrule
\end{tabularx}

\end{document}
"""

for d in CL_DIRS:
    path = os.path.join(d, "cover_letter.tex")
    with open(path, "w", encoding="utf-8") as f:
        f.write(cl_content)
    print(f"Updated {path}")
