import pypdf
import glob
import os

authors = ['Shahrukh', 'Saleem', 'Araby', 'Madbouly', 'Uvesh', 'Husain', 'Ram Soorat', 'Priyanka', 'Afzalur', 'Rahman']

supp_files = glob.glob('**/supplementary.pdf', recursive=True)
ga_files = glob.glob('**/graphical_abstract.pdf', recursive=True)
main_files = glob.glob('**/Manuscript_Without_Author_Details.pdf', recursive=True)

print('=== 1. VERIFYING SUPPLEMENTARY ANONYMIZATION ===')
for sf in supp_files:
    if 'build' in sf or 'dist' in sf:
        continue
    reader = pypdf.PdfReader(sf)
    meta = reader.metadata or {}
    meta_author = meta.get('/Author', '')
    print(f'Checking {sf} ({len(reader.pages)} pages), Author meta: "{meta_author}"')
    assert meta_author == 'Anonymous Authors', f"Author meta in {sf} should be 'Anonymous Authors', got {meta_author}"
    for idx, page in enumerate(reader.pages):
        txt = page.extract_text()
        for a in authors:
            if a.lower() in txt.lower():
                print(f'  [FAIL] Author {a} found on page {idx+1} in {sf}')
                raise SystemExit(1)
print('  -> PASS: All supplementary files are 100% anonymized!')

print('\n=== 2. VERIFYING GRAPHICAL ABSTRACT ANONYMIZATION & WORDING ===')
for gf in ga_files:
    if 'build' in gf or 'dist' in gf:
        continue
    reader = pypdf.PdfReader(gf)
    meta = reader.metadata or {}
    meta_author = meta.get('/Author', '')
    txt = reader.pages[0].extract_text()
    print(f'Checking {gf}, Author meta: "{meta_author}"')
    for a in authors:
        if a.lower() in txt.lower():
            print(f'  [FAIL] Author {a} found in {gf}')
            raise SystemExit(1)
        if a.lower() in str(meta_author).lower():
            print(f'  [FAIL] Author {a} found in meta of {gf}')
            raise SystemExit(1)
    # Check updated wording
    has_exact = '4,096' in txt and '20 ms' in txt
    has_aero = 'Qiskit' in txt and 'Aer' in txt
    print(f'  Wording check: 4096/20ms={has_exact}, Qiskit Aer={has_aero}')
    assert has_exact, "Missing 4096 states in 20 ms"
    assert has_aero, "Missing Qiskit Aer"
print('  -> PASS: All graphical abstract files are 100% anonymized with updated wording!')

print('\n=== 3. VERIFYING MAIN MANUSCRIPT ANONYMIZATION ===')
for mf in main_files:
    reader = pypdf.PdfReader(mf)
    meta = reader.metadata or {}
    meta_author = meta.get('/Author', '')
    print(f'Checking {mf}, Author meta: "{meta_author}"')
    for a in authors:
        if a.lower() in str(meta_author).lower():
            print(f'  [FAIL] Author {a} in meta of {mf}')
            raise SystemExit(1)
    txt_p1 = reader.pages[0].extract_text()
    for a in authors:
        if a.lower() in txt_p1.lower():
            print(f'  [FAIL] Author {a} in page 1 of {mf}')
            raise SystemExit(1)
print('  -> PASS: All main manuscript files are 100% anonymized!')

print('\n=== 4. VERIFYING AUTHOR-CONTAINING FILES (Title Page & Cover Letter) ===')
tp_files = glob.glob('**/Title_Page_with_Author_Details.pdf', recursive=True)
cl_files = glob.glob('**/cover_letter.pdf', recursive=True)
for f in tp_files:
    reader = pypdf.PdfReader(f)
    txt = reader.pages[0].extract_text()
    assert 'Shahrukh Saleem' in txt, f'Missing Shahrukh in {f}'
    print(f'Confirmed authors present in Title Page: {f}')
for f in cl_files:
    reader = pypdf.PdfReader(f)
    txt = reader.pages[0].extract_text()
    assert 'Shahrukh Saleem' in txt, f'Missing Shahrukh in {f}'
    print(f'Confirmed corresponding author present in Cover Letter: {f}')

print('\n======================================================')
print('ALL FINAL REVIEW REQUIREMENTS ARE 100% VERIFIED AND SATISFIED!')
print('======================================================')
