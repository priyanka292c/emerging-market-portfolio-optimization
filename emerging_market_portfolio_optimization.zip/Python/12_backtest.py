"""
12_backtest.py
==============
Walk-forward portfolio backtesting engine.
Computes realised returns, turnover, TC, and full risk metrics
for every model and every rebalancing date.

Inputs:
  - Results/classical_weights_{model}.csv
  - Results/qaoa_weights_{date}.csv (if available)
  - Data/processed/returns.csv

Outputs:
  - Results/portfolio_returns.csv      : monthly returns per model
  - Results/portfolio_performance.csv  : aggregated performance table
  - Results/portfolio_metrics_full.csv : full metrics per model
  - Results/turnover.csv               : turnover per date per model
  - Logs/12_backtest.log
"""

import sys
import logging
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
DATA_PROC = ROOT / "Data" / "processed"
RESULTS   = ROOT / "Results"
LOG_DIR   = ROOT / "Logs"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "12_backtest.log", mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
log = logging.getLogger(__name__)

TC_COST    = 0.002   # 20bps round-trip
RF_ANNUAL  = 0.14    # Turkish risk-free rate proxy (approx repo rate; documented)
# Note: RF rate is an approximation. A more precise value from CBRT data
# would be preferable. This is documented as a limitation.

MODELS = [
    "A_HistMean_MV", "B_Factor_MV", "C_FactorRegime_MV",
    "D_FactorRegime_CVaR", "E_Full_MIQP",
    "EW", "RP", "SA", "GA",
]


def load_weights(model: str) -> pd.DataFrame | None:
    path = RESULTS / f"classical_weights_{model}.csv"
    if not path.exists():
        log.warning(f"Weights not found: {path}")
        return None
    df = pd.read_csv(path, parse_dates=["date"])
    df = df.set_index("date").sort_index()
    return df


def compute_portfolio_return(weights_t: pd.Series,
                              monthly_ret: pd.DataFrame,
                              date: pd.Timestamp) -> float:
    """Compute portfolio return in month following date."""
    # Next month's realised return
    future_months = monthly_ret.index[monthly_ret.index > date]
    if len(future_months) == 0:
        return np.nan
    next_month = future_months[0]
    tickers = weights_t.index
    available = monthly_ret.columns.intersection(tickers)
    if available.empty:
        return np.nan
    ret_vec = monthly_ret.loc[next_month, available].fillna(0)
    w_vec   = weights_t.reindex(available).fillna(0).values
    if w_vec.sum() > 0:
        w_vec = w_vec / w_vec.sum()
    return float(ret_vec.values @ w_vec)


def compute_turnover(w_new: pd.Series, w_old: pd.Series) -> float:
    """Portfolio turnover: sum of |w_new - w_old|."""
    tickers = w_new.index.union(w_old.index)
    w1 = w_new.reindex(tickers).fillna(0)
    w2 = w_old.reindex(tickers).fillna(0)
    return float((w1 - w2).abs().sum())


def backtest_model(model: str, monthly_ret: pd.DataFrame) -> pd.DataFrame:
    weights_df = load_weights(model)
    if weights_df is None:
        return pd.DataFrame()

    records = []
    prev_weights = None

    for date in weights_df.index:
        w_new = weights_df.loc[date].dropna()
        w_new = w_new[w_new != 0]

        # Portfolio return next month
        port_ret = compute_portfolio_return(w_new, monthly_ret, date)

        # Turnover and TC
        if prev_weights is not None:
            turnover = compute_turnover(w_new, prev_weights)
            tc       = TC_COST * turnover
        else:
            turnover = 0.0
            tc       = 0.0

        net_ret = port_ret - tc if not np.isnan(port_ret) else np.nan

        records.append({
            "date":      date,
            "model":     model,
            "gross_ret": port_ret,
            "turnover":  turnover,
            "tc":        tc,
            "net_ret":   net_ret,
            "n_assets":  int((w_new > 0.001).sum()),
        })
        prev_weights = w_new.copy()

    return pd.DataFrame(records)


def compute_full_metrics(returns: np.ndarray,
                          model: str,
                          rf_annual: float = RF_ANNUAL) -> dict:
    """Compute complete set of financial performance metrics."""
    sys.path.insert(0, str(ROOT / "Python"))
    from cvar_utils import portfolio_risk_report
    base = portfolio_risk_report(returns, label=model, rf_annual=rf_annual)

    # Alpha and Beta vs BIST-100
    try:
        macro  = pd.read_csv(DATA_PROC / "macro.csv", index_col=0, parse_dates=True)
        bist   = macro["BIST100"].resample("ME").last().pct_change().dropna()
        idx    = bist.index.intersection(pd.DatetimeIndex(
            [base.get("label", "")]  # placeholder; need date alignment below
        ))
    except Exception:
        bist = None

    base["model"] = model
    return base


def main():
    log.info("=" * 70)
    log.info("Phase 12: Walk-Forward Backtesting")
    log.info("=" * 70)

    ret_path = DATA_PROC / "returns.csv"
    if not ret_path.exists():
        log.error("returns.csv not found.")
        sys.exit(1)

    returns_daily = pd.read_csv(ret_path, index_col=0, parse_dates=True)
    monthly_ret   = np.expm1(returns_daily.resample("ME").sum())

    all_bt = []
    for model in MODELS:
        log.info(f"\nBacktesting: {model}")
        bt = backtest_model(model, monthly_ret)
        if not bt.empty:
            all_bt.append(bt)
            log.info(f"  Periods: {len(bt)}, Avg net return: "
                     f"{bt['net_ret'].mean():.4f}, Avg turnover: {bt['turnover'].mean():.4f}")

    if not all_bt:
        log.error("No backtest results. Check that classical_weights_*.csv exist.")
        sys.exit(1)

    bt_all = pd.concat(all_bt, ignore_index=True)
    bt_all.to_csv(RESULTS / "portfolio_returns.csv", index=False)

    # Aggregate performance
    perf_records = []
    for model in MODELS:
        sub = bt_all[bt_all["model"] == model].dropna(subset=["net_ret"])
        if len(sub) < 6:
            continue
        rets = sub["net_ret"].values
        rf_m = (1 + RF_ANNUAL) ** (1 / 12) - 1
        excess = rets - rf_m

        ann_ret = (1 + rets.mean()) ** 12 - 1
        ann_vol = rets.std() * np.sqrt(12)
        sharpe  = excess.mean() / excess.std() * np.sqrt(12) if excess.std() > 0 else np.nan
        neg_excess = excess[excess < 0]
        sortino = excess.mean() * 12 / (neg_excess.std() * np.sqrt(12)) \
                  if len(neg_excess) > 0 and neg_excess.std() > 0 else np.nan
        wealth  = np.cumprod(1 + rets)
        peak    = np.maximum.accumulate(wealth)
        mdd     = float(((peak - wealth) / peak).max())
        calmar  = ann_ret / mdd if mdd > 0 else np.nan
        cvar_95 = -np.percentile(rets, 5)  # empirical CVaR
        losses  = -rets
        cvar_exact = float(losses[losses >= np.percentile(losses, 95)].mean())

        perf_records.append({
            "model":         model,
            "n_months":      len(rets),
            "ann_return":    round(ann_ret, 6),
            "ann_vol":       round(ann_vol, 6),
            "sharpe":        round(sharpe, 4)  if not np.isnan(sharpe)  else np.nan,
            "sortino":       round(sortino, 4) if not np.isnan(sortino) else np.nan,
            "calmar":        round(calmar, 4)  if not np.isnan(calmar)  else np.nan,
            "cvar_95":       round(cvar_exact, 6),
            "max_drawdown":  round(mdd, 6),
            "avg_turnover":  round(sub["turnover"].mean(), 4),
            "avg_tc":        round(sub["tc"].mean(), 6),
            "pct_positive":  round((rets > 0).mean(), 4),
        })

    perf_df = pd.DataFrame(perf_records)
    perf_df.to_csv(RESULTS / "portfolio_performance.csv", index=False)

    log.info("\n" + "=" * 70)
    log.info("PORTFOLIO PERFORMANCE SUMMARY (Net of TC)")
    log.info("=" * 70)
    log.info(perf_df.to_string(index=False))
    log.info(f"\n[OK] Results saved: {RESULTS / 'portfolio_performance.csv'}")


if __name__ == "__main__":
    main()
