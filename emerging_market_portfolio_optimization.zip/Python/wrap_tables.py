import os
import re

tables_dir = "LaTeX/tables"

for fname in os.listdir(tables_dir):
    if not fname.endswith(".tex"):
        continue
    fpath = os.path.join(tables_dir, fname)
    with open(fpath, "r", encoding="utf-8") as f:
        content = f.read()

    # If it has tabular and not already resizebox
    if r"\begin{tabular}" in content and r"\resizebox" not in content:
        # Check if table is wide (more than 4 columns or specific tables)
        match = re.search(r"\\begin\{tabular\}\{([^}]+)\}", content)
        if match:
            cols = match.group(1).replace(" ", "")
            # If 5 or more columns, or table04, table06, table10, table11, table12, table13, table14, table15, table16
            if len(cols) >= 5 or any(k in fname for k in ["table04", "table06", "table09", "table10", "table11", "table12", "table13", "table14", "table15", "table16"]):
                new_content = content.replace(r"\begin{tabular}", r"\resizebox{\textwidth}{!}{%" + "\n" + r"\begin{tabular}")
                new_content = new_content.replace(r"\end{tabular}", r"\end{tabular}%" + "\n" + "}")
                with open(fpath, "w", encoding="utf-8") as f:
                    f.write(new_content)
                print(f"Wrapped {fname} in resizebox")

print("Finished table wrapping.")
