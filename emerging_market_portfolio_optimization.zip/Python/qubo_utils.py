"""
qubo_utils.py
=============
Shared QUBO/binary encoding utility functions.
Imported by 08_qubo_builder.py, 09_qaoa.py, 10_vqe.py, 11_noise_simulation.py.
"""

import numpy as np


def weight_from_bits(bits, n_bits, w_max):
    """Convert n_bits binary array to continuous weight in [0, w_max]."""
    levels = 2 ** n_bits - 1
    return (sum(b * (2 ** i) for i, b in enumerate(bits)) / levels) * w_max


def weight_vector_from_x(x, N, n_bits, w_max):
    """Convert full binary vector x (length N*n_bits) to weight vector (N,)."""
    w = np.zeros(N)
    for i in range(N):
        bits = x[i * n_bits: (i + 1) * n_bits]
        w[i] = weight_from_bits(bits, n_bits, w_max)
    return w


def asset_weight_coeffs(i, N, n_bits, w_max):
    """Returns coefficient vector a_i such that w_i = a_i^T x."""
    levels = 2 ** n_bits - 1
    a = np.zeros(N * n_bits)
    for b in range(n_bits):
        a[i * n_bits + b] = (2 ** b) / levels * w_max
    return a


def qubo_to_ising(Q, c):
    """
    QUBO Q(x) = x^T Q x + c  ->  Ising H(z) = z^T J z + h^T z + offset
    Substitution: x_i = (1 - z_i) / 2
    Returns J, h, offset.
    """
    M = Q.shape[0]
    J = np.zeros((M, M))
    h = np.zeros(M)

    for i in range(M):
        for j in range(i + 1, M):
            J[i, j] = Q[i, j] / 4
            J[j, i] = Q[i, j] / 4

    for i in range(M):
        h[i] = -0.5 * (Q[i, :].sum() + Q[:, i].sum()) / 2 + Q[i, i] / 2

    offset = 0.25 * Q.sum() + c
    return J, h, offset
