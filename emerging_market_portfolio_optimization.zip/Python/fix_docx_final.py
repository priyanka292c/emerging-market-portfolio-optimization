﻿with open(r"D:\Quantum finance\22_09_2026\Python\generate_all_docx.py", "r", encoding="utf-8") as f:
    txt = f.read()

txt = txt.replace('shutil.copy("LaTeX/', 'shutil.copy(r"D:/Quantum finance/22_09_2026/LaTeX/')
txt = txt.replace("shutil.copy('LaTeX/", "shutil.copy(r'D:/Quantum finance/22_09_2026/LaTeX/")

with open(r"D:\Quantum finance\22_09_2026\Python\generate_all_docx.py", "w", encoding="utf-8") as f:
    f.write(txt)
print("Updated shutil.copy LaTeX paths.")
