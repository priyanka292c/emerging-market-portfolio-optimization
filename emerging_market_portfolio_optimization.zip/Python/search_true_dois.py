import urllib.request
import urllib.parse
import json

targets = [
    ("balcilar2013investor", "Investor herds and regime-switching in extreme downside market conditions: The case of Gulf Arab stock markets", "Balcilar"),
    ("balke2000regime", "Credit and Economic Activity: Credit Regimes and Nonlinear Transmission of Shocks", "Balke"),
    ("bekaert2007liquidity", "Liquidity and Expected Returns in Emerging Markets", "Bekaert"),
    ("bouri2019herding", "Herding behaviour in cryptocurrencies", "Bouri"),
    ("culjak2022benefits", "Benefits of sectoral cryptocurrency portfolio optimization", "Culjak"),
    ("gurdgiev2020herding", "Herding and tail risk in cryptocurrency markets", "Gurdgiev"),
    ("kaya2021impact", "The impact of uncertainty shocks on Turkish financial markets", "Kaya"),
    ("mensi2016asymmetric", "Asymmetric dynamic linkages between BRICS stock markets and country risk ratings", "Mensi"),
    ("umutlu2010degree", "The Degree of Financial Liberalization and Aggregated Stock-Return Volatility in Emerging Markets", "Umutlu"),
]

for key, title, author in targets:
    query = f"{title} {author}"
    url = f"https://api.crossref.org/works?query.title={urllib.parse.quote(title)}&query.author={urllib.parse.quote(author)}&rows=3"
    req = urllib.request.Request(url, headers={'User-Agent': 'AntigravityVerifier/2.0 (mailto:scholar_verification@antigravity.org)'})
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            items = data.get('message', {}).get('items', [])
            print(f"=== {key} ===")
            print(f"Target: {title} ({author})")
            for it in items[:2]:
                found_title = it.get('title', [''])[0]
                found_doi = it.get('DOI', '')
                found_journal = it.get('container-title', [''])[0]
                print(f"  Found DOI: {found_doi}")
                print(f"  Found Title: {found_title}")
                print(f"  Found Journal: {found_journal}")
            print()
    except Exception as e:
        print(f"Error {key}: {e}")
