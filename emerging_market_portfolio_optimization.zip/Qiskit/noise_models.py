"""
Qiskit Standalone Module: Quantum Noise Models
=============================================
Provides depolarizing, readout, and thermal relaxation error models for AerSimulator.
"""

from qiskit_aer.noise import NoiseModel, depolarizing_error, ReadoutError


def get_depolarizing_model(epsilon: float) -> NoiseModel:
    """Builds a gate error model with 1-qubit and 2-qubit depolarizing noise."""
    model = NoiseModel()
    if epsilon > 0:
        err_1q = depolarizing_error(epsilon, 1)
        err_2q = depolarizing_error(2 * epsilon, 2)
        model.add_all_qubit_quantum_error(err_1q, ["rx", "ry", "rz", "h", "u"])
        model.add_all_qubit_quantum_error(err_2q, ["cx", "cz", "rzz"])
    return model


def get_readout_error_model(p_meas: float) -> NoiseModel:
    """Builds a readout error model with symmetric bit-flip measurement probabilities."""
    model = NoiseModel()
    if p_meas > 0:
        p_correct = 1.0 - p_meas
        ro = ReadoutError([[p_correct, p_meas], [p_meas, p_correct]])
        model.add_all_qubit_readout_error(ro)
    return model
