"""
Qiskit Standalone Module: QAOA Portfolio Optimization
====================================================
Implements parameterized QAOA circuits for portfolio sub-problems (Qiskit 2.x API).
"""

import numpy as np
from qiskit import QuantumCircuit, transpile
from qiskit.quantum_info import Statevector
from qiskit_aer import AerSimulator
from scipy.optimize import minimize


def build_qaoa_ansatz(J: np.ndarray, h: np.ndarray, p: int, gamma: np.ndarray, beta: np.ndarray) -> QuantumCircuit:
    """
    Constructs p-layer QAOA circuit for Ising Hamiltonian:
    H_C = sum_{i<j} J_{ij} Z_i Z_j + sum_i h_i Z_i
    """
    n_qubits = len(h)
    qc = QuantumCircuit(n_qubits)
    qc.h(range(n_qubits))

    for k in range(p):
        # Problem Unitary U_C(gamma)
        for i in range(n_qubits):
            for j in range(i + 1, n_qubits):
                if abs(J[i, j]) > 1e-10:
                    qc.rzz(2 * gamma[k] * J[i, j], i, j)
        for i in range(n_qubits):
            if abs(h[i]) > 1e-10:
                qc.rz(2 * gamma[k] * h[i], i)

        # Mixer Unitary U_B(beta)
        for i in range(n_qubits):
            qc.rx(2 * beta[k], i)

    return qc


def optimize_qaoa(J: np.ndarray, h: np.ndarray, offset: float, p: int = 1, maxiter: int = 200, seed: int = 42):
    """Solves the portfolio Ising problem using QAOA with statevector simulation."""
    n_qubits = len(h)
    rng = np.random.default_rng(seed)

    # Precompute state energies for fast vectorized expectation
    Z_all = np.array([[1 - 2 * int(b) for b in format(i, f'0{n_qubits}b')] for i in range(2 ** n_qubits)])
    E_all = np.einsum('ki,ij,kj->k', Z_all, J, Z_all) + Z_all @ h + offset

    def cost_fn(params):
        gamma = params[:p]
        beta = params[p:]
        qc = build_qaoa_ansatz(J, h, p, gamma, beta)
        probs = Statevector(qc).probabilities()
        return float(probs @ E_all)

    init_params = np.concatenate([rng.uniform(0, np.pi, p), rng.uniform(0, np.pi / 2, p)])
    res = minimize(cost_fn, init_params, method="COBYLA", options={"maxiter": maxiter})
    return res
