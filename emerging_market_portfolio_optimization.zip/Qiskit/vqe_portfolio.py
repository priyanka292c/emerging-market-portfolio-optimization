"""
Qiskit Standalone Module: VQE Portfolio Optimization
===================================================
Hardware-efficient VQE portfolio optimization with RealAmplitudes ansatz.
"""

import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit.library import RealAmplitudes
from qiskit.quantum_info import Statevector
from scipy.optimize import minimize


def optimize_vqe(J: np.ndarray, h: np.ndarray, offset: float, reps: int = 1, maxiter: int = 300, seed: int = 42):
    """Solves the portfolio Ising problem using VQE."""
    n_qubits = len(h)
    rng = np.random.default_rng(seed)

    ansatz = RealAmplitudes(n_qubits, entanglement="linear", reps=reps)
    Z_all = np.array([[1 - 2 * int(b) for b in format(i, f'0{n_qubits}b')] for i in range(2 ** n_qubits)])
    E_all = np.einsum('ki,ij,kj->k', Z_all, J, Z_all) + Z_all @ h + offset

    def cost_fn(theta):
        bound_circuit = ansatz.assign_parameters(dict(zip(ansatz.parameters, theta)))
        probs = Statevector(bound_circuit).probabilities()
        return float(probs @ E_all)

    init_theta = rng.uniform(-np.pi, np.pi, ansatz.num_parameters)
    res = minimize(cost_fn, init_theta, method="COBYLA", options={"maxiter": maxiter})
    return res
