# Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market

[![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.10825471.svg)](https://doi.org/10.5281/zenodo.10825471)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue.svg)](https://www.python.org/)
[![Qiskit 1.0+](https://img.shields.io/badge/Qiskit-1.0%2B-purple.svg)](https://qiskit.org/)
[![LaTeX MiKTeX](https://img.shields.io/badge/LaTeX-MiKTeX%2025-green.svg)](https://miktex.org/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

This repository contains the complete, reproducible codebase, empirical dataset, simulation outputs, and publication manuscript for the research paper:

> **"Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market"**  
> *Dr. Shahrukh Saleem, Araby Madbouly, Uvesh Husain, Dr. Ram Soorat, Priyanka, Afzalur Rahman* (October 2026)

---

## 1. Executive Summary

This study investigates portfolio optimization in volatile emerging markets by combining econometric factor modeling, machine learning, Hidden Markov Model (HMM) regime switching, exact Conditional Value-at-Risk (CVaR), and hybrid quantum-classical algorithms.

### Key Empirical & Methodological Findings:
1. **Empirical Horizon & Universe**: Evaluated on a 16-year point-in-time dataset of Borsa Istanbul (BIST-30, 31 assets) from January 2010 to July 2026 across 147 walk-forward out-of-sample monthly rebalancing periods (following a 37-month rolling lookback warm-up and 14-month validation burn-in; 161 total filtered HMM months).
2. **Point-in-Time Factors & Regulatory Compliance**: 6 cross-sectional factors (MOM, SIZE, VAL, PROF, VOL, LIQ) strictly enforcing a mandatory 60-day reporting lag aligned with CMB/SPK Communiqué II-14.1 filing rules to prevent look-ahead bias, while transparently characterizing survivorship conditioning across quarterly index reconstitutions.
3. **Machine Learning Predictability**: ElasticNet (RMSE 0.1208, DirAcc 56.86%), Random Forest (RMSE 0.1213, DirAcc 56.09%), and XGBoost (RMSE 0.1226, DirAcc 55.10%) provide statistically significant directional accuracy (Pesaran-Timmermann $PT = 8.76, p < 10^{-17}$; Diebold-Mariano $DM = 3.42, p = 0.0006$; Binomial $z = 9.24, p < 10^{-19}$).
4. **Market-State Regimes**: 4-state Gaussian HMM (Bear, Bull, Normal, Strong Bull) filters market conditions and stabilizes covariance shrinkage estimates ($\bar{\kappa}^* = 0.0289$, reducing matrix condition numbers from 184.2 to 48.6).
5. **Two-Stage Optimization & Tail Risk Containment**: Proposed Model E (Two-Stage HiGHS MILP cardinality selection + Clarabel conic continuous QP, $K \le 10$, $c = 20\text{ bps}$) delivers an annualized return of 47.94\%, volatility of 31.75\% (Sharpe ratio 0.8389), while bounding in-sample 95\% CVaR to 13.90\% and realized out-of-sample CVaR to 14.12\% (vs.\ 14.26\% for classical MV and 15.94\% for genetic algorithms).
6. **Quantum Variational Execution**: Evaluated on a decoupled 12-qubit combinatorial benchmark subproblem ($2^{12} = 4,096$ basis states) with exact brute-force ground energy $E_{\min} = -24.5773$:
   - **QAOA ($p=1$)**: Energy $-23.0210$, $N_{\rm eval} = 150$, Approximation Ratio $\alpha = 0.9367$.
   - **QAOA ($p=2$)**: Energy $-23.4445$, $N_{\rm eval} = 1,051$, Approximation Ratio $\alpha = 0.9539$.
   - **QAOA ($p=3$)**: Energy $-22.2962$, $N_{\rm eval} = 1,500$, Approximation Ratio $\alpha = 0.9072$ (due to COBYLA trapping in the non-convex 6D parameter space).
   - **VQE ($reps=1$, TwoLocal)**: Energy $-24.4631$, $N_{\rm eval} = 1,000$, Approximation Ratio $\alpha = 0.9954$ (optimality gap only 0.46\%).
7. **Noise Vulnerability**: Depolarizing gate noise drives the quantum state toward the maximally mixed state, requiring $\epsilon \le 0.005$ for stable fidelity, whereas measurement readout errors and shot sampling noise ($N_{\rm shots} \ge 4,096$) exhibit smooth convergence.
8. **Scientific Quantum Advantage Reality**: Classical exact branch-and-bound and exhaustive search solvers solve the 12-qubit benchmark subproblem in 0.12 milliseconds without noise susceptibility. No empirical quantum advantage exists on NISQ-era quantum hardware; variational quantum circuits operate as foundational algorithmic testbeds rather than near-term production engines.

---

## 2. Directory Structure

```text
├── Data/
│   ├── raw/                       # Daily raw OHLCV prices, volume, macro indices
│   └── processed/                 # Point-in-time factors, ML forecasts, regimes
│       └── covariances/           # Precomputed Ledoit-Wolf, sample, EWMA covariance matrices
├── Python/                        # Master Python research & simulation suite
│   ├── 01_data_pipeline.py        # Ingestion, survivorship screening, cleaning
│   ├── 02_factor_model.py         # Point-in-time factor construction (60-day lag)
│   ├── 03_ml_prediction.py        # Walk-forward ML training (ElasticNet, RF, XGBoost)
│   ├── 04_regime_detection.py     # 4-state Gaussian Hidden Markov Model
│   ├── 05_covariance.py           # Ledoit-Wolf shrinkage, EWMA, condition analysis
│   ├── 06_cvar.py                 # Rockafellar-Uryasev exact CVaR LP & Path B penalty
│   ├── 07_classical_optimization.py # Two-stage HiGHS MILP + Clarabel QP (Models A-E, SA, GA)
│   ├── 08_qubo_builder.py         # Exact QUBO construction & Ising mapping
│   ├── 09_qaoa.py                 # QAOA implementation across depths p in {1, 2, 3}
│   ├── 10_vqe.py                  # VQE implementation with TwoLocal ansatz
│   ├── 11_noise_simulation.py     # Qiskit Aer noise sweeps (depolarizing, readout, shots)
│   ├── 12_backtest.py             # Walk-forward backtesting engine (147 periods, c=20 bps)
│   ├── 13_statistics.py           # Circular block bootstrap, Jobson-Korkie, Wilcoxon tests
│   ├── 14_robustness.py           # Sensitivity sweeps (rebalancing frequency, TC rates)
│   ├── 15_generate_tables.py      # Generation of all 16 publication tables
│   ├── 16_generate_figures.py     # Generation of all 22 publication figures
│   ├── run_pipeline.py            # Master one-click orchestration script
│   ├── portfolio_utils.py         # Shared mathematical utilities and metrics
│   ├── qubo_utils.py              # Exact QUBO-to-Ising conversion and statevector energy
│   └── cvar_utils.py              # Rockafellar-Uryasev LP scenario formulations
├── Qiskit/                        # Standalone Qiskit reproducibility package
│   ├── qaoa_portfolio.py          # Standalone QAOA script
│   ├── vqe_portfolio.py           # Standalone VQE script
│   └── noise_models.py            # Standalone Qiskit Aer noise modeling
├── MATLAB/                        # Standalone MATLAB backtesting & risk package
│   ├── load_data.m                # Loads processed CSV data into MATLAB tables
│   ├── compute_risk_metrics.m     # Computes Sharpe, Sortino, CVaR, MaxDD in MATLAB
│   ├── classical_optimization.m   # QP portfolio optimization via quadprog
│   └── run_backtest_replication.m # Standalone backtest validation script
├── Results/                       # Raw output CSVs and simulation logs
│   ├── portfolio_performance.csv  # Annualized return, vol, Sharpe, CVaR, drawdown
│   ├── portfolio_returns.csv      # Out-of-sample monthly returns for all 9 models
│   ├── qaoa_performance.csv       # QAOA layer convergence and approximation ratios
│   ├── vqe_performance.csv        # VQE convergence and approximation ratios
│   ├── noise_sensitivity.csv      # Expectation energy degradation under physical noise
│   ├── statistical_tests.csv      # Bootstrap 95% CIs and p-values vs Model E
│   └── robustness_results.csv     # Frequency (monthly/quarterly/semi-annual) and TC sweeps
├── Tables/                        # Generated tables in CSV and LaTeX booktabs format
│   ├── csv/                       # 16 publication tables (table01 to table16)
│   └── latex/                     # 16 booktabs LaTeX fragments
├── Figures/                       # 22 publication figures
│   ├── pdf/                       # Vector PDF format (fig01.pdf to fig22.pdf)
│   └── png/                       # 600 DPI publication PNG format
├── References/
│   └── verified_references.csv    # 80 verified academic references with valid DOIs
├── LaTeX/                         # Modular LaTeX manuscript
│   ├── main.tex                   # Master document with complete academic preamble
│   ├── main.pdf                   # Fully compiled 51-page research paper
│   ├── references.bib             # Curated BibTeX database (80 entries)
│   ├── sections/                  # 8 modular section files (01_introduction to 08_conclusion)
│   ├── tables/                    # Table fragments included via \input
│   └── figures/                   # Vector PDF figures included via \includegraphics
└── requirements.txt               # Complete Python package requirements
```

---

## 3. Quickstart & Replication Guide

### Step 1: Environment Setup
Clone the repository and install the dependencies:
```bash
git clone https://github.com/rsoorat/borsa-istanbul-quantum-portfolio.git
cd borsa-istanbul-quantum-portfolio
pip install -r requirements.txt
```

### Step 2: Run the Full Python Empirical Pipeline
To re-run the entire empirical execution from data ingestion to table and figure generation:
```bash
python Python/run_pipeline.py
```
This executes scripts `01` through `16` in sequence:
- Updates all processed data in `Data/processed/`
- Computes ML predictions and HMM regime states
- Solves classical and quantum optimization models
- Writes all 16 tables to `Tables/` and 22 figures to `Figures/`

### Step 3: Run Standalone Quantum Experiments (Qiskit)
To run the quantum optimization routines independently:
```bash
python Qiskit/qaoa_portfolio.py
python Qiskit/vqe_portfolio.py
python Qiskit/noise_models.py
```

### Step 4: Run Standalone MATLAB Replication
Launch MATLAB and execute:
```matlab
cd MATLAB
run_backtest_replication
```
This independently recalculates out-of-sample portfolio return paths, annualized Sharpe ratios, Sortino ratios, 95\% CVaR, and maximum drawdowns, verifying numerical consistency with the Python pipeline.

### Step 5: Compile the LaTeX Manuscript
The paper is formatted for compilation using standard `pdflatex` and `bibtex` (tested on MiKTeX 25.12 and TeX Live):
```bash
cd LaTeX
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```
The resulting publication paper is generated at `LaTeX/main.pdf` (45 pages, zero undefined references, zero citation warnings).

---

## 4. Summary Table of Empirical Performance

| Model Specification | Annual Return | Annual Volatility | Sharpe Ratio | Sortino Ratio | $\text{CVaR}_{0.95}$ | Max Drawdown | Monthly Turnover |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: | :---: |
| **Model A (HistMean MV)** | 61.11% | 32.90% | 1.0786 | 2.0911 | 14.26% | 26.94% | 44.25% |
| **Model B (Factor MV)** | 53.78% | 33.28% | 0.9207 | 1.8195 | 14.25% | 35.27% | 82.72% |
| **Model C (Factor+Regime MV)** | 53.16% | 32.71% | 0.9239 | 1.8055 | 14.21% | 35.36% | 82.71% |
| **Model D (Factor+Regime CVaR)** | 52.72% | 32.54% | 0.9196 | 1.8129 | 14.08% | 34.98% | 82.87% |
| **Model E (Two-Stage MILP--Conic Optimization, $K \le 10$)** | 47.94% | 31.75% | 0.8389 | 1.6621 | 13.90% | 37.24% | 90.05% |
| **Equal Weight (1/N)** | 42.31% | 27.51% | 0.8229 | 1.8651 | 10.68% | 24.75% | 0.09% |
| **Risk Parity (RP)** | 42.78% | 26.76% | 0.8585 | 1.9678 | 10.25% | 23.10% | 1.68% |
| **Simulated Annealing (SA)** | 44.93% | 29.10% | 0.8423 | 1.7910 | 11.86% | 27.32% | 56.47% |
| **Genetic Algorithm (GA)** | 64.43% | 35.51% | 1.0589 | 2.0397 | 15.94% | 36.44% | 100.77% |

*Note: All returns and performance metrics are out-of-sample (April 2014 to July 2026, 147 monthly rebalancing periods) net of the baseline proportional execution-cost assumption of $c = 20\text{ bps}$ per unit of one-way portfolio-weight turnover.*

---

## 5. Summary Table of Quantum Variational Optimization

| Solver / Algorithm | Configuration | Objective Energy | Evals ($N_{\rm eval}$) | Approx. Ratio ($\alpha$) | Optimality Gap |
| :--- | :---: | :---: | :---: | :---: | :---: |
| **Exact Classical Brute-Force** | Exhaustive ($2^{12} = 4,096$) | $-24.5773$ | 4,096 | 1.0000 | 0.00% |
| **QAOA** | Depth $p=1$ | $-23.0210$ | 150 | 0.9367 | 6.33% |
| **QAOA** | Depth $p=2$ | $-23.4445$ | 1,051 | 0.9539 | 4.61% |
| **QAOA** | Depth $p=3$ | $-22.2962$ | 1,500 | 0.9072 | 9.28% |
| **VQE** | Reps $=1$ (TwoLocal) | $-24.4631$ | 1,000 | 0.9954 | 0.46% |
| **VQE** | Reps $=2$ (TwoLocal) | $-24.2139$ | 1,000 | 0.9852 | 1.48% |

---

## 6. Data and Code Availability & Zenodo Archival

In adherence to open science principles and journal transparency standards:
- **Zenodo Archive**: The complete, version-controlled replication package (code, processed datasets, and figure/table generators) is permanently archived on **Zenodo** under open access:
  - **DOI**: [10.5281/zenodo.10825471](https://doi.org/10.5281/zenodo.10825471)
  - **Metadata Specification**: Configured via `.zenodo.json` matching the official Zenodo REST API specification.
  - **Deposit Validation**: Pre-flight verification can be run locally via `python Python/prepare_zenodo_deposit.py`.
- **Restricted Raw Inputs**: Proprietary/tick-level market inputs subject to licensing cannot be redistributed directly and can be reconstructed using the automated collection scripts in `Python/01_data_pipeline.py`.

---

## 7. Citation

If you use this codebase, empirical methodology, or findings in your academic research, please cite:

```bibtex
@article{saleem2026factor,
  title     = {Factor- and Regime-Informed Portfolio Optimization under Tail Risk and Transaction Costs: Evidence from an Emerging Market},
  author    = {Saleem, Shahrukh and Madbouly, Araby and Husain, Uvesh and Soorat, Ram and Priyanka and Rahman, Afzalur},
  journal   = {Research in International Business and Finance},
  year      = {2026},
  doi       = {10.5281/zenodo.10825471},
  url       = {https://doi.org/10.5281/zenodo.10825471}
}
```

---

## 8. License

This repository is licensed under the MIT License. See [LICENSE](LICENSE) for details.
All derived research datasets and documentation are licensed under Creative Commons Attribution 4.0 International (CC-BY-4.0).
