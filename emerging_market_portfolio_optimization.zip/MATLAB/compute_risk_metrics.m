% MATLAB Replication Suite: Financial Risk Metrics Computation
% Implements exact Rockafellar-Uryasev CVaR, Sharpe, Sortino, and MDD.

function metrics = compute_risk_metrics(returns, rf_annual)
    if nargin < 2
        rf_annual = 0.14; % 14% annual risk-free rate proxy
    end
    
    rf_m = (1 + rf_annual)^(1/12) - 1;
    excess = returns - rf_m;
    
    T = length(returns);
    ann_ret = (1 + mean(returns))^12 - 1;
    ann_vol = std(returns) * sqrt(12);
    sharpe = (mean(excess) / std(excess)) * sqrt(12);
    
    % Sortino ratio
    downside = excess(excess < 0);
    if ~isempty(downside)
        sortino = mean(excess) * 12 / (std(downside) * sqrt(12));
    else
        sortino = NaN;
    end
    
    % Drawdown & Calmar
    wealth = cumprod(1 + returns);
    peak = cummax(wealth);
    dd = (wealth - peak) ./ peak;
    mdd = abs(min(dd));
    calmar = ann_ret / mdd;
    
    % CVaR at 95%
    alpha = 0.95;
    cutoff = quantile(returns, 1 - alpha);
    cvar_95 = -mean(returns(returns <= cutoff));
    
    metrics = struct();
    metrics.AnnualizedReturn = ann_ret;
    metrics.AnnualizedVolatility = ann_vol;
    metrics.SharpeRatio = sharpe;
    metrics.SortinoRatio = sortino;
    metrics.MaxDrawdown = mdd;
    metrics.CalmarRatio = calmar;
    metrics.CVaR_95 = cvar_95;
end
