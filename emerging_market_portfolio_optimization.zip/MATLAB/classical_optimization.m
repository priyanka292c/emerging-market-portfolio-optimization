% MATLAB Replication Suite: Classical Portfolio Optimization Benchmarks
% Implements Markowitz Mean-Variance, Equal Weight, and Risk Parity.

function [w_mv, w_ew, w_rp] = classical_optimization(mu, Sigma)
    N = length(mu);
    
    % 1. Equal Weight
    w_ew = ones(N, 1) / N;
    
    % 2. Mean-Variance Optimization (quadprog)
    % min  0.5 * w' * Sigma * w - (1/lambda) * mu' * w
    % s.t. sum(w) = 1, w >= 0
    lambda = 1.0;
    H = Sigma;
    f = -mu / lambda;
    Aeq = ones(1, N);
    beq = 1;
    lb = zeros(N, 1);
    ub = 0.20 * ones(N, 1); % Max 20% position limit
    
    options = optimoptions('quadprog', 'Display', 'off');
    w_mv = quadprog(H, f, [], [], Aeq, beq, lb, ub, [], options);
    
    % 3. Risk Parity (Inverse Volatility Heuristic)
    vols = sqrt(diag(Sigma));
    inv_vol = 1 ./ vols;
    w_rp = inv_vol / sum(inv_vol);
end
