% MATLAB Replication Suite: Walk-Forward Backtesting Replication
% Computes net performance metrics from Results/portfolio_returns.csv

function run_backtest_replication()
    resultsFile = fullfile('..', 'Results', 'portfolio_returns.csv');
    if ~exist(resultsFile, 'file')
        error('Results/portfolio_returns.csv not found. Run Python pipeline first.');
    end
    
    t = readtable(resultsFile, 'PreserveVariableNames', true);
    models = unique(t.model);
    
    disp('================================================================');
    disp(' MATLAB REPLICATION: Walk-Forward Performance Summary');
    disp('================================================================');
    fprintf('%-22s %-12s %-12s %-10s %-10s\n', 'Model', 'Ann.Return', 'Ann.Vol', 'Sharpe', 'MaxDD');
    disp('----------------------------------------------------------------');
    
    for i = 1:length(models)
        m = models{i};
        sub = t(strcmp(t.model, m), :);
        rets = sub.net_ret(~isnan(sub.net_ret));
        
        metrics = compute_risk_metrics(rets, 0.14);
        fprintf('%-22s %11.2f%% %11.2f%% %9.4f %9.2f%%\n', ...
            m, metrics.AnnualizedReturn*100, metrics.AnnualizedVolatility*100, ...
            metrics.SharpeRatio, metrics.MaxDrawdown*100);
    end
    disp('================================================================');
end
