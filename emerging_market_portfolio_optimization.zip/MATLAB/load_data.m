% MATLAB Replication Suite: Data Loading Script
% Loads processed prices, returns, and macro data from Data/processed/

function [prices, returns, macro, factors] = 01_load_data()
    disp('Loading processed financial datasets...');
    
    dataPath = fullfile('..', 'Data', 'processed');
    
    if exist(fullfile(dataPath, 'returns.csv'), 'file')
        returns = readtable(fullfile(dataPath, 'returns.csv'), 'PreserveVariableNames', true);
        disp(['Loaded returns: ', num2str(height(returns)), ' daily observations.']);
    else
        warning('returns.csv not found.');
        returns = [];
    end
    
    if exist(fullfile(dataPath, 'prices.csv'), 'file')
        prices = readtable(fullfile(dataPath, 'prices.csv'), 'PreserveVariableNames', true);
    else
        prices = [];
    end
    
    if exist(fullfile(dataPath, 'macro.csv'), 'file')
        macro = readtable(fullfile(dataPath, 'macro.csv'), 'PreserveVariableNames', true);
    else
        macro = [];
    end
    
    if exist(fullfile(dataPath, 'factors_monthly.csv'), 'file')
        factors = readtable(fullfile(dataPath, 'factors_monthly.csv'), 'PreserveVariableNames', true);
    else
        factors = [];
    end
end
